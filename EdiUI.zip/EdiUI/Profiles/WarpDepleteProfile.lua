-- EdiUI WarpDeplete Profile Data
-- Direct profile settings for WarpDeplete (AceDB-based addon)
local EdiUI = EdiUI
local Profiles = EdiUI.Profiles

Profiles.WarpDepleteData = {
    -- Force count format
    ["customForcesFormat"] = "Need :remainingcountafterpull: || :percentafterpull: || :count:/:totalcount:",
    ["forcesFormat"] = ":custom:",
    ["customCurrentPullFormat"] = "",
    ["currentPullFormat"] = ":custom:",
    ["customTooltipCountFormat"] = "+:count: || :percent:",
    ["tooltipCountFormat"] = ":custom:",

    -- Fonts
    ["bar1Font"] = "EdiFont",
    ["bar2Font"] = "EdiFont",
    ["bar3Font"] = "EdiFont",
    ["timerFont"] = "EdiFont",
    ["objectivesFont"] = "EdiFont",
    ["keyDetailsFont"] = "EdiFont",
    ["deathsFont"] = "EdiFont",
    ["forcesFont"] = "EdiFont",

    -- Font sizes
    ["bar1FontSize"] = 14,
    ["bar2FontSize"] = 14,
    ["bar3FontSize"] = 14,
    ["timerFontSize"] = 32,
    ["objectivesFontSize"] = 12,
    ["keyDetailsFontSize"] = 14,
    ["deathsFontSize"] = 14,
    ["forcesFontSize"] = 14,

    -- Textures
    ["bar1Texture"] = "Melli",
    ["bar2Texture"] = "Melli",
    ["bar3Texture"] = "Melli",
    ["forcesTexture"] = "Melli",
    ["forcesOverlayTexture"] = "Melli",

    -- Colors (hex format with alpha)
    ["bar1TextureColor"] = "fffc9a00",
    ["bar2TextureColor"] = "fffc9a00",
    ["bar3TextureColor"] = "fffc9a00",
    ["forcesTextureColor"] = "ff00a4ff",
    ["forcesOverlayTextureColor"] = "ffffffff",
    ["timerSuccessColor"] = "ff00a4ff",
    ["keyDetailsColor"] = "ff00a4ff",
    ["completedObjectivesColor"] = "fffc9a00",
    ["completedForcesColor"] = "fffc9a00",

    -- Bar dimensions
    ["barWidth"] = 290,
    ["barHeight"] = 8,

    -- Position (can be adjusted by user)
    ["frameX"] = 16,
    ["frameY"] = 140,
}
