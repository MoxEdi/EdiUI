# EdiUI Profile Management

## Quick Start

To update the addon profiles:

1. Edit any .txt file in this folder (ElvUI.txt, Plater.txt, etc.)
2. Paste your new import string
3. Save the file
4. Double-click UpdateProfiles.bat (in the EdiUI folder)
5. Reload WoW (/reload)

## Available Profiles

- ElvUI.txt - Main ElvUI profile
- ElvUIAura.txt - ElvUI Auras (Buffs/Debuffs)
- ElvUIDark.txt - ElvUI Dark theme variant
- ElvUIPrivate.txt - ElvUI Private settings
- ElvUIGlobal.txt - ElvUI Global settings
- Plater.txt - Plater Nameplates profile
- Details.txt - Details! Damage Meter profile
- EditMode.txt - Blizzard EditMode layout

## Requirements

- Python 3.x installed on your system
- If you don't have Python, download from: https://www.python.org/downloads/

## Notes

- The .txt files are human-readable import strings
- CustomImportStrings.lua is auto-generated - don't edit it directly!
- Always use UpdateProfiles.bat to regenerate the .lua file after editing .txt files
