-- EdiUI Color Definitions
-- Centralized color palette used throughout the addon
local ADDON_NAME, ns = ...

-- Ensure EdiUI global exists
if not EdiUI then
    EdiUI = {}
end

local Colors = {}

-- ============================================================================
-- BRAND COLORS
-- ============================================================================

Colors.BLUE = { r = 0.906, g = 0.298, b = 0.235 }  -- Vibrant red (was blue)
Colors.GOLD = { r = 1.0, g = 0.78, b = 0.29 }
Colors.DARK_BLUE = { r = 0.7, g = 0.2, b = 0.18 }  -- Dark red (was dark blue)
Colors.LIGHT_BLUE = { r = 0.95, g = 0.4, b = 0.35 }  -- Light red (was light blue)

-- ============================================================================
-- UI ELEMENT COLORS
-- ============================================================================

-- Backgrounds
Colors.BG_DARKER = { r = 0.02, g = 0.02, b = 0.03 }
Colors.BG_DARK = { r = 0.04, g = 0.04, b = 0.06 }
Colors.BG_MEDIUM = { r = 0.05, g = 0.05, b = 0.07 }
Colors.BG_LIGHT = { r = 0.07, g = 0.07, b = 0.09 }
Colors.BG_LIGHTER = { r = 0.08, g = 0.08, b = 0.1 }
Colors.BG_INPUT = { r = 0.08, g = 0.08, b = 0.1 }
Colors.BG_TITLEBAR = { r = 0.1, g = 0.1, b = 0.13 }
Colors.BG_SIDEBAR = { r = 0.05, g = 0.05, b = 0.07 }
Colors.BG_HOVER = { r = 0.12, g = 0.12, b = 0.16 }
Colors.BG_SELECTED = { r = 0.15, g = 0.15, b = 0.2 }
Colors.BG_BUTTON = { r = 0.2, g = 0.2, b = 0.25 }
Colors.BG_CONTROL = { r = 0.05, g = 0.05, b = 0.07 }

-- Borders
Colors.BORDER_DARK = { r = 0.15, g = 0.15, b = 0.2 }
Colors.BORDER_MEDIUM = { r = 0.2, g = 0.2, b = 0.25 }
Colors.BORDER_LIGHT = { r = 0.3, g = 0.3, b = 0.35 }
Colors.BORDER_INPUT = { r = 0.2, g = 0.2, b = 0.25 }
Colors.BORDER_TRACK = { r = 0.2, g = 0.2, b = 0.2 }

-- Text
Colors.TEXT_WHITE = { r = 1.0, g = 1.0, b = 1.0 }
Colors.TEXT_LIGHT = { r = 0.8, g = 0.8, b = 0.8 }
Colors.TEXT_MEDIUM = { r = 0.7, g = 0.7, b = 0.7 }

-- ============================================================================
-- COLOR STRINGS (for inline text coloring)
-- ============================================================================

Colors.HEADER_COLOR = "|cffffc84a"  -- Gold
Colors.ACCENT_COLOR = "|cffffc84a"  -- Gold
Colors.BLUE_TEXT = "|cffe74c3c"     -- Vibrant red (was blue)
Colors.GOLD_TEXT = "|cffffc84a"     -- Gold

-- ============================================================================
-- UTILITY FUNCTIONS
-- ============================================================================

function Colors:ToHex(color, includePrefix)
    if not color then
        return "ffffff"
    end

    local hex = string.format("%02x%02x%02x",
        math.floor((color.r or 1) * 255),
        math.floor((color.g or 1) * 255),
        math.floor((color.b or 1) * 255)
    )

    return (includePrefix and "|cff" or "") .. hex
end

function Colors:ToColorString(text, color)
    if not text or not color then
        return text or ""
    end

    return self:ToHex(color, true) .. text .. "|r"
end

function Colors:CreateColor(color, alpha)
    if not color then
        return CreateColor(1, 1, 1, alpha or 1)
    end

    return CreateColor(color.r or 1, color.g or 1, color.b or 1, alpha or color.a or 1)
end

-- ============================================================================
-- BLENDING UTILITIES
-- ============================================================================

local function Clamp01(value)
    if value < 0 then return 0 end
    if value > 1 then return 1 end
    return value
end

function Colors:BlendWithWhite(color, amount)
    if not color then
        return nil
    end

    local a = Clamp01(amount or 0)
    return {
        r = Clamp01(color.r + (1 - color.r) * a),
        g = Clamp01(color.g + (1 - color.g) * a),
        b = Clamp01(color.b + (1 - color.b) * a),
    }
end

function Colors:BlendWithBlack(color, amount)
    if not color then
        return nil
    end

    local a = Clamp01(amount or 0)
    return {
        r = Clamp01(color.r * (1 - a)),
        g = Clamp01(color.g * (1 - a)),
        b = Clamp01(color.b * (1 - a)),
    }
end

function Colors:Blend(color1, color2, ratio)
    if not color1 or not color2 then
        return color1 or color2
    end

    local r = Clamp01(ratio or 0.5)
    return {
        r = Clamp01(color1.r * (1 - r) + color2.r * r),
        g = Clamp01(color1.g * (1 - r) + color2.g * r),
        b = Clamp01(color1.b * (1 - r) + color2.b * r),
    }
end

-- ============================================================================
-- EXPORT
-- ============================================================================

-- Store in namespace
ns.Colors = Colors

-- Make available globally
if not EdiUI then
    EdiUI = {}
end
EdiUI.Colors = Colors
