-- EdiUI Core
local ADDON_NAME, ns = ...

-- Create main addon object
EdiUI = LibStub("AceAddon-3.0"):NewAddon("EdiUI", "AceEvent-3.0", "AceConsole-3.0", "AceTimer-3.0")

-- Addon info
EdiUI.Version = "1.400"
EdiUI.Name = "|cffe74c3cEdi|r|cffffc84aUI|r"

-- Namespace for modules
EdiUI.Media = {}

-- Get the detected UI type (ElvUI)
function EdiUI:GetActiveUI()
    local Compat = EdiUI.Compat or ns.Compat

    if Compat and Compat.IsAddOnLoaded then
        if Compat.IsAddOnLoaded("ElvUI") then
            return "elvui"
        end
    elseif C_AddOns and C_AddOns.IsAddOnLoaded then
        if C_AddOns.IsAddOnLoaded("ElvUI") then
            return "elvui"
        end
    end
    return nil
end

-- Slash command - now uses Sushi-based options panel
function EdiUI:CMD(msg)
    msg = msg and msg:lower() or ""
    
    -- Handle subcommands
    if msg:match("^install") then
        if self.Installer and self.Installer.Show then
            self.Installer:Show()
        else
            self:Print("Installer not available yet. Please wait a moment and try again.")
        end
    elseif msg:match("^reinstall") then
        if self.Installer and self.Installer.Reset then
            self.Installer:Reset()
        else
            self:Print("Installer not available yet. Please wait a moment and try again.")
        end
    elseif msg:match("^cluster") then
        local cluster = self:GetModule("ClusterPositioning", true)
        if cluster and cluster.Recalculate then
            cluster:Recalculate()
            self:Print("Cluster positioning recalculated.")
        else
            self:Print("ClusterPositioning module not available.")
        end
    elseif msg == "old" then
        -- Legacy: open old AceConfig panel if it exists
        local AceConfigDialog = LibStub("AceConfigDialog-3.0", true)
        if AceConfigDialog then
            AceConfigDialog:Open("EdiUI")
        end
    else
        -- Default: open new Sushi options panel
        if self.OpenOptions then
            self:OpenOptions()
        else
            self:Print("Options panel not loaded yet. Please wait a moment and try again.")
        end
    end
end

function EdiUI:OnInitialize()
    -- Load database
    self.db = LibStub("AceDB-3.0"):New("EdiUIDB", self.defaults, "Edi")

    if self.db then
        local current = self.db:GetCurrentProfile()
        local hasEdi = false
        for _, name in ipairs(self.db:GetProfiles()) do
            if name == "Edi" then
                hasEdi = true
                break
            end
        end

        if not hasEdi then
            if current ~= "Edi" then
                self.db:SetProfile("Edi")
                self.db:CopyProfile(current)
                self.db:SetProfile(current)
            else
                self.db:ResetProfile()
            end
        end
    end

    if self.db and self.db.RegisterCallback then
        self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
        self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
        self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
    end

    -- Register slash commands
    self:RegisterChatCommand("eui", "CMD")
    self:RegisterChatCommand("ediui", "CMD")
    self:RegisterChatCommand("rl", function() ReloadUI() end)
end

function EdiUI:OnProfileChanged()
    if self.BuildOptionsPanel then
        self:BuildOptionsPanel()
    end
    if self.CooldownManager and self.CooldownManager.Update then
        self.CooldownManager:Update()
    end
    if self.PowerBar and self.PowerBar.UpdateAll then
        self.PowerBar:UpdateAll()
    end
    if self.ClassBar and self.ClassBar.UpdateAll then
        self.ClassBar:UpdateAll()
    end
    if self.CastBar and self.CastBar.UpdateAll then
        self.CastBar:UpdateAll()
    end
end

function EdiUI:OnEnable()
    -- Register events
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    
    -- Initialize modules after a short delay
    C_Timer.After(0.5, function()
        local loadedModules = {}

        -- Initialize General UI tweaks
        if EdiUI.General and EdiUI.General.Initialize then
            EdiUI.General:Initialize()
            table.insert(loadedModules, "General")
        end
        
        -- Build the options panel (after all modules are registered)
        C_Timer.After(0.3, function()
            if EdiUI.BuildOptionsPanel then
                EdiUI:BuildOptionsPanel()
            end
        end)

        -- Auto-open installer if not completed
        C_Timer.After(0.6, function()
            if EdiUI.Installer and EdiUI.Installer.MaybeAutoOpen then
                EdiUI.Installer:MaybeAutoOpen()
            end
        end)
        
        -- Print initialization messages
        print(string.format("|cffe74c3cEdi|r|cffffc84aUI|r: v%s loaded! Type /eui for options.", EdiUI.Version))
        print("|cffe74c3cEdi|r|cffffc84aUI|r: Install: /eui install")
    end)
end

function EdiUI:PLAYER_ENTERING_WORLD()
    -- Reserved for future use
end

function EdiUI:Print(...)
    print(self.Name .. ":", ...)
end
