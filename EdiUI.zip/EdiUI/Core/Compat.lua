-- EdiUI Compatibility Layer
-- Provides unified API wrappers for WoW 12.0+
local ADDON_NAME, ns = ...

-- Ensure EdiUI global exists
if not EdiUI then
    EdiUI = {}
end

-- Create compatibility namespace
local Compat = {}

-- ============================================================================
-- ADDON MANAGEMENT (12.0+ uses C_AddOns exclusively)
-- ============================================================================

Compat.IsAddOnLoaded = C_AddOns.IsAddOnLoaded
Compat.GetAddOnInfo = C_AddOns.GetAddOnInfo
Compat.LoadAddOn = C_AddOns.LoadAddOn
Compat.GetAddOnMetadata = C_AddOns.GetAddOnMetadata

-- ============================================================================
-- UNIT POWER (12.0+ API changes)
-- ============================================================================

function Compat.GetUnitPower(unit, powerType)
    -- Force through string format to strip "secret value" protection
    local value = UnitPower(unit, powerType or 0)
    if value then
        local success, result = pcall(function() return tonumber(string.format("%d", value)) end)
        if success and result then
            return result
        end
    end
    return 0
end

function Compat.GetUnitPowerMax(unit, powerType)
    -- Force through string format to strip "secret value" protection
    local value = UnitPowerMax(unit, powerType or 0)
    if value then
        local success, result = pcall(function() return tonumber(string.format("%d", value)) end)
        if success and result then
            return result
        end
    end
    return 1
end

function Compat.GetUnitPowerPercent(unit, powerType)
    -- UnitPowerPercent can return protected "secret" values that can't be used in arithmetic
    -- Always use manual calculation for safety
    local current = Compat.GetUnitPower(unit, powerType)
    local max = Compat.GetUnitPowerMax(unit, powerType)
    if max and max > 0 then
        return (current / max) * 100
    end
    return 0
end

-- ============================================================================
-- FRAME UTILITIES (12.0+ removed old resize APIs)
-- ============================================================================

function Compat.SetFrameResize(frame, minW, minH, maxW, maxH)
    -- SetResizeBounds is the only method in 12.0+
    if frame.SetResizeBounds then
        frame:SetResizeBounds(minW, minH, maxW, maxH)
    end
end

-- ============================================================================
-- TEXTURE GRADIENTS (12.0+ removed SetGradientAlpha)
-- ============================================================================

function Compat.SetTextureGradient(texture, orientation, startColor, endColor)
    if not texture or not startColor or not endColor then
        return
    end

    -- Use modern SetGradient with CreateColor (12.0+ only method)
    if texture.SetGradient then
        texture:SetGradient(
            orientation or "HORIZONTAL",
            CreateColor(startColor.r, startColor.g, startColor.b, startColor.a or 1),
            CreateColor(endColor.r, endColor.g, endColor.b, endColor.a or 1)
        )
    end
end

-- ============================================================================
-- FONT STRING SHADOWS (12.0+ enhanced API)
-- ============================================================================

function Compat.SetFontStringShadow(fontString, enable, style)
    if not fontString then
        return
    end

    if enable then
        local alpha = (style == "" and 1 or 0.6)
        fontString:SetShadowColor(0, 0, 0, alpha)
        fontString:SetShadowOffset(1, -1)
    else
        fontString:SetShadowColor(0, 0, 0, 0)
        fontString:SetShadowOffset(0, 0)
    end
end

-- ============================================================================
-- EDITMODE (12.0+ event system)
-- ============================================================================

function Compat.RegisterEditModeCallback(event, callback)
    if EventRegistry and EventRegistry.RegisterCallback then
        EventRegistry:RegisterCallback(event, callback)
    end
end

function Compat.UnregisterEditModeCallback(event, callback)
    if EventRegistry and EventRegistry.UnregisterCallback then
        EventRegistry:UnregisterCallback(event, callback)
    end
end

-- Get EditMode system by ID
function Compat.GetEditModeSystem(systemID)
    if EditModeManagerFrame and EditModeManagerFrame.GetSystemByID then
        return EditModeManagerFrame:GetSystemByID(systemID)
    end
    return nil
end

-- ============================================================================
-- BLIZZARD FRAMES (12.0+ reorganization)
-- ============================================================================

function Compat.GetStanceBar()
    -- In 12.0, stance bar is part of EditMode system
    local stanceBarSystem = Compat.GetEditModeSystem(Enum.EditModeSystem.StanceBar)
    if stanceBarSystem then
        return stanceBarSystem
    end

    -- Fallback to global (may not exist in 12.0)
    return _G.StanceBar
end

function Compat.GetMinimap()
    -- Handle different UI configurations
    return Minimap or (MinimapCluster and MinimapCluster.Minimap)
end

function Compat.GetMicroButtons()
    local buttons = {}
    local buttonNames = {
        "CharacterMicroButton",
        "SpellbookMicroButton",
        "TalentMicroButton",
        "AchievementMicroButton",
        "QuestLogMicroButton",
        "GuildMicroButton",
        "LFDMicroButton",
        "EJMicroButton",
        "CollectionsMicroButton",
        "StoreMicroButton",
        "MainMenuMicroButton",
        "HelpMicroButton",
    }

    for _, name in ipairs(buttonNames) do
        local btn = _G[name]
        if btn then
            table.insert(buttons, btn)
        end
    end

    return buttons
end

-- ============================================================================
-- SAFE NUMBER CONVERSION
-- ============================================================================

function Compat.SafeNumber(value, default)
    if type(value) == "number" then
        return value
    end
    return default or 0
end

-- ============================================================================
-- COLOR UTILITIES
-- ============================================================================

function Compat.CreateColorFromTable(tbl)
    if not tbl then
        return CreateColor(1, 1, 1, 1)
    end

    return CreateColor(tbl.r or 1, tbl.g or 1, tbl.b or 1, tbl.a or 1)
end

function Compat.ColorToHex(r, g, b, prefix)
    if type(r) == "table" then
        b = r.b or 1
        g = r.g or 1
        r = r.r or 1
    end

    local hex = string.format("%02x%02x%02x",
        math.floor(r * 255),
        math.floor(g * 255),
        math.floor(b * 255)
    )

    return (prefix ~= false and "|cff" or "") .. hex
end

-- ============================================================================
-- EXPORT
-- ============================================================================

-- Store in namespace for other files
ns.Compat = Compat

-- Also make available globally for easier access
if not EdiUI then
    EdiUI = {}
end
EdiUI.Compat = Compat
