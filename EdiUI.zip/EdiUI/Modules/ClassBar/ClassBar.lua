-- EdiUI Class Bar
-- Shows class resource points (combo points, holy power, etc.) above the power bar
local EdiUI = EdiUI
local ClassBar = EdiUI:NewModule("ClassBar", "AceEvent-3.0", "AceHook-3.0")

local CLASS_POWER_TYPES = {
    Enum.PowerType.ComboPoints,
    Enum.PowerType.HolyPower,
    Enum.PowerType.SoulShards,
    Enum.PowerType.Chi,
    Enum.PowerType.ArcaneCharges,
    Enum.PowerType.Maelstrom,
    Enum.PowerType.Essence,
    Enum.PowerType.Runes,
}

local function GetElvUILSM()
    local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
    if E and E.Libs and E.Libs.LSM then
        return E.Libs.LSM
    end
    return nil
end

local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.classBar
end

local function GetElvUFColors()
    if _G.ElvUF and _G.ElvUF.colors then
        return _G.ElvUF.colors
    end
    return nil
end

local function NormalizeColor(color)
    if type(color) ~= "table" then
        return nil
    end
    if color.r then
        return { r = color.r, g = color.g, b = color.b }
    end
    if color[1] then
        return { r = color[1], g = color[2], b = color[3] }
    end
    return nil
end

local function Clamp01(value)
    if value < 0 then
        return 0
    end
    if value > 1 then
        return 1
    end
    return value
end

local function BlendWithWhite(color, amount)
    if not color then
        return nil
    end
    local a = Clamp01(amount or 0)
    return {
        r = Clamp01(color.r + (1 - color.r) * a),
        g = Clamp01(color.g + (1 - color.g) * a),
        b = Clamp01(color.b + (1 - color.b) * a),
    }
end

local function GetElegantOverride(powerType)
    if powerType == Enum.PowerType.ComboPoints then
        return { r = 1.0, g = 0.9, b = 0.55 }
    end
    if powerType == Enum.PowerType.HolyPower then
        return { r = 1.0, g = 0.86, b = 0.5 }
    end
    return nil
end

local function GetPointColor(powerType, index)
    local colors = GetElvUFColors()
    if not colors then
        return nil
    end

    if powerType == Enum.PowerType.ComboPoints and colors.ComboPoints then
        return colors.ComboPoints[index]
    end

    if powerType == Enum.PowerType.HolyPower and colors.ClassBars and colors.ClassBars.PALADIN then
        return colors.ClassBars.PALADIN[index] or colors.ClassBars.PALADIN
    end

    if powerType == Enum.PowerType.SoulShards and colors.ClassBars and colors.ClassBars.WARLOCK and colors.ClassBars.WARLOCK.SOUL_SHARDS then
        return colors.ClassBars.WARLOCK.SOUL_SHARDS[index] or colors.ClassBars.WARLOCK.SOUL_SHARDS
    end

    if powerType == Enum.PowerType.Chi and colors.ClassBars and colors.ClassBars.MONK then
        return colors.ClassBars.MONK[index] or colors.ClassBars.MONK
    end

    if powerType == Enum.PowerType.ArcaneCharges and colors.ClassBars and colors.ClassBars.MAGE and colors.ClassBars.MAGE.ARCANE_CHARGES then
        return colors.ClassBars.MAGE.ARCANE_CHARGES[index] or colors.ClassBars.MAGE.ARCANE_CHARGES
    end

    if powerType == Enum.PowerType.Maelstrom and colors.ClassBars and colors.ClassBars.SHAMAN and colors.ClassBars.SHAMAN.MAELSTROM then
        return colors.ClassBars.SHAMAN.MAELSTROM
    end

    if powerType == Enum.PowerType.Essence and colors.ClassBars and colors.ClassBars.EVOKER and colors.ClassBars.EVOKER.ESSENCE then
        return colors.ClassBars.EVOKER.ESSENCE[index] or colors.ClassBars.EVOKER.ESSENCE
    end

    if powerType == Enum.PowerType.Runes and colors.ClassBars and colors.ClassBars.DEATHKNIGHT then
        return colors.ClassBars.DEATHKNIGHT[index] or colors.ClassBars.DEATHKNIGHT
    end

    return nil
end

local function GetActivePowerType()
    local _, class = UnitClass("player")
    local currentPowerType = UnitPowerType("player")
    for _, powerType in ipairs(CLASS_POWER_TYPES) do
        local allow = true
        if class == "DRUID" and powerType == Enum.PowerType.ComboPoints then
            allow = (currentPowerType == Enum.PowerType.Energy)
        end
        if class == "MONK" and powerType == Enum.PowerType.Chi then
            local spec = GetSpecialization and GetSpecialization() or nil
            allow = (spec == 3)
        end
        if allow then
            local maxPower = UnitPowerMax("player", powerType)
            if maxPower and maxPower > 0 and maxPower <= 10 then
                return powerType, maxPower
            end
        end
    end
    return nil, 0
end

function ClassBar:CreateBar()
    if self.bar then
        return
    end

    local bar = CreateFrame("Frame", "EdiUIClassBar", UIParent, "BackdropTemplate")
    bar:SetFrameStrata("HIGH")
    bar:SetFrameLevel(35)

    bar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    bar:SetBackdropColor(0.05, 0.05, 0.07, 1)
    bar:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)

    local border = CreateFrame("Frame", nil, bar, "BackdropTemplate")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    border:SetBackdropBorderColor(0, 0, 0, 1)
    border:SetFrameLevel(bar:GetFrameLevel() - 2)
    bar.border = border

    bar.segments = {}
    self.bar = bar
end

function ClassBar:UpdateAnchor()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    self.bar:ClearAllPoints()
    local powerBar = _G.EdiUIPowerBar
    if powerBar then
        self.bar:SetPoint("BOTTOM", powerBar, "TOP", db.offsetX or 0, db.offsetY or 6)
    else
        local anchor = _G.EssentialCooldownViewer
        if anchor then
            self.bar:SetPoint("BOTTOM", anchor, "TOP", db.offsetX or 0, (db.offsetY or 6) + 10)
        else
            self.bar:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        end
    end

    local width = db.width or 220
    if db.matchEssentials then
        local essentials = _G.EssentialCooldownViewer
        if essentials and essentials.GetWidth then
            local essWidth = essentials:GetWidth()
            if essWidth and essWidth > 0 then
                width = essWidth
            end
        end
    end
    self.bar:SetWidth(width)
    self.bar:SetHeight(db.height or 12)
end

function ClassBar:UpdateTexture()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local lsm = GetElvUILSM()
    local tex = "Interface\\Buttons\\WHITE8x8"
    if lsm and db.texture and db.texture ~= "" then
        tex = lsm:Fetch("statusbar", db.texture) or tex
    end
    self.segmentTexture = tex

    for _, seg in ipairs(self.bar.segments) do
        if seg and seg.SetStatusBarTexture then
            seg:SetStatusBarTexture(tex)
        end
    end
end

function ClassBar:EnsureSegments(count)
    local bar = self.bar
    if not bar then
        return
    end

    for i = #bar.segments + 1, count do
        local seg = CreateFrame("StatusBar", nil, bar, "BackdropTemplate")
        seg:SetMinMaxValues(0, 1)
        seg:SetValue(0)
        seg:SetStatusBarTexture(self.segmentTexture or "Interface\\Buttons\\WHITE8x8")
        seg:SetFrameLevel(bar:GetFrameLevel() + 1)

        seg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        seg:SetBackdropColor(0.05, 0.05, 0.07, 1)
        seg:SetBackdropBorderColor(0, 0, 0, 1)

        local bg = seg:CreateTexture(nil, "BORDER")
        bg:SetTexture("Interface\\Buttons\\WHITE8x8")
        bg:SetPoint("TOPLEFT", seg, "TOPLEFT", 1, -1)
        bg:SetPoint("BOTTOMRIGHT", seg, "BOTTOMRIGHT", -1, 1)
        bg:SetColorTexture(0.12, 0.12, 0.14, 0.5)
        seg.bg = bg

        if i > 1 then
            local sep = seg:CreateTexture(nil, "OVERLAY")
            sep:SetColorTexture(0, 0, 0, 1)
            sep:SetPoint("LEFT", seg, "LEFT", -1, 0)
            sep:SetSize(1, 0)
            seg.sep = sep
        end
        bar.segments[i] = seg
    end

    for i = count + 1, #bar.segments do
        bar.segments[i]:Hide()
    end
end

function ClassBar:LayoutSegments(count)
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local spacing = db.spacing or 1
    if spacing < 0 then
        spacing = 0
    end
    local totalWidth = self.bar:GetWidth()
    local height = self.bar:GetHeight()
    if count <= 0 then
        return
    end

    local segWidth = (totalWidth - (spacing * (count - 1))) / count
    local x = 0
    for i = 1, count do
        local seg = self.bar.segments[i]
        if seg then
            seg:ClearAllPoints()
            seg:SetPoint("LEFT", self.bar, "LEFT", x, 0)
            seg:SetSize(segWidth, height)
            seg:Show()
            if seg.sep then
                seg.sep:SetHeight(height)
            end
            x = x + segWidth + spacing
        end
    end
end

function ClassBar:UpdateDisplay()
    local db = GetDb()
    if not db or not self.bar then
        return false
    end

    local powerType, maxPower = GetActivePowerType()
    if not powerType or maxPower <= 0 then
        self.bar:Hide()
        return false
    end

    local cur = UnitPower("player", powerType)
    if type(cur) ~= "number" then
        cur = 0
    end

    self:EnsureSegments(maxPower)
    self:LayoutSegments(maxPower)

    local baseColor = { r = 0.906, g = 0.298, b = 0.235 }
    if db.usePowerColor then
        local pointColor = NormalizeColor(GetPointColor(powerType, 1))
        if pointColor then
            baseColor = pointColor
        else
            local _, powerToken = UnitPowerType("player")
            local c = PowerBarColor and (PowerBarColor[powerType] or PowerBarColor[powerToken])
            if c then
                baseColor = { r = c.r, g = c.g, b = c.b }
            end
        end
    elseif db.color then
        baseColor = db.color
    end

    for i = 1, maxPower do
        local seg = self.bar.segments[i]
        if seg then
            seg:SetStatusBarTexture(self.segmentTexture or "Interface\\Buttons\\WHITE8x8")
            local overrideColor = GetElegantOverride(powerType)
            if i <= cur then
                seg:SetValue(1)
                local pointColor = overrideColor or NormalizeColor(GetPointColor(powerType, i)) or baseColor
                pointColor = BlendWithWhite(pointColor, 0.12) or pointColor
                seg:SetStatusBarColor(pointColor.r or 0.906, pointColor.g or 0.298, pointColor.b or 0.235)
                if seg.bg then
                    seg.bg:SetColorTexture((pointColor.r or 0.906) * 0.2, (pointColor.g or 0.298) * 0.2, (pointColor.b or 0.235) * 0.2, 0.6)
                end
            else
                local pointColor = overrideColor or NormalizeColor(GetPointColor(powerType, i)) or baseColor
                pointColor = BlendWithWhite(pointColor, 0.12) or pointColor
                seg:SetValue(1)
                seg:SetStatusBarColor((pointColor.r or 0.906) * 0.35, (pointColor.g or 0.298) * 0.35, (pointColor.b or 0.235) * 0.35)
                if seg.bg then
                    seg.bg:SetColorTexture(0.08, 0.08, 0.1, 0.6)
                end
            end
        end
    end

    self.bar:Show()
    return true
end

function ClassBar:UpdateAll()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    if db.enabled then
        self.bar:Show()
    else
        self.bar:Hide()
        return
    end

    self:UpdateAnchor()
    self:UpdateTexture()
    if not self:UpdateDisplay() then
        self.bar:Hide()
    end

    if not self.anchorPending then
        self.anchorPending = true
        C_Timer.After(0.1, function()
            self.anchorPending = false
            if self.bar then
                self:UpdateAnchor()
                self:UpdateDisplay()
            end
        end)
    end

    if not self.anchorPendingSpec then
        self.anchorPendingSpec = true
        C_Timer.After(0.2, function()
            self.anchorPendingSpec = false
            if self.bar then
                self:UpdateAnchor()
                self:UpdateDisplay()
            end
        end)
    end
end

function ClassBar:HookRefreshLayout()
    if self.layoutHooked then
        return
    end
    if _G.CooldownViewerSettings and _G.CooldownViewerSettings.RefreshLayout then
        self:SecureHook(_G.CooldownViewerSettings, "RefreshLayout", function()
            self:UpdateAnchor()
            if self.bar and self.bar.segments and #self.bar.segments > 0 then
                self:LayoutSegments(#self.bar.segments)
            end
        end)
        self.layoutHooked = true
    end
end

function ClassBar:OnEnable()
    self:CreateBar()
    self:HookRefreshLayout()

    self:RegisterEvent("PLAYER_ENTERING_WORLD", "UpdateAll")
    self:RegisterEvent("UNIT_POWER_UPDATE", "UpdateDisplay")
    self:RegisterEvent("UNIT_POWER_FREQUENT", "UpdateDisplay")
    self:RegisterEvent("UNIT_MAXPOWER", "UpdateAll")
    self:RegisterEvent("UNIT_DISPLAYPOWER", "UpdateAll")
    self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED", "UpdateAll")

    self:UpdateAll()
end
