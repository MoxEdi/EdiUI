-- EdiUI Trinket Tracker
-- Shows on-use trinkets with cooldowns anchored to the player unit frame
local EdiUI = EdiUI
local Trinkets = EdiUI:NewModule("Trinkets", "AceEvent-3.0")

local TRINKET_SLOTS = { 13, 14 }

local trackerFrame
local trackerBorder
local trinketFrames = {}

local function GetSettings()
    local profile = EdiUI.db and EdiUI.db.profile
    if not profile then return nil end
    profile.cooldownManager = profile.cooldownManager or {}
    profile.cooldownManager.trinkets = profile.cooldownManager.trinkets or {}
    return profile.cooldownManager.trinkets
end

local function GetAnchorParent()
    return _G.ElvUF_Player or _G.PlayerFrame or UIParent
end

local function EnsureFrames()
    if trackerFrame then return end

    trackerFrame = CreateFrame("Frame", "EdiUI_TrinketTracker", UIParent)
    trackerFrame:SetSize(1, 1)
    trackerFrame:SetFrameStrata("HIGH")
    trackerFrame:Hide()

    trackerBorder = CreateFrame("Frame", nil, trackerFrame, "BackdropTemplate")
    trackerBorder:SetPoint("TOPLEFT", trackerFrame, "TOPLEFT", -1, 1)
    trackerBorder:SetPoint("BOTTOMRIGHT", trackerFrame, "BOTTOMRIGHT", 1, -1)
    trackerBorder:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    trackerBorder:SetBackdropBorderColor(0, 0, 0, 0.8)
    trackerBorder:Show()

    for index, slot in ipairs(TRINKET_SLOTS) do
        local frame = CreateFrame("Frame", nil, trackerFrame)
        frame.slot = slot
        frame.icon = frame:CreateTexture(nil, "ARTWORK")
        frame.icon:SetAllPoints()
        frame.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        frame.cooldown = CreateFrame("Cooldown", nil, frame, "CooldownFrameTemplate")
        frame.cooldown:SetAllPoints()
        frame:Hide()
        trinketFrames[index] = frame
    end
end

function Trinkets:UpdateLayout(visibleFrames)
    local settings = GetSettings()
    if not settings or not trackerFrame then return end

    local size = settings.size or 20
    local spacing = settings.spacing or 4
    local anchor = settings.anchor or "BOTTOMLEFT"
    local offsetX = settings.offsetX or 0
    local offsetY = settings.offsetY or 0
    local strata = settings.strata or "HIGH"

    local parent = GetAnchorParent()
    trackerFrame:SetFrameStrata(strata)
    trackerFrame:ClearAllPoints()
    trackerFrame:SetPoint(anchor, parent, anchor, offsetX, offsetY)

    local count = #visibleFrames
    if count == 0 then
        trackerFrame:Hide()
        return
    end

    trackerFrame:SetSize((size * count) + (spacing * (count - 1)), size)
    trackerFrame:Show()
    if trackerBorder then
        trackerBorder:Show()
    end

    for i, frame in ipairs(visibleFrames) do
        frame:SetSize(size, size)
        frame:ClearAllPoints()
        if i == 1 then
            frame:SetPoint("LEFT", trackerFrame, "LEFT", 0, 0)
        else
            frame:SetPoint("LEFT", visibleFrames[i - 1], "RIGHT", spacing, 0)
        end
        frame:Show()
    end
end

function Trinkets:Update(_, unit)
    if unit and unit ~= "player" then
        return
    end
    local settings = GetSettings()
    if not settings or settings.enabled == false then
        if trackerFrame then trackerFrame:Hide() end
        return
    end

    EnsureFrames()

    local visible = {}
    for index, slot in ipairs(TRINKET_SLOTS) do
        local frame = trinketFrames[index]
        local itemID = GetInventoryItemID("player", slot)
        if itemID then
            local spellName = GetItemSpell(itemID)
            if spellName then
                local icon = GetInventoryItemTexture("player", slot)
                if icon then
                    frame.icon:SetTexture(icon)
                end

                local start, duration, enable = GetInventoryItemCooldown("player", slot)
                if enable == 1 and duration and duration > 0 then
                    if CooldownFrame_Set then
                        CooldownFrame_Set(frame.cooldown, start, duration, enable, true)
                    else
                        frame.cooldown:SetCooldown(start, duration)
                    end
                else
                    frame.cooldown:SetCooldown(0, 0)
                end
                frame.cooldown:Show()
                table.insert(visible, frame)
            else
                frame:Hide()
            end
        else
            frame:Hide()
        end
    end

    self:UpdateLayout(visible)
end

function Trinkets:OnEnable()
    self:RegisterEvent("PLAYER_ENTERING_WORLD", "Update")
    self:RegisterEvent("PLAYER_EQUIPMENT_CHANGED", "Update")
    self:RegisterEvent("UNIT_INVENTORY_CHANGED", "Update")
    self:RegisterEvent("SPELL_UPDATE_COOLDOWN", "Update")
    C_Timer.After(1, function()
        if self.Update then
            self:Update()
        end
    end)
end

function Trinkets:OnDisable()
    if trackerFrame then
        trackerFrame:Hide()
    end
end
