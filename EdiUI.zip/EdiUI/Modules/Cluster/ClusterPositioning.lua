-- EdiUI Cluster Positioning (ThingsUI-inspired)
-- Anchors ElvUI unit frames around Blizzard Essential cooldowns.
local EdiUI = EdiUI

local Cluster = EdiUI:NewModule("ClusterPositioning", "AceEvent-3.0", "AceHook-3.0")

local updateFrame = CreateFrame("Frame")
local updateThrottle = 0.05
local nextUpdate = 0
local lastEssentialCount = -1
local lastUtilityCount = -1
local savedPoints = {}
local hooksApplied = false

local function CountVisibleChildren(frame)
    if not frame then
        return 0
    end

    local count = 0
    for _, child in ipairs({ frame:GetChildren() }) do
        if child and child:IsShown() then
            count = count + 1
        end
    end
    return count
end

local function CalculateEffectiveWidth(db)
    local essentialCount = EssentialCooldownViewer and CountVisibleChildren(EssentialCooldownViewer) or 0
    local utilityCount = UtilityCooldownViewer and CountVisibleChildren(UtilityCooldownViewer) or 0

    local essentialWidth = (essentialCount * db.essentialIconWidth) +
        (math.max(0, essentialCount - 1) * db.essentialIconPadding)

    if not db.accountForUtility or utilityCount == 0 or essentialCount == 0 then
        return essentialWidth, essentialCount, utilityCount, 0
    end

    local utilityWidth = (utilityCount * db.utilityIconWidth) +
        (math.max(0, utilityCount - 1) * db.utilityIconPadding)

    local overflow = 0
    local extraUtilityIcons = math.max(0, utilityCount - essentialCount)
    local threshold = db.utilityThreshold or 3

    if extraUtilityIcons >= threshold and utilityWidth > essentialWidth then
        local widthDifference = utilityWidth - essentialWidth
        overflow = widthDifference + ((db.utilityOverflowOffset or 25) * 2)
    end

    return essentialWidth + overflow, essentialCount, utilityCount, overflow
end

local function SavePoint(frame)
    if not frame or savedPoints[frame] then
        return
    end

    local point, rel, relPoint, x, y = frame:GetPoint(1)
    savedPoints[frame] = {
        point = point,
        rel = rel,
        relPoint = relPoint,
        x = x,
        y = y,
    }
end

local function RestorePoint(frame)
    local data = savedPoints[frame]
    if not data or not frame then
        return
    end

    frame:ClearAllPoints()
    frame:SetPoint(data.point, data.rel, data.relPoint, data.x, data.y)
end

local function UpdateClusterPositioning(force)
    local db = EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.clusterPositioning
    if not db or not db.enabled then
        return
    end
    if InCombatLockdown() then
        return
    end
    if not EssentialCooldownViewer then
        return
    end

    local _, essentialCount, utilityCount, utilityOverflow = CalculateEffectiveWidth(db)

    if not force and essentialCount == lastEssentialCount and utilityCount == lastUtilityCount then
        return
    end
    lastEssentialCount = essentialCount
    lastUtilityCount = utilityCount

    -- Notify ClassBar and CastBar to update when essentials change
    if EdiUI.ClassBar and EdiUI.ClassBar.UpdateAnchor then
        C_Timer.After(0.15, function()
            if EdiUI.ClassBar and EdiUI.ClassBar.bar then
                EdiUI.ClassBar:UpdateAnchor()
                if EdiUI.ClassBar.UpdateDisplay then
                    EdiUI.ClassBar:UpdateDisplay()
                end
            end
        end)
    end
    if EdiUI.CastBar and EdiUI.CastBar.UpdateAnchor then
        C_Timer.After(0.15, function()
            if EdiUI.CastBar and EdiUI.CastBar.bar then
                EdiUI.CastBar:UpdateAnchor()
            end
        end)
    end

    local sideOverflow = utilityOverflow / 2

    if db.playerFrame.enabled then
        local playerFrame = _G["ElvUF_Player"]
        if playerFrame then
            local playerOffsetX = db.playerOffsetX or 0
            local playerOffsetY = db.playerOffsetY or 0
            SavePoint(playerFrame)
            playerFrame:ClearAllPoints()
            playerFrame:SetPoint("RIGHT", EssentialCooldownViewer, "LEFT", -(db.frameGap + sideOverflow) + playerOffsetX, playerOffsetY)
        end
    end

    if db.playerPowerBar and db.playerPowerBar.enabled then
        local playerFrame = _G["ElvUF_Player"]
        if playerFrame and playerFrame.Power then
            local powerBar = playerFrame.Power
            -- Check if power bar is detached (has its own holder)
            if powerBar.Holder and powerBar.Holder:GetParent() ~= playerFrame then
                local holder = powerBar.Holder
                SavePoint(holder)
                holder:ClearAllPoints()
                holder:SetPoint("TOP", playerFrame, "BOTTOM", db.playerPowerBar.xOffset or 0, -(db.playerPowerBar.gap or 1))
            end
        end
    end

    if db.targetFrame.enabled then
        local targetFrame = _G["ElvUF_Target"]
        if targetFrame then
            local targetOffsetX = db.targetOffsetX or 0
            local targetOffsetY = db.targetOffsetY or 0
            SavePoint(targetFrame)
            targetFrame:ClearAllPoints()
            targetFrame:SetPoint("LEFT", EssentialCooldownViewer, "RIGHT", db.frameGap + sideOverflow + targetOffsetX, targetOffsetY)
        end
    end

    if db.targetTargetFrame.enabled then
        local totFrame = _G["ElvUF_TargetTarget"]
        local targetFrame = _G["ElvUF_Target"]
        if totFrame and targetFrame then
            SavePoint(totFrame)
            totFrame:ClearAllPoints()
            totFrame:SetPoint("LEFT", targetFrame, "RIGHT", db.targetTargetFrame.gap, 0)
        end
    end

    if db.targetCastBar.enabled then
        local targetFrame = _G["ElvUF_Target"]
        local castBar = _G["ElvUF_Target_CastBar"]
        if targetFrame and castBar then
            local holder = castBar.Holder or castBar
            SavePoint(holder)
            holder:ClearAllPoints()
            holder:SetPoint("TOP", targetFrame, "BOTTOM", db.targetCastBar.xOffset, -db.targetCastBar.gap)
        end
    end

    if db.targetPowerBar and db.targetPowerBar.enabled then
        local targetFrame = _G["ElvUF_Target"]
        if targetFrame and targetFrame.Power then
            local powerBar = targetFrame.Power
            -- Check if power bar is detached (has its own holder)
            if powerBar.Holder and powerBar.Holder:GetParent() ~= targetFrame then
                local holder = powerBar.Holder
                SavePoint(holder)
                holder:ClearAllPoints()
                holder:SetPoint("TOP", targetFrame, "BOTTOM", db.targetPowerBar.xOffset or 0, -(db.targetPowerBar.gap or 1))
            end
        end
    end
end

local function OnUpdate()
    local currentTime = GetTime()
    if currentTime < nextUpdate then
        return
    end
    nextUpdate = currentTime + updateThrottle

    UpdateClusterPositioning()
end

function Cluster:Recalculate()
    lastEssentialCount = -1
    lastUtilityCount = -1
    UpdateClusterPositioning(true)
end

function Cluster:RestoreFrames()
    for frame in pairs(savedPoints) do
        RestorePoint(frame)
    end
end

function Cluster:UpdateSettings()
    local db = EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.clusterPositioning
    if not db or not db.enabled then
        updateFrame:SetScript("OnUpdate", nil)
        self:RestoreFrames()
        return
    end

    updateFrame:SetScript("OnUpdate", OnUpdate)
    self:Recalculate()
end

function Cluster:ApplyHooks()
    if hooksApplied then
        return
    end

    if C_AddOns.IsAddOnLoaded("Blizzard_CooldownViewer") and CooldownViewerSettings then
        self:SecureHook(CooldownViewerSettings, "RefreshLayout", function()
            self:Recalculate()
        end)
    end

    -- Hook into Blizzard Cooldown Frame changes
    if EssentialCooldownViewer then
        self:SecureHookScript(EssentialCooldownViewer, "OnShow", function()
            C_Timer.After(0.1, function() self:Recalculate() end)
        end)
        self:SecureHookScript(EssentialCooldownViewer, "OnHide", function()
            C_Timer.After(0.1, function() self:Recalculate() end)
        end)
    end

    if UtilityCooldownViewer then
        self:SecureHookScript(UtilityCooldownViewer, "OnShow", function()
            C_Timer.After(0.1, function() self:Recalculate() end)
        end)
        self:SecureHookScript(UtilityCooldownViewer, "OnHide", function()
            C_Timer.After(0.1, function() self:Recalculate() end)
        end)
    end

    local compat = EdiUI.Compat
    if compat and compat.RegisterEditModeCallback then
        compat.RegisterEditModeCallback("EditMode.Enter", function()
            self:Recalculate()
        end)
        compat.RegisterEditModeCallback("EditMode.Edit", function()
            self:Recalculate()
        end)
        compat.RegisterEditModeCallback("EditMode.Exit", function()
            self:Recalculate()
        end)
    elseif EditModeManagerFrame then
        self:SecureHook(EditModeManagerFrame, "EnterEditMode", function()
            self:Recalculate()
        end)
        self:SecureHook(EditModeManagerFrame, "ExitEditMode", function()
            self:Recalculate()
        end)
    end

    hooksApplied = true
end

function Cluster:OnEnable()
    local db = EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.clusterPositioning
    if not db then
        return
    end

    self:ApplyHooks()

    if db.enabled then
        self:UpdateSettings()
    end

    C_Timer.After(1.0, function()
        if EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.clusterPositioning.enabled then
            self:Recalculate()
        end
    end)
end
