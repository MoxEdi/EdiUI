-- EdiUI Portraits Functions
-- Adapted from Blinkiis Portraits for NephUI/ElvUI
local EdiUI = EdiUI
local Portraits = EdiUI.Portraits

local UnitIsPlayer = UnitIsPlayer
local UnitClass = UnitClass
local UnitReaction = UnitReaction
local UnitInPartyIsAI = UnitInPartyIsAI
local UnitClassification = UnitClassification
local UnitFactionGroup = UnitFactionGroup
local UnitIsDead = UnitIsDead
local UnitExists = UnitExists
local UnitGUID = UnitGUID
local UnitIsConnected = UnitIsConnected
local UnitIsVisible = UnitIsVisible
local UnitCastingInfo = UnitCastingInfo
local UnitChannelInfo = UnitChannelInfo
local select, tinsert = select, tinsert

-- Portrait textures (loaded from Media/Portraits)
Portraits.media = {}
Portraits.CachedBossIDs = {}
Portraits.PortraitFrames = {}

local playerFaction = nil

-- ============================================================================
-- UNIT FRAME MAPPINGS
-- ============================================================================
local unitFrames = {
    elvui = {
        player = "ElvUF_Player",
        target = "ElvUF_Target",
        pet = "ElvUF_Pet",
        targettarget = "ElvUF_TargetTarget",
        focus = "ElvUF_Focus",
        boss = "ElvUF_Boss",
    },
}

function Portraits:GetUnitFrame(unit)
    local uiType = EdiUI:GetActiveUI()
    if not uiType then return nil end
    
    local frames = unitFrames[uiType]
    if not frames then return nil end
    
    return frames[unit]
end

-- ============================================================================
-- TEXTURE/MEDIA FUNCTIONS
-- ============================================================================
local mediaPath = "Interface\\AddOns\\EdiUI\\Media\\Portraits\\"

-- Portrait frame textures
Portraits.media.portraits = {
    blizz = {
        texture = mediaPath .. "blizz.tga",
        mask = mediaPath .. "blizz_mask_a.tga",
        extra = mediaPath .. "blizz_extra_a.tga",
        mask_mirror = mediaPath .. "blizz_mask_b.tga",
        extra_mirror = mediaPath .. "blizz_extra_b.tga",
    },
    blizz_up = {
        texture = mediaPath .. "blizz_up.tga",
        mask = mediaPath .. "blizz_up_mask_a.tga",
        extra = mediaPath .. "blizz_up_extra_a.tga",
        mask_mirror = mediaPath .. "blizz_up_mask_b.tga",
        extra_mirror = mediaPath .. "blizz_up_extra_b.tga",
    },
    circle = {
        texture = mediaPath .. "circle.tga",
        mask = mediaPath .. "circle_mask.tga",
        extra = mediaPath .. "circle_extra.tga",
    },
    square = {
        texture = mediaPath .. "square.tga",
        mask = mediaPath .. "square_mask.tga",
        extra = mediaPath .. "square_extra.tga",
    },
    square_round = {
        texture = mediaPath .. "square_round.tga",
        mask = mediaPath .. "square_round_mask.tga",
        extra = mediaPath .. "square_round_extra.tga",
    },
    pad = {
        texture = mediaPath .. "pad.tga",
        mask = mediaPath .. "pad_mask.tga",
        extra = mediaPath .. "pad_extra.tga",
    },
    diamond = {
        texture = mediaPath .. "diamond.tga",
        mask = mediaPath .. "diamond_mask.tga",
        extra = mediaPath .. "diamond_extra.tga",
    },
    oval = {
        texture = mediaPath .. "oval.tga",
        mask = mediaPath .. "oval_mask.tga",
        extra = mediaPath .. "oval_extra.tga",
    },
}

-- Extra textures (rare/elite/boss indicators)
Portraits.media.extra = {
    blizz_neutral = mediaPath .. "extra_blizz_neutral.tga",
    blizz_boss = mediaPath .. "extra_blizz_boss.tga",
    blizz_boss_neutral = mediaPath .. "extra_blizz_boss_neutral.tga",
    blizz_gold = mediaPath .. "extra_blizz_gold.tga",
    blizz_silver = mediaPath .. "extra_blizz_silver.tga",
}

-- Class icon sets
Portraits.media.class = {
    none = nil,
}

-- ============================================================================
-- COLOR FUNCTIONS
-- ============================================================================
function Portraits:GetUnitColor(unit, isDead, isPlayer, class)
    if not unit then return end
    
    local colors = EdiUI.db.profile.colors
    
    if isDead then return colors.misc.death, isPlayer end
    
    if EdiUI.db.profile.misc.force_default then return colors.misc.default, isPlayer end
    
    if isPlayer then
        if EdiUI.db.profile.misc.force_reaction then
            local unitFaction = select(1, UnitFactionGroup(unit))
            playerFaction = playerFaction or select(1, UnitFactionGroup("player"))
            
            local reactionType = (playerFaction == unitFaction) and "friendly" or "enemy"
            return colors.reaction[reactionType], isPlayer
        else
            return class and colors.class[class] or colors.misc.default
        end
    else
        local reaction = (unit == "pet") and UnitReaction("player", unit) or UnitReaction(unit, "player")
        local reactionType = (reaction and ((reaction <= 3) and "enemy" or (reaction == 4) and "neutral" or "friendly")) or "enemy"
        return colors.reaction[reactionType], isPlayer
    end
end

-- ============================================================================
-- PORTRAIT UPDATE FUNCTIONS
-- ============================================================================
local function GetCastIcon(unit)
    return select(3, UnitCastingInfo(unit)) or select(3, UnitChannelInfo(unit))
end

local function UpdatePortraitTexture(portrait, unit)
    if portrait.isCasting then
        local castIcon = GetCastIcon(unit)
        if castIcon then
            portrait.portrait:SetTexture(castIcon)
            return
        else
            portrait.isCasting = false
        end
    end
    
    local forceDesaturate = EdiUI.db.profile.misc.desaturate
    
    if portrait.useClassIcon and portrait.isPlayer then
        portrait.unitClass = portrait.unitClass or select(2, UnitClass(portrait.unit))
        if portrait.classIcons and portrait.classIcons.texCoords and portrait.unitClass then
            portrait.texCoords = portrait.classIcons.texCoords[portrait.unitClass]
            portrait.portrait:SetTexture(portrait.classIcons.texture, "CLAMP", "CLAMP", "TRILINEAR")
        else
            SetPortraitTexture(portrait.portrait, unit or portrait.unit, true)
        end
    else
        SetPortraitTexture(portrait.portrait, unit or portrait.unit, true)
    end
    
    Portraits:UpdateDesaturated(portrait, (forceDesaturate or portrait.isDead))
    Portraits:Mirror(portrait.portrait, portrait.isPlayer and portrait.db.mirror, (portrait.isPlayer and portrait.useClassIcon) and portrait.texCoords)
end

function Portraits:UpdateDesaturated(portrait, isDead)
    if isDead then
        if not portrait.isDesaturated then
            portrait.portrait:SetDesaturated(true)
            portrait.isDesaturated = true
        end
    elseif portrait.isDesaturated then
        portrait.portrait:SetDesaturated(false)
        portrait.isDesaturated = false
    end
end

function Portraits:Mirror(texture, mirror, texCoords)
    if texCoords then
        local coords = texCoords
        if #coords == 8 then
            texture:SetTexCoord(unpack((mirror and { coords[5], coords[6], coords[7], coords[8], coords[1], coords[2], coords[3], coords[4] } or coords)))
        else
            texture:SetTexCoord(unpack((mirror and { coords[2], coords[1], coords[3], coords[4] } or coords)))
        end
    else
        texture:SetTexCoord(mirror and 1 or 0, mirror and 0 or 1, 0, 1)
    end
end

-- ============================================================================
-- MAIN UPDATE FUNCTION
-- ============================================================================
local function Update(portrait, event, eventUnit)
    if not portrait.unit then return end
    
    local unit = portrait.unit
    local guid = UnitGUID(unit)
    local isAvailable = UnitIsConnected(unit) and UnitIsVisible(unit)
    local hasStateChanged = ((event == "ForceUpdate") or (portrait.guid ~= guid) or (portrait.state ~= isAvailable))
    local isDead = event == "UNIT_HEALTH" and portrait.isDead or UnitIsDead(unit)
    
    if hasStateChanged or isDead ~= portrait.isDead then
        local class = select(2, UnitClass(unit))
        local isPlayer = UnitIsPlayer(unit) or UnitInPartyIsAI(unit)
        
        portrait.isPlayer = isPlayer
        portrait.unitClass = class
        portrait.lastGUID = guid
        portrait.state = isAvailable
        portrait.unit = unit
        portrait.isDead = isDead
        
        local color = Portraits:GetUnitColor(unit, portrait.isDead, isPlayer, class)
        if color then portrait.texture:SetVertexColor(color.r, color.g, color.b, color.a or 1) end
        
        UpdatePortraitTexture(portrait, unit)
        Portraits:UpdateExtraTexture(portrait, portrait.db.unitcolor and color, portrait.db.forceExtra)
        
        if not InCombatLockdown() and portrait:GetAttribute("unit") ~= unit then 
            portrait:SetAttribute("unit", unit) 
        end
    end
end

-- ============================================================================
-- CAST EVENTS
-- ============================================================================
local function CastStart(portrait, _, unit)
    portrait.isCasting = true
    local castIcon = GetCastIcon(unit)
    if castIcon then
        portrait.portrait:SetTexture(castIcon)
        if portrait.useClassIcon and portrait.texCoords then 
            Portraits:Mirror(portrait.portrait, portrait.isPlayer and portrait.db.mirror, { 0, 1, 0, 1 }) 
        end
    end
end

local function CastStop(portrait, event, unit)
    portrait.isCasting = false
    UpdatePortraitTexture(portrait, unit)
end

-- ============================================================================
-- EVENT HANDLERS
-- ============================================================================
local eventHandlers = {
    PORTRAITS_UPDATED = function(p, e, u) Update(p, e, p.unit) end,
    UNIT_CONNECTION = Update,
    UNIT_PORTRAIT_UPDATE = Update,
    PARTY_MEMBER_ENABLE = Update,
    ForceUpdate = Update,
    
    UNIT_SPELLCAST_CHANNEL_START = CastStart,
    UNIT_SPELLCAST_START = CastStart,
    UNIT_SPELLCAST_CHANNEL_STOP = CastStop,
    UNIT_SPELLCAST_INTERRUPTED = CastStop,
    UNIT_SPELLCAST_STOP = CastStop,
    UNIT_SPELLCAST_EMPOWER_START = CastStart,
    UNIT_SPELLCAST_EMPOWER_STOP = CastStop,
    
    UNIT_ENTERED_VEHICLE = function(p, e, u) C_Timer.After(0.6, function() Update(p, e, p.unit) end) end,
    UNIT_EXITING_VEHICLE = function(p, e, u) Update(p, e, p.unit) end,
    UNIT_EXITED_VEHICLE = function(p, e, u) Update(p, e, p.unit) end,
    VEHICLE_UPDATE = function(p, e, u) Update(p, e, p.unit) end,
    
    PLAYER_TARGET_CHANGED = function(p, e, u) Update(p, e, p.unit) end,
    PLAYER_FOCUS_CHANGED = function(p, e, u) Update(p, e, p.unit) end,
    UNIT_TARGET = function(p, e, u) Update(p, e, p.unit) end,
    
    GROUP_ROSTER_UPDATE = function(p, e, u) Update(p, e, p.unit) end,
    UNIT_NAME_UPDATE = function(p, e, u) Update(p, e, p.unit) end,
    
    UNIT_HEALTH = function(p, e, u)
        if p.unit ~= u then return end
        local isDead = UnitIsDead(p.unit)
        if p.isDead == isDead then return end
        p.isDead = isDead
        Update(p, e)
    end,
    
    ARENA_OPPONENT_UPDATE = Update,
    UNIT_TARGETABLE_CHANGED = Update,
    INSTANCE_ENCOUNTER_ENGAGE_UNIT = function(p, e, u) Update(p, e, p.unit) end,
}

local function OnEvent(portrait, event, eventUnit, arg)
    local unit = portrait.parentFrame and portrait.parentFrame.unit or portrait.unit
    portrait.unit = unit
    
    if eventHandlers[event] then eventHandlers[event](portrait, event, eventUnit, arg) end
end

-- ============================================================================
-- EXTRA TEXTURE (RARE/ELITE/BOSS)
-- ============================================================================
local extraTypes = { rare = true, elite = true, rareelite = true, boss = true }

function Portraits:UpdateExtraTexture(portrait, color, force)
    if not (portrait.extra and portrait.db.extra) then
        if portrait.extra then portrait.extra:Hide() end
        return
    end
    
    local npcID = portrait.lastGUID and select(6, strsplit("-", portrait.lastGUID))
    if portrait.type == "boss" and npcID and not Portraits.CachedBossIDs[npcID] then 
        Portraits.CachedBossIDs[npcID] = true 
    end
    
    local isBoss = portrait.type == "boss" or (npcID and Portraits.CachedBossIDs[npcID])
    local c = isBoss and "boss" or UnitClassification(portrait.unit)
    if c == "worldboss" then c = "boss" end
    
    local isExtraUnit = extraTypes[c]
    
    if not isExtraUnit and force and force ~= "none" then
        c = force
        isExtraUnit = true
    end
    
    if isExtraUnit and not color then
        color = EdiUI.db.profile.misc.force_reaction
                and (function()
                    local reaction = UnitReaction(portrait.unit, "player")
                    local reactionType = (reaction and ((reaction <= 3) and "enemy" or (reaction == 4) and "neutral" or "friendly")) or "enemy"
                    return EdiUI.db.profile.colors.reaction[reactionType]
                end)()
            or EdiUI.db.profile.colors.classification[c]
    end
    
    if color then
        portrait.extra:SetTexture(portrait[c .. "File"], "CLAMP", "CLAMP", "TRILINEAR")
        portrait.extra:SetVertexColor(color.r, color.g, color.b, color.a or 1)
        portrait.extra:Show()
    else
        portrait.extra:Hide()
    end
end

-- ============================================================================
-- TEXTURE UPDATE FUNCTIONS
-- ============================================================================
local function SetTexture(texture, file, wrapMode)
    texture:SetTexture(file, wrapMode, wrapMode, "TRILINEAR")
end

function Portraits:UpdateTextures(portrait)
    local mirror = portrait.db.mirror
    
    SetTexture(portrait.texture, portrait.textureFile, "CLAMP")
    SetTexture(portrait.mask, portrait.maskFile, "CLAMPTOBLACKADDITIVE")
    
    if portrait.extraMask then SetTexture(portrait.extraMask, portrait.extraMaskFile, "CLAMPTOBLACKADDITIVE") end
    SetTexture(portrait.bg, portrait.bgFile, "CLAMP")
    
    Portraits:Mirror(portrait.texture, mirror)
    Portraits:Mirror(portrait.extra, mirror)
end

function Portraits:UpdateTexturesFiles(portrait, settings)
    local dbMisc = EdiUI.db.profile.misc
    local media = self.media.portraits[settings.texture] or self.media.portraits.blizz
    
    portrait.bgFile = mediaPath .. "blank"
    
    if portrait.useClassIcon then 
        portrait.classIcons = self.media.class[dbMisc.class_icon] 
    end
    
    portrait.textureFile = media.texture
    portrait.maskFile = (settings.mirror and media.mask_mirror) and media.mask_mirror or media.mask
    portrait.extraMaskFile = (settings.mirror and media.extra_mirror) and media.extra_mirror or media.extra
    
    portrait.playerFile = self.media.extra[dbMisc.player] or self.media.extra.blizz_neutral
    portrait.rareFile = self.media.extra[dbMisc.rare] or self.media.extra.blizz_neutral
    portrait.eliteFile = self.media.extra[dbMisc.elite] or self.media.extra.blizz_neutral
    portrait.rareeliteFile = self.media.extra[dbMisc.rareelite] or self.media.extra.blizz_neutral
    portrait.bossFile = self.media.extra[dbMisc.boss] or self.media.extra.blizz_boss_neutral
end

-- ============================================================================
-- SIZE/POSITION UPDATE
-- ============================================================================
local function UpdateZoom(texture, size)
    local zoom = EdiUI.db.profile.misc.zoom
    local offset = (size / 2) * zoom
    
    texture:SetPoint("TOPLEFT", 0 - offset, 0 + offset)
    texture:SetPoint("BOTTOMRIGHT", 0 + offset, 0 - offset)
end

function Portraits:UpdateSize(portrait, size, point)
    if not InCombatLockdown() then
        size = size or portrait.size
        point = point or portrait.point
        portrait:SetSize(size / 2, size / 2)
        portrait.texture:SetSize(size, size)
        portrait:ClearAllPoints()
        portrait:SetPoint(point.point, portrait.parentFrame, point.relativePoint, point.x, point.y)
        
        if portrait.db.strata ~= "AUTO" then portrait:SetFrameStrata(portrait.db.strata) end
        portrait:SetFrameLevel(portrait.db.level)
    end
end

-- ============================================================================
-- PORTRAIT CREATION
-- ============================================================================
function Portraits:CreatePortrait(name, parent)
    if not parent then return nil end
    
    local portrait = CreateFrame("Button", "EdiUI_Portrait_" .. name, parent, "SecureUnitButtonTemplate")
    
    -- Main texture (frame border)
    portrait.texture = portrait:CreateTexture("EdiUI_texture-" .. name, "ARTWORK", nil, 4)
    portrait.texture:SetPoint("CENTER", portrait, "CENTER", 0, 0)
    
    -- Mask
    portrait.mask = portrait:CreateMaskTexture()
    portrait.mask:SetAllPoints(portrait.texture)
    
    -- Portrait (the actual unit portrait)
    portrait.portrait = portrait:CreateTexture("EdiUI_portrait-" .. name, "ARTWORK", nil, 2)
    portrait.portrait:SetAllPoints(portrait.texture)
    portrait.portrait:AddMaskTexture(portrait.mask)
    
    -- Extra texture (rare/elite/boss)
    local extraOnTop = EdiUI.db.profile.misc.extratop
    portrait.extra = portrait:CreateTexture("EdiUI_extra-" .. name, "OVERLAY", nil, extraOnTop and 7 or 1)
    portrait.extra:SetAllPoints(portrait.texture)
    
    -- Extra mask
    if not extraOnTop then
        portrait.extraMask = portrait:CreateMaskTexture()
        portrait.extraMask:SetAllPoints(portrait.texture)
        portrait.extra:AddMaskTexture(portrait.extraMask)
    end
    
    -- Background
    portrait.bg = portrait:CreateTexture("EdiUI_bg-" .. name, "BACKGROUND", nil, 1)
    portrait.bg:SetAllPoints(portrait.texture)
    portrait.bg:AddMaskTexture(portrait.mask)
    portrait.bg:SetVertexColor(0, 0, 0, 1)
    
    -- Mouse interaction
    portrait:SetAttribute("unit", portrait.unit)
    portrait:SetAttribute("*type1", "target")
    portrait:SetAttribute("*type2", "togglemenu")
    portrait:SetAttribute("type3", "focus")
    portrait:SetAttribute("toggleForVehicle", true)
    portrait:SetAttribute("ping-receiver", true)
    portrait:RegisterForClicks("AnyUp")
    portrait:Show()
    
    return portrait
end

-- ============================================================================
-- REGISTER EVENTS
-- ============================================================================
function Portraits:RegisterEvents(portrait, events, cast)
    for _, event in pairs(events) do
        if cast then
            portrait:RegisterUnitEvent(event, portrait.unit)
        else
            portrait:RegisterEvent(event)
        end
        tinsert(portrait.events, event)
    end
    
    portrait:RegisterUnitEvent("UNIT_HEALTH", portrait.unit)
end

local castEvents = { "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_CHANNEL_STOP" }
local empowerEvents = { "UNIT_SPELLCAST_EMPOWER_START", "UNIT_SPELLCAST_EMPOWER_STOP" }

function Portraits:RegisterCastEvents(portrait)
    if not portrait.castEventsSet then
        Portraits:RegisterEvents(portrait, castEvents, true)
        Portraits:RegisterEvents(portrait, empowerEvents, true)
        portrait.castEventsSet = true
    end
end

function Portraits:UnregisterCastEvents(portrait)
    for _, event in pairs(castEvents) do
        portrait:UnregisterEvent(event)
    end
    for _, event in pairs(empowerEvents) do
        portrait:UnregisterEvent(event)
    end
    portrait.castEventsSet = false
end

function Portraits:UpdateCastSettings(portrait)
    if portrait.db.cast then
        Portraits:RegisterCastEvents(portrait)
        portrait.cast = true
    elseif portrait.cast then
        Portraits:UnregisterCastEvents(portrait)
        portrait.cast = false
    end
end

-- ============================================================================
-- INITIALIZE PORTRAIT
-- ============================================================================
function Portraits:InitPortrait(portrait, events)
    if portrait then
        Portraits:UpdateTextures(portrait)
        
        if not portrait.eventsSet then
            Portraits:RegisterEvents(portrait, events)
            
            portrait:SetScript("OnEvent", OnEvent)
            portrait.eventsSet = true
        end
        OnEvent(portrait, "ForceUpdate", portrait.unit)
        
        UpdateZoom(portrait.portrait, portrait.size)
    end
end

-- ============================================================================
-- REMOVE PORTRAIT
-- ============================================================================
function Portraits:RemovePortrait(frame)
    if frame then
        frame:UnregisterAllEvents()
        frame:Hide()
    end
end
