-- EdiUI Portraits Module
-- Main portrait initialization and management
local EdiUI = EdiUI
local Portraits = EdiUI.Portraits

-- Standard events for portrait updates
local standardEvents = { 
    "UNIT_PORTRAIT_UPDATE", 
    "PORTRAITS_UPDATED", 
    "UNIT_MODEL_CHANGED", 
    "UNIT_CONNECTION", 
    "UNIT_ENTERED_VEHICLE", 
    "UNIT_EXITING_VEHICLE", 
    "UNIT_EXITED_VEHICLE", 
    "VEHICLE_UPDATE",
    "PLAYER_TARGET_CHANGED",
    "PLAYER_FOCUS_CHANGED"
}

-- ============================================================================
-- INITIALIZE SPECIFIC PORTRAIT TYPES
-- ============================================================================
function Portraits:InitializePlayerPortrait()
    if not EdiUI.db.profile.player.enable then return end
    
    local frameName = self:GetUnitFrame("player")
    if not frameName then return end
    
    local parent = _G[frameName]
    if not parent then return end
    
    self.PortraitFrames.player = self.PortraitFrames.player or self:CreatePortrait("player", parent)
    
    local portrait = self.PortraitFrames.player
    if portrait then
        portrait.events = {}
        portrait.parentFrame = parent
        portrait.unit = "player"
        portrait.type = "player"
        portrait.db = EdiUI.db.profile.player
        portrait.size = EdiUI.db.profile.player.size
        portrait.point = EdiUI.db.profile.player.point
        portrait.useClassIcon = EdiUI.db.profile.misc.class_icon ~= "none"
        portrait.realUnit = "player"
        
        portrait.isPlayer = nil
        portrait.unitClass = nil
        portrait.lastGUID = nil
        
        self:UpdateTexturesFiles(portrait, EdiUI.db.profile.player)
        self:UpdateSize(portrait)
        self:UpdateCastSettings(portrait)
        self:InitPortrait(portrait, standardEvents)
    end
end

function Portraits:InitializeTargetPortrait()
    if not EdiUI.db.profile.target.enable then return end
    
    local frameName = self:GetUnitFrame("target")
    if not frameName then return end
    
    local parent = _G[frameName]
    if not parent then return end
    
    self.PortraitFrames.target = self.PortraitFrames.target or self:CreatePortrait("target", parent)
    
    local portrait = self.PortraitFrames.target
    if portrait then
        portrait.events = {}
        portrait.parentFrame = parent
        portrait.unit = "target"
        portrait.type = "target"
        portrait.db = EdiUI.db.profile.target
        portrait.size = EdiUI.db.profile.target.size
        portrait.point = EdiUI.db.profile.target.point
        portrait.useClassIcon = EdiUI.db.profile.misc.class_icon ~= "none"
        portrait.realUnit = "target"
        
        portrait.isPlayer = nil
        portrait.unitClass = nil
        portrait.lastGUID = nil
        
        self:UpdateTexturesFiles(portrait, EdiUI.db.profile.target)
        self:UpdateSize(portrait)
        self:UpdateCastSettings(portrait)
        self:InitPortrait(portrait, standardEvents)
    end
end

function Portraits:InitializeFocusPortrait()
    if not EdiUI.db.profile.focus.enable then return end
    
    local frameName = self:GetUnitFrame("focus")
    if not frameName then return end
    
    local parent = _G[frameName]
    if not parent then return end
    
    self.PortraitFrames.focus = self.PortraitFrames.focus or self:CreatePortrait("focus", parent)
    
    local portrait = self.PortraitFrames.focus
    if portrait then
        portrait.events = {}
        portrait.parentFrame = parent
        portrait.unit = "focus"
        portrait.type = "focus"
        portrait.db = EdiUI.db.profile.focus
        portrait.size = EdiUI.db.profile.focus.size
        portrait.point = EdiUI.db.profile.focus.point
        portrait.useClassIcon = EdiUI.db.profile.misc.class_icon ~= "none"
        portrait.realUnit = "focus"
        
        portrait.isPlayer = nil
        portrait.unitClass = nil
        portrait.lastGUID = nil
        
        self:UpdateTexturesFiles(portrait, EdiUI.db.profile.focus)
        self:UpdateSize(portrait)
        self:UpdateCastSettings(portrait)
        self:InitPortrait(portrait, standardEvents)
    end
end

function Portraits:InitializePetPortrait()
    if not EdiUI.db.profile.pet.enable then return end
    
    local frameName = self:GetUnitFrame("pet")
    if not frameName then return end
    
    local parent = _G[frameName]
    if not parent then return end
    
    self.PortraitFrames.pet = self.PortraitFrames.pet or self:CreatePortrait("pet", parent)
    
    local portrait = self.PortraitFrames.pet
    if portrait then
        portrait.events = {}
        portrait.parentFrame = parent
        portrait.unit = "pet"
        portrait.type = "pet"
        portrait.db = EdiUI.db.profile.pet
        portrait.size = EdiUI.db.profile.pet.size
        portrait.point = EdiUI.db.profile.pet.point
        portrait.useClassIcon = EdiUI.db.profile.misc.class_icon ~= "none"
        portrait.realUnit = "pet"
        
        portrait.isPlayer = nil
        portrait.unitClass = nil
        portrait.lastGUID = nil
        
        self:UpdateTexturesFiles(portrait, EdiUI.db.profile.pet)
        self:UpdateSize(portrait)
        self:UpdateCastSettings(portrait)
        self:InitPortrait(portrait, standardEvents)
    end
end

function Portraits:InitializeTargetTargetPortrait()
    if not EdiUI.db.profile.targettarget.enable then return end
    
    local frameName = self:GetUnitFrame("targettarget")
    if not frameName then return end
    
    local parent = _G[frameName]
    if not parent then return end
    
    self.PortraitFrames.targettarget = self.PortraitFrames.targettarget or self:CreatePortrait("targettarget", parent)
    
    local portrait = self.PortraitFrames.targettarget
    if portrait then
        portrait.events = {}
        portrait.parentFrame = parent
        portrait.unit = "targettarget"
        portrait.type = "targettarget"
        portrait.db = EdiUI.db.profile.targettarget
        portrait.size = EdiUI.db.profile.targettarget.size
        portrait.point = EdiUI.db.profile.targettarget.point
        portrait.useClassIcon = EdiUI.db.profile.misc.class_icon ~= "none"
        portrait.realUnit = "targettarget"
        
        portrait.isPlayer = nil
        portrait.unitClass = nil
        portrait.lastGUID = nil
        
        self:UpdateTexturesFiles(portrait, EdiUI.db.profile.targettarget)
        self:UpdateSize(portrait)
        self:UpdateCastSettings(portrait)
        self:InitPortrait(portrait, standardEvents)
    end
end

function Portraits:InitializeBossPortrait()
    if not EdiUI.db.profile.boss.enable then return end
    
    local bossFrameBase = self:GetUnitFrame("boss")
    if not bossFrameBase then return end
    
    for i = 1, 5 do
        local frameName = bossFrameBase .. i
        local parent = _G[frameName]
        
        if parent then
            local key = "boss" .. i
            self.PortraitFrames[key] = self.PortraitFrames[key] or self:CreatePortrait(key, parent)
            
            local portrait = self.PortraitFrames[key]
            if portrait then
                portrait.events = {}
                portrait.parentFrame = parent
                portrait.unit = key
                portrait.type = "boss"
                portrait.db = EdiUI.db.profile.boss
                portrait.size = EdiUI.db.profile.boss.size
                portrait.point = EdiUI.db.profile.boss.point
                portrait.useClassIcon = EdiUI.db.profile.misc.class_icon ~= "none"
                portrait.realUnit = key
                
                portrait.isPlayer = nil
                portrait.unitClass = nil
                portrait.lastGUID = nil
                
                self:UpdateTexturesFiles(portrait, EdiUI.db.profile.boss)
                self:UpdateSize(portrait)
                self:UpdateCastSettings(portrait)
                self:InitPortrait(portrait, standardEvents)
            end
        end
    end
end

-- ============================================================================
-- KILL PORTRAIT FUNCTIONS
-- ============================================================================
function Portraits:KillPlayerPortrait()
    if self.PortraitFrames.player then
        self:RemovePortrait(self.PortraitFrames.player)
        self.PortraitFrames.player = nil
    end
end

function Portraits:KillTargetPortrait()
    if self.PortraitFrames.target then
        self:RemovePortrait(self.PortraitFrames.target)
        self.PortraitFrames.target = nil
    end
end

function Portraits:KillFocusPortrait()
    if self.PortraitFrames.focus then
        self:RemovePortrait(self.PortraitFrames.focus)
        self.PortraitFrames.focus = nil
    end
end

function Portraits:KillPetPortrait()
    if self.PortraitFrames.pet then
        self:RemovePortrait(self.PortraitFrames.pet)
        self.PortraitFrames.pet = nil
    end
end

function Portraits:KillTargetTargetPortrait()
    if self.PortraitFrames.targettarget then
        self:RemovePortrait(self.PortraitFrames.targettarget)
        self.PortraitFrames.targettarget = nil
    end
end

function Portraits:KillBossPortrait()
    for i = 1, 5 do
        local key = "boss" .. i
        if self.PortraitFrames[key] then
            self:RemovePortrait(self.PortraitFrames[key])
            self.PortraitFrames[key] = nil
        end
    end
end

-- ============================================================================
-- LOAD ALL PORTRAITS
-- ============================================================================
function Portraits:LoadPortraits()
    if InCombatLockdown() then
        C_Timer.After(1, function()
            Portraits:LoadPortraits()
        end)
        return
    end
    
    self:InitializePlayerPortrait()
    self:InitializeTargetPortrait()
    self:InitializeFocusPortrait()
    self:InitializePetPortrait()
    self:InitializeTargetTargetPortrait()
    self:InitializeBossPortrait()
end

-- ============================================================================
-- INITIALIZE MODULE
-- ============================================================================
function Portraits:Initialize()
    -- Check if a supported UI is available
    if not EdiUI:GetActiveUI() then
        EdiUI:Print("No supported UI detected (ElvUI required)")
        return
    end
    
    -- Load portraits after a delay to ensure UI frames are created
    C_Timer.After(1, function()
        self:LoadPortraits()
    end)
    
    -- Periodic refresh to catch frames that load late
    C_Timer.NewTicker(2, function()
        self:LoadPortraits()
    end, 5) -- Run 5 times over 10 seconds then stop
end
