-- EdiUI Profile Import/Export
-- Allows sharing profile settings via copy/paste strings
-- Based on NephUI's implementation using AceSerializer-3.0 + LibDeflate
local EdiUI = EdiUI

local Profiles = {}
EdiUI.Profiles = Profiles

-- Libraries (loaded lazily)
local AceSerializer, LibDeflate

local function GetLibraries()
    if not AceSerializer then
        local stub = LibStub or _G.LibStub
        if stub then
            AceSerializer = stub("AceSerializer-3.0", true)
        end
    end
    if not LibDeflate then
        local stub = LibStub or _G.LibStub
        if stub then
            LibDeflate = stub("LibDeflate", true)
        end
    end
    if not AceSerializer or not LibDeflate then
        return nil, nil
    end
    return AceSerializer, LibDeflate
end

-- Version prefix for import validation
local EXPORT_PREFIX = "EdiUI1:"

-- Export current profile to a string
function Profiles:Export()
    local AS, LD = GetLibraries()
    if not AS then
        return nil, "AceSerializer-3.0 library not found. Make sure Ace3 is loaded."
    end
    if not LD then
        return nil, "LibDeflate library not found. Make sure it's loaded."
    end

    local profile = EdiUI.db and EdiUI.db.profile
    if not profile then
        return nil, "No profile loaded. Try reloading the UI."
    end

    -- Serialize using AceSerializer
    local ok, serialized = pcall(AS.Serialize, AS, profile)
    if not ok or not serialized or type(serialized) ~= "string" then
        return nil, "Failed to serialize profile: " .. tostring(serialized)
    end

    -- Compress
    ok, compressed = pcall(LD.CompressDeflate, LD, serialized)
    if not ok or not compressed then
        return nil, "Failed to compress profile: " .. tostring(compressed)
    end

    -- Encode for safe copy/paste (printable characters only)
    ok, encoded = pcall(LD.EncodeForPrint, LD, compressed)
    if not ok or not encoded then
        return nil, "Failed to encode profile: " .. tostring(encoded)
    end

    return EXPORT_PREFIX .. encoded
end

-- Deep copy helper function
local function DeepCopy(src, dst)
    if type(src) ~= "table" then
        return
    end
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then
                dst[k] = {}
            else
                -- Clear existing table
                for key in pairs(dst[k]) do
                    dst[k][key] = nil
                end
            end
            DeepCopy(v, dst[k])
        else
            dst[k] = v
        end
    end
end

-- Import profile from a string
function Profiles:Import(importString)
    local AS, LD = GetLibraries()
    if not AS or not LD then
        return false, "Required libraries not found. Please /reload and try again."
    end

    if not importString or importString == "" then
        return false, "No import string provided"
    end

    -- Clean up whitespace
    importString = importString:gsub("%s+", "")

    -- Check and remove prefix
    if not importString:find("^EdiUI1:") then
        return false, "Invalid format. String must start with 'EdiUI1:'"
    end

    local encoded = importString:gsub("^EdiUI1:", "")

    -- Decode
    local ok, compressed = pcall(LD.DecodeForPrint, LD, encoded)
    if not ok or not compressed then
        return false, "Could not decode string (corrupted or invalid format)"
    end

    -- Decompress
    ok, serialized = pcall(LD.DecompressDeflate, LD, compressed)
    if not ok or not serialized then
        return false, "Could not decompress data (corrupted)"
    end

    -- Deserialize using AceSerializer
    ok, importedData = pcall(AS.Deserialize, AS, serialized)
    if not ok or type(importedData) ~= "table" then
        return false, "Could not deserialize profile (incompatible format)"
    end
    
    -- Apply to current profile using deep copy
    local profile = EdiUI.db and EdiUI.db.profile
    if not profile then
        return false, "No profile to import into"
    end

    -- Clear existing profile
    for k in pairs(profile) do
        profile[k] = nil
    end

    -- Deep copy imported values
    DeepCopy(importedData, profile)

    -- Trigger all module updates
    if EdiUI.db then
        -- Fire OnProfileChanged to notify all modules
        if EdiUI.db.callbacks and EdiUI.db.callbacks.Fire then
            EdiUI.db.callbacks:Fire("OnProfileChanged", EdiUI.db)
        end

        -- Refresh all modules
        for name, module in EdiUI:IterateModules() do
            if module.UpdateAll then
                pcall(module.UpdateAll, module)
            elseif module.Refresh then
                pcall(module.Refresh, module)
            elseif module.Update then
                pcall(module.Update, module)
            end
        end
    end

    return true, "Profile imported successfully! Please /reload to apply all changes."
end

-- Validate an import string without applying it
function Profiles:Validate(importString)
    local AS, LD = GetLibraries()
    if not AS or not LD then
        return false, "Libraries not loaded"
    end
    
    if not importString or importString == "" then
        return false, "Empty string"
    end
    
    -- Clean up whitespace
    importString = importString:gsub("%s+", "")
    
    if not importString:find("^EdiUI1:") then
        return false, "Invalid format"
    end
    
    local encoded = importString:gsub("^EdiUI1:", "")
    local compressed = LD:DecodeForPrint(encoded)
    if not compressed then
        return false, "Decode failed"
    end
    
    local serialized = LD:DecompressDeflate(compressed)
    if not serialized then
        return false, "Decompress failed"
    end
    
    local ok, data = AS:Deserialize(serialized)
    if not ok or type(data) ~= "table" then
        return false, "Deserialize failed"
    end
    
    return true, "Valid EdiUI profile string"
end

-- Check if libraries are available
function Profiles:LibrariesAvailable()
    local AS, LD = GetLibraries()
    return AS ~= nil and LD ~= nil
end

-- Test export/import system
function Profiles:Test()
    EdiUI:Print("Testing profile export/import system...")

    -- Check libraries
    local AS, LD = GetLibraries()
    if not AS then
        EdiUI:Print("|cffff0000ERROR: AceSerializer-3.0 not found!|r")
        return false
    else
        EdiUI:Print("|cff00ff00OK: AceSerializer-3.0 loaded|r")
    end

    if not LD then
        EdiUI:Print("|cffff0000ERROR: LibDeflate not found!|r")
        return false
    else
        EdiUI:Print("|cff00ff00OK: LibDeflate loaded|r")
    end

    -- Test export
    local exportStr, exportErr = self:Export()
    if not exportStr then
        EdiUI:Print("|cffff0000ERROR: Export failed: " .. tostring(exportErr) .. "|r")
        return false
    else
        EdiUI:Print("|cff00ff00OK: Export successful (" .. #exportStr .. " characters)|r")
    end

    -- Test validation
    local validOk, validErr = self:Validate(exportStr)
    if not validOk then
        EdiUI:Print("|cffff0000ERROR: Validation failed: " .. tostring(validErr) .. "|r")
        return false
    else
        EdiUI:Print("|cff00ff00OK: Validation successful|r")
    end

    EdiUI:Print("|cff00ff00All tests passed! Export/import system is working.|r")
    return true
end

local TryImportWithFunctions

function Profiles:ImportElvUIProfile()
    local str = self.ImportStrings and self.ImportStrings["ElvUI"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    local E = _G.ElvUI and unpack(_G.ElvUI) or nil
    if not E then
        return false, "ElvUI not loaded. Enable ElvUI and reload."
    end

    local DI = E.Distributor
    if not DI then
        return false, "ElvUI Distributor module not found."
    end

    -- Decode the import string
    local profileType, profileKey, data = DI:Decode(str)
    if not data or type(data) ~= "table" then
        return false, "Failed to decode ElvUI profile string."
    end

    -- Import the profile
    DI:SetImportedProfile(profileType, "EdiUI", data, true)

    return true
end

function Profiles:ImportElvUIDarkProfile()
    local str = self.ImportStrings and self.ImportStrings["ElvUIDark"]
    if not str or str == "" then
        return false, "Missing ElvUI Dark import string"
    end

    local E = _G.ElvUI and unpack(_G.ElvUI) or nil
    if not E then
        return false, "ElvUI not loaded. Enable ElvUI and reload."
    end

    local DI = E.Distributor
    if not DI then
        return false, "ElvUI Distributor module not found."
    end

    -- Decode the import string
    local profileType, profileKey, data = DI:Decode(str)
    if not data or type(data) ~= "table" then
        return false, "Failed to decode ElvUI Dark profile string."
    end

    -- Import the profile
    DI:SetImportedProfile(profileType, "EdiUI_Dark", data, true)

    return true
end

local function GetElvUIAndDistributor()
    local E = _G.ElvUI and unpack(_G.ElvUI) or nil
    if not E then
        return nil, nil
    end
    return E, E.Distributor
end

function Profiles:ImportElvUIAuras()
    local str = self.ImportStrings and self.ImportStrings["ElvUIAuras"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    local E, DI = GetElvUIAndDistributor()
    if not E or not DI then
        return false, "ElvUI not loaded. Enable ElvUI and reload."
    end

    local profileType, profileKey, data = DI:Decode(str)
    if not data or type(data) ~= "table" then
        return false, "Failed to decode ElvUI Auras string."
    end

    DI:SetImportedProfile(profileType, "EdiUI", data, true)
    return true
end

function Profiles:ImportElvUIPrivate()
    local str = self.ImportStrings and self.ImportStrings["ElvUIPrivate"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    local E, DI = GetElvUIAndDistributor()
    if not E or not DI then
        return false, "ElvUI not loaded. Enable ElvUI and reload."
    end

    local profileType, profileKey, data = DI:Decode(str)
    if not data or type(data) ~= "table" then
        return false, "Failed to decode ElvUI Private string."
    end

    DI:SetImportedProfile(profileType, "EdiUI", data, true)
    return true
end

function Profiles:ImportElvUIGlobal()
    local str = self.ImportStrings and self.ImportStrings["ElvUIGlobal"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    local E, DI = GetElvUIAndDistributor()
    if not E or not DI then
        return false, "ElvUI not loaded. Enable ElvUI and reload."
    end

    local profileType, profileKey, data = DI:Decode(str)
    if not data or type(data) ~= "table" then
        return false, "Failed to decode ElvUI Global string."
    end

    DI:SetImportedProfile(profileType, "EdiUI", data, true)
    return true
end

function Profiles:ImportDetailsProfile()
    local str = self.ImportStrings and self.ImportStrings["Details"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    local details = _G.Details or _G._detalhes
    if not details then
        return false, "Details! not loaded. Enable Details! and reload."
    end

    -- Details import signature: ImportProfile(string, profileName, runTutorial, autoSwitch, useExactName)
    if type(details.ImportProfile) == "function" then
        local ok, result = pcall(details.ImportProfile, details, str, "EdiUI", false, false, true)
        if ok then
            return true
        end
        return false, "Details! import failed: " .. tostring(result)
    end

    return false, "Details! ImportProfile function not found"
end

function Profiles:ImportPlaterProfile()
    local str = self.ImportStrings and self.ImportStrings["Plater"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    local Plater = _G.Plater
    if not Plater then
        return false, "Plater not loaded. Enable Plater and reload."
    end

    -- Use Plater's own DecompressData to get the profile table
    if type(Plater.DecompressData) ~= "function" then
        return false, "Plater.DecompressData not available"
    end

    local data = Plater.DecompressData(str, "print")
    if not data or type(data) ~= "table" then
        return false, "Failed to decompress Plater profile"
    end

    -- Check if data is wrapped (some exports use { profile = {...}, type = "profile" })
    if data.profile and type(data.profile) == "table" and data.profile.plate_config then
        data = data.profile
    end

    -- Verify we have valid profile data
    if not data.plate_config then
        return false, "Invalid profile: missing plate_config"
    end

    -- Import using Plater's native function (same as NaowhUI)
    if type(Plater.ImportAndSwitchProfile) ~= "function" then
        return false, "Plater.ImportAndSwitchProfile not available"
    end

    local ok, err = pcall(function()
        Plater.ImportAndSwitchProfile("EdiUI", data, false, false, true, true)
    end)

    if not ok then
        return false, "Import failed: " .. tostring(err)
    end

    -- Refresh after import
    C_Timer.After(0.5, function()
        if Plater.ImportScriptsFromLibrary then
            pcall(Plater.ImportScriptsFromLibrary)
        end
        if Plater.ApplyPatches then
            pcall(Plater.ApplyPatches)
        end
        if Plater.RefreshConfig then
            pcall(Plater.RefreshConfig, Plater)
        end
    end)

    return true
end

function Profiles:ImportWarpDepleteProfile()
    -- Check if WarpDeplete is loaded
    if not _G.WarpDeplete or not _G.WarpDepleteDB then
        return false, "WarpDeplete not loaded. Enable WarpDeplete and reload."
    end

    -- Get our profile data
    local profileData = self.WarpDepleteData
    if not profileData then
        return false, "WarpDeplete profile data not found."
    end

    -- Copy profile data to WarpDepleteDB
    if not _G.WarpDepleteDB.profiles then
        _G.WarpDepleteDB.profiles = {}
    end

    -- Deep copy the profile
    local function DeepCopyProfile(src)
        if type(src) ~= "table" then return src end
        local copy = {}
        for k, v in pairs(src) do
            copy[k] = DeepCopyProfile(v)
        end
        return copy
    end

    _G.WarpDepleteDB.profiles.EdiUI = DeepCopyProfile(profileData)

    -- Set the profile as active
    local WD = _G.WarpDeplete
    if WD.db and WD.db.SetProfile then
        WD.db:SetProfile("EdiUI")
    end

    -- Trigger WarpDeplete to refresh its UI with new settings
    -- WarpDeplete uses AceDB callbacks, but we may need to manually refresh
    if WD.OnProfileChanged then
        WD:OnProfileChanged()
    elseif WD.Refresh then
        WD:Refresh()
    elseif WD.UpdateLayout then
        WD:UpdateLayout()
    elseif WD.ApplySettings then
        WD:ApplySettings()
    end

    -- Also try to update font objects directly if the display exists
    if WD.frames and WD.frames.root then
        -- Force a visual update by hiding/showing
        local wasShown = WD.frames.root:IsShown()
        if wasShown then
            WD.frames.root:Hide()
            C_Timer.After(0.1, function()
                WD.frames.root:Show()
            end)
        end
    end

    return true, "Profile applied. You may need to /reload for fonts to fully apply."
end

function Profiles:ImportBigWigsProfile()
    local str = self.ImportStrings and self.ImportStrings["BigWigs"]
    if not str or str == "" then
        return false, "Missing import string"
    end

    -- BigWigs is Load-on-Demand, try to force-load it
    local BW = _G.BigWigs
    if not BW then
        -- Check if BigWigs is enabled (might not be loaded yet)
        local bigwigsEnabled = false
        if C_AddOns then
            local name = C_AddOns.GetAddOnInfo("BigWigs")
            if name then
                local enableState = C_AddOns.GetAddOnEnableState("BigWigs")
                bigwigsEnabled = (enableState == 2) or (enableState == 1)
            end
        end

        if not bigwigsEnabled then
            return false, "BigWigs not enabled. Enable it in AddOns and reload."
        end

        -- Try to force-load BigWigs (order matters for dependencies)
        local loadFunc = (C_AddOns and C_AddOns.LoadAddOn) or LoadAddOn
        if loadFunc then
            loadFunc("BigWigs")
            loadFunc("BigWigs_Core")
            loadFunc("BigWigs_Plugins")
            loadFunc("BigWigs_Options")
        end

        -- Check again after loading
        BW = _G.BigWigs
        if not BW then
            return false, "BigWigs failed to load. Try entering a dungeon first, then retry."
        end
    end

    -- Ensure BigWigs is fully initialized
    local loader = _G.BigWigsLoader
    if loader and loader.LoadAddOn then
        -- This triggers BigWigs initialization
        loader:LoadAddOn("BigWigs_Options")
    end

    -- BigWigs uses LibSerialize + LibDeflate with "BW2:" prefix
    if not str:find("^BW2:") then
        return false, "Invalid BigWigs profile format"
    end

    -- Method 1: Try BigWigsOptions import (most reliable)
    local BWOptions = _G.BigWigsOptions
    if BWOptions then
        -- BigWigsOptions has import functionality
        if type(BWOptions.ImportProfile) == "function" then
            local ok, result = pcall(BWOptions.ImportProfile, BWOptions, str)
            if ok then
                return true
            end
        end
        -- Try through SendMessage
        if type(BWOptions.SendMessage) == "function" then
            local ok = pcall(BWOptions.SendMessage, BWOptions, "BigWigs_ProfileImport", str)
            if ok then
                return true
            end
        end
    end

    -- Method 2: Try BigWigsLoader
    local loader = _G.BigWigsLoader
    if loader and type(loader.ImportProfile) == "function" then
        local ok, result = pcall(loader.ImportProfile, loader, str)
        if ok then
            return true
        end
    end

    -- Method 3: Manual decode - try multiple library sources
    local LS, LD
    local loader = _G.BigWigsLoader

    -- Try BigWigsLoader's internal references first (most reliable after loading)
    if loader then
        LS = loader.Serialize
        LD = loader.Deflate
    end

    -- Try LibStub
    if not LS and LibStub then
        LS = LibStub("LibSerialize", true)
        LD = LibStub("LibDeflate", true)
    end

    -- Try BigWigs' embedded libraries
    if not LS and BW and BW.GetLib then
        LS = BW:GetLib("LibSerialize")
        LD = BW:GetLib("LibDeflate")
    end

    -- Try global references
    if not LS then
        LS = _G.LibSerialize
        LD = _G.LibDeflate
    end

    -- Try through AceAddon
    if not LS and _G.AceAddon then
        local aceAddon = _G.AceAddon:GetAddon("BigWigs", true)
        if aceAddon and aceAddon.Serialize then
            LS = aceAddon.Serialize
            LD = aceAddon.Deflate
        end
    end

    if LS and LD then
        local encoded = str:gsub("^BW2:", "")
        local decoded = LD:DecodeForPrint(encoded)
        if decoded then
            local decompressed = LD:DecompressDeflate(decoded)
            if decompressed then
                local ok, data = LS:Deserialize(decompressed)
                if ok and type(data) == "table" then
                    -- Apply to BigWigs3DB directly
                    local db = _G.BigWigs3DB
                    if db then
                        -- Create EdiUI profile
                        db.profiles = db.profiles or {}
                        db.profiles["EdiUI"] = data

                        -- Switch to the profile
                        if BW.db and BW.db.SetProfile then
                            BW.db:SetProfile("EdiUI")
                        else
                            -- Set as current profile manually
                            local charKey = UnitName("player") .. " - " .. GetRealmName()
                            db.profileKeys = db.profileKeys or {}
                            db.profileKeys[charKey] = "EdiUI"
                        end
                        return true
                    end

                    -- Fallback: write to BW.db.profile directly
                    if BW.db and BW.db.profile then
                        for k, v in pairs(data) do
                            BW.db.profile[k] = v
                        end
                        return true
                    end
                end
            end
        end
        return false, "Failed to decode BigWigs profile"
    end

    -- Method 4: Direct SavedVariable write (reload required)
    local encoded = str:gsub("^BW2:", "")

    -- Store for later application
    EdiUI.pendingBigWigsImport = str
    _G.BigWigs3DB = _G.BigWigs3DB or {}
    _G.BigWigs3DB.pendingImport = str

    return false, "BigWigs libraries not available. Profile saved - do /reload and retry."
end

function Profiles:ImportEditModeProfile()
    local str = self.ImportStrings and self.ImportStrings["EditMode"]
    if not str or str == "" then
        return false, "Missing import string"
    end
    if InCombatLockdown and InCombatLockdown() then
        return false, "Cannot import Edit Mode in combat"
    end

    if C_AddOns and C_AddOns.LoadAddOn then
        pcall(C_AddOns.LoadAddOn, "Blizzard_EditMode")
    elseif UIParentLoadAddOn then
        pcall(UIParentLoadAddOn, "Blizzard_EditMode")
    end

    local function GetLayoutsSnapshot()
        if _G.C_EditMode and type(_G.C_EditMode.GetLayouts) == "function" then
            local info = _G.C_EditMode.GetLayouts()
            if type(info) == "table" and type(info.layouts) == "table" then
                return info
            end
        end
        return nil
    end

    local function GetLayoutSignature(layout)
        if type(layout) ~= "table" then
            return nil
        end
        return layout.layoutName or layout.name or layout.layoutID or layout.layoutIndex or layout.id
    end

    local function BuildLayoutSet(layouts)
        local set = {}
        if type(layouts) == "table" then
            for _, layout in ipairs(layouts) do
                local sig = GetLayoutSignature(layout)
                if sig ~= nil then
                    set[sig] = true
                end
            end
        end
        return set
    end

    local function FindNewLayoutIndex(beforeInfo, afterInfo)
        if not afterInfo or type(afterInfo.layouts) ~= "table" then
            return nil
        end

        local beforeSet = BuildLayoutSet(beforeInfo and beforeInfo.layouts)
        for index, layout in ipairs(afterInfo.layouts) do
            local sig = GetLayoutSignature(layout)
            if sig and not beforeSet[sig] then
                return layout.layoutIndex or layout.id or layout.layoutID or index
            end
        end

        if beforeInfo and type(beforeInfo.layouts) == "table" then
            if #afterInfo.layouts > #beforeInfo.layouts then
                local layout = afterInfo.layouts[#afterInfo.layouts]
                if layout then
                    return layout.layoutIndex or layout.id or layout.layoutID or #afterInfo.layouts
                end
            end
        end

        return nil
    end

    local function TryActivateLayout(layoutIndex)
        if not layoutIndex then
            return false
        end
        if _G.C_EditMode and type(_G.C_EditMode.SetActiveLayout) == "function" then
            local ok = pcall(_G.C_EditMode.SetActiveLayout, layoutIndex)
            if ok then
                return true
            end
        end
        if _G.EditModeManagerFrame then
            if type(_G.EditModeManagerFrame.SelectLayout) == "function" then
                local ok = pcall(_G.EditModeManagerFrame.SelectLayout, _G.EditModeManagerFrame, layoutIndex)
                if ok then
                    return true
                end
            elseif type(_G.EditModeManagerFrame.ActivateLayout) == "function" then
                local ok = pcall(_G.EditModeManagerFrame.ActivateLayout, _G.EditModeManagerFrame, layoutIndex)
                if ok then
                    return true
                end
            end
        end
        return false
    end

    local function FindEditBox(frame, depth, visited)
        if not frame then return nil end
        if frame.IsObjectType and frame:IsObjectType("EditBox") then
            return frame
        end
        if not depth or depth <= 0 then
            return nil
        end
        visited = visited or {}
        if visited[frame] then
            return nil
        end
        visited[frame] = true

        if frame.GetChildren then
            for child in frame:GetChildren() do
                local found = FindEditBox(child, depth - 1, visited)
                if found then return found end
            end
        end
        if frame.GetRegions then
            for region in frame:GetRegions() do
                local found = FindEditBox(region, depth - 1, visited)
                if found then return found end
            end
        end
        if frame.GetScrollChild then
            local scrollChild = frame:GetScrollChild()
            local found = FindEditBox(scrollChild, depth - 1, visited)
            if found then return found end
        end
        return nil
    end

    local function FindButton(frame)
        if not frame or not frame.GetChildren then return nil end
        local preferredLabels = {
            ["Import"] = true,
            ["OK"] = true,
            ["Okay"] = true,
            ["Accept"] = true,
        }
        local firstButton
        for child in frame:GetChildren() do
            if child.IsObjectType and child:IsObjectType("Button") then
                firstButton = firstButton or child
                if child.GetText then
                    local text = child:GetText()
                    if text and preferredLabels[text] then
                        return child
                    end
                end
            end
        end
        return firstButton
    end

    local function TryImportViaDialog(importString)
        local dialog = _G.EditModeImportLayoutDialog

        if not dialog then
            return false, "Edit Mode import dialog not available. Open Edit Mode once and retry."
        end

        local importBox = nil
        if dialog.ImportBox then
            if dialog.ImportBox.IsObjectType and dialog.ImportBox:IsObjectType("EditBox") then
                importBox = dialog.ImportBox
            elseif dialog.ImportBox.EditBox then
                importBox = dialog.ImportBox.EditBox
            elseif dialog.ImportBox.GetScrollChild then
                importBox = dialog.ImportBox:GetScrollChild()
            end
        end
        importBox = importBox or dialog.ImportLayoutEditBox or dialog.ImportStringEditBox or dialog.ImportEditBox or dialog.EditBox
        if importBox and importBox.IsObjectType and not importBox:IsObjectType("EditBox") then
            importBox = FindEditBox(importBox, 4)
        end
        if not importBox then
            importBox = FindEditBox(dialog, 4)
        end
        if importBox and importBox.SetText then
            importBox:SetText(importString)
        else
            return false, "Import dialog missing input"
        end

        local nameBox = dialog.LayoutNameEditBox or dialog.NameEditBox or dialog.LayoutNameBox
        if nameBox and nameBox.SetText then
            nameBox:SetText("EdiUI")
        end

        local charSpecific = dialog.CharacterSpecificLayoutCheckButton or dialog.CharacterSpecificCheckButton
        if charSpecific then
            local button = charSpecific.Button or charSpecific.CheckButton or charSpecific
            if button and button.SetChecked then
                button:SetChecked(true)
            end
        end

        local accept = dialog.AcceptButton or dialog.ImportButton or dialog.OkayButton or dialog.OKButton
        if not accept then
            accept = FindButton(dialog)
        end

        if accept and accept.Click then
            accept:Click()
            return true
        end

        if accept and accept.GetScript then
            local handler = accept:GetScript("OnClick")
            if handler then
                pcall(handler, accept)
                return true
            end
        end

        return false, "Import dialog missing accept button"
    end

    local beforeInfo = GetLayoutsSnapshot()
    local lastErr
    local importResult
    if _G.C_EditMode and type(_G.C_EditMode.ImportLayout) == "function" then
        local ok, err = pcall(_G.C_EditMode.ImportLayout, str)
        if ok and err == false then
            lastErr = "Import returned false"
        elseif ok then
            importResult = err
        else
            lastErr = err
        end
    end

    if _G.EditModeManagerFrame and type(_G.EditModeManagerFrame.ImportLayout) == "function" then
        local ok, err = pcall(_G.EditModeManagerFrame.ImportLayout, _G.EditModeManagerFrame, str)
        if ok and err == false then
            return false, "Import returned false"
        end
        if ok then
            importResult = err
        else
            return false, err
        end
    end

    if not importResult then
        local ok, err = TryImportViaDialog(str)
        if ok then
            importResult = true
        else
            if lastErr then
                return false, lastErr
            end
            return false, err or "EditMode import API not found"
        end
    end

    local afterInfo = GetLayoutsSnapshot()
    local layoutIndex
    if type(importResult) == "number" then
        layoutIndex = importResult
    elseif type(importResult) == "table" then
        layoutIndex = importResult.layoutIndex or importResult.id or importResult.layoutID
    end

    if not layoutIndex then
        layoutIndex = FindNewLayoutIndex(beforeInfo, afterInfo)
    end

    if layoutIndex and TryActivateLayout(layoutIndex) then
        return true
    end

    if beforeInfo and afterInfo and beforeInfo.activeLayout and afterInfo.activeLayout then
        if beforeInfo.activeLayout ~= afterInfo.activeLayout then
            return true
        end
    end

    return false, "Layout imported but could not activate. Please select it in Edit Mode."
end

TryImportWithFunctions = function(target, funcNames, importString)
    if not target then
        return false, "Target not available"
    end

    for _, funcName in ipairs(funcNames) do
        local func = target[funcName]
        if type(func) == "function" then
            local ok, result = pcall(func, target, importString)
            if ok and result == false then
                return false, "Import returned false via " .. funcName
            elseif ok then
                return true
            end
            return false, result or ("Import failed via " .. funcName)
        end
    end

    return false, "No supported import function found"
end

function Profiles:InstallAddonStrings()
    if not self.ImportStrings then
        EdiUI:Print("No addon strings available.")
        return
    end

    local results = {}

    local function RecordResult(name, ok, err)
        results[#results + 1] = { name = name, ok = ok, err = err }
    end

    -- ElvUI
    do
        local name = "ElvUI"
        local ok, err = self:ImportElvUIProfile()
        RecordResult(name, ok, err)
    end

    -- Details!
    do
        local name = "Details"
        local ok, err = self:ImportDetailsProfile()
        RecordResult(name, ok, err)
    end

    -- Plater
    do
        local name = "Plater"
        local ok, err = self:ImportPlaterProfile()
        RecordResult(name, ok, err)
    end

    -- Blizzard EditMode
    do
        local name = "EditMode"
        local ok, err = self:ImportEditModeProfile()
        RecordResult(name, ok, err)
    end

    -- WarpDeplete
    do
        local name = "WarpDeplete"
        local ok, err = self:ImportWarpDepleteProfile()
        RecordResult(name, ok, err)
    end

    -- BigWigs
    do
        local name = "BigWigs"
        local ok, err = self:ImportBigWigsProfile()
        RecordResult(name, ok, err)
    end

    for _, result in ipairs(results) do
        if result.ok then
            EdiUI:Print(result.name .. ": import applied.")
        else
            EdiUI:Print(result.name .. ": import failed (" .. (result.err or "unknown error") .. ").")
        end
    end

    EdiUI:Print("Install finished. A /reload is recommended for changes to fully apply.")
end
