-- EdiUI Class Bar Options
local EdiUI = EdiUI

local function BuildClassBarOptions(parent)
    EdiUI:ResetLayout()

    EdiUI:AddHeader(parent, "Class Bar")
    EdiUI:AddDescription(parent, "Control the class resource bar shown above the power bar.")
    EdiUI:AddSpacer(parent, 10)

    local db = EdiUI.db.profile.classBar
    if not db then
        db = {}
        EdiUI.db.profile.classBar = db
    end

    if db.enabled == nil then db.enabled = true end
    if not db.width then db.width = 220 end
    if not db.height then db.height = 12 end
    if not db.spacing then db.spacing = 2 end
    if db.offsetX == nil then db.offsetX = 0 end
    if db.offsetY == nil then db.offsetY = 6 end
    if db.matchEssentials == nil then db.matchEssentials = true end
    if not db.texture then db.texture = "ElvUI Norm" end
    if db.usePowerColor == nil then db.usePowerColor = true end
    if not db.color then db.color = { r = 0.906, g = 0.298, b = 0.235 } end

    local bar = EdiUI:GetModule("ClassBar", true)
    local function Apply()
        if bar and bar.UpdateAll then
            bar:UpdateAll()
        end
    end

    local function BuildTextureList()
        local textures = {}
        local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
        if E and E.Libs and E.Libs.LSM then
            for name in pairs(E.Libs.LSM:HashTable("statusbar")) do
                textures[name] = name
            end
        end
        if next(textures) == nil and db.texture then
            textures[db.texture] = db.texture
        end
        return textures
    end

    local function AddPanel(title, buildFunc)
        local startYOffset = EdiUI:GetCurrentYOffset()
        local panel = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 6, -startYOffset)
        panel:SetPoint("TOPRIGHT", -6, -startYOffset)
        panel:SetHeight(1)

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyFrame(panel, 'Transparent')
        else
            panel:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            panel:SetBackdropColor(0.05, 0.05, 0.07, 1)
            panel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local outerYOffset = EdiUI:GetCurrentYOffset()
        EdiUI:SetCurrentYOffset(12)
        EdiUI:AddHeader(panel, title)
        EdiUI:AddSpacer(panel, 8)
        buildFunc(panel)
        local panelHeight = EdiUI:GetCurrentYOffset() + 12
        panel:SetHeight(panelHeight)
        EdiUI:SetCurrentYOffset(outerYOffset + panelHeight + 18)
    end

    parent.__ediWidthStateCallbacks = parent.__ediWidthStateCallbacks or {}
    AddPanel("Settings", function(panel)
        EdiUI:AddCheckbox(panel, "Enabled", "Show the class resource bar.",
            function() return db.enabled end,
            function(val) db.enabled = val Apply() end
        )
        EdiUI:AddCheckbox(panel, "Match Essentials Width", "Match Essentials cooldown width.",
            function() return db.matchEssentials end,
            function(val)
                db.matchEssentials = val
                Apply()
                for _, cb in ipairs(parent.__ediWidthStateCallbacks or {}) do
                    cb()
                end
            end
        )
    end)

    AddPanel("Size & Position", function(panel)
        local widthSlider = EdiUI:AddSliderBare(panel, "Width", "Bar width", 120, 700, 1,
            function() return db.width end,
            function(val) db.width = val Apply() end
        )
        local function UpdateWidthState()
            local disabled = db.matchEssentials
            if widthSlider and widthSlider.SetEnabled then
                widthSlider:SetEnabled(not disabled)
            end
            local text = widthSlider and widthSlider.Text or nil
            if text then
                text:SetTextColor(disabled and 0.5 or 1, disabled and 0.5 or 0.78, disabled and 0.5 or 0.29)
            end
            if widthSlider and widthSlider.Edit then
                widthSlider.Edit:SetTextColor(disabled and 0.5 or 1, disabled and 0.5 or 0.78, disabled and 0.5 or 0.29)
            end
        end
        UpdateWidthState()
        EdiUI:AddSliderBare(panel, "Height", "Bar height", 6, 30, 1,
            function() return db.height end,
            function(val) db.height = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "Spacing", "Space between segments", 0, 10, 1,
            function() return db.spacing end,
            function(val) db.spacing = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "X Offset", "Horizontal offset", -200, 200, 1,
            function() return db.offsetX end,
            function(val) db.offsetX = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "Y Offset", "Vertical offset", -200, 200, 1,
            function() return db.offsetY end,
            function(val) db.offsetY = val Apply() end
        )
        local parent = panel:GetParent()
        if parent and parent.__ediWidthStateCallbacks then
            table.insert(parent.__ediWidthStateCallbacks, UpdateWidthState)
        end
    end)

    AddPanel("Appearance", function(panel)
        EdiUI:AddTextureDropdown(panel, "Texture", "Status bar texture", BuildTextureList(),
            function() return db.texture end,
            function(val) db.texture = val Apply() end,
            "statusbar"
        )
        EdiUI:AddCheckbox(panel, "Use Power Color", "Use class resource colors.",
            function() return db.usePowerColor end,
            function(val) db.usePowerColor = val Apply() end
        )
        EdiUI:AddColorPicker(panel, "Bar Color", "Bar color when power colors are disabled.",
            function()
                local c = db.color or {}
                return c.r or 0.906, c.g or 0.298, c.b or 0.235, 1
            end,
            function(r, g, b)
                db.color = db.color or {}
                db.color.r = r
                db.color.g = g
                db.color.b = b
                Apply()
            end
        )
    end)

    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        EdiUI:RegisterOptionsTab("classbar", "Class Bar", BuildClassBarOptions, 8)
    end
end)
