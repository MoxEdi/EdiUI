-- EdiUI Blizzard Cooldown Manager Options
local EdiUI = EdiUI

local function GetManager()
    return EdiUI and EdiUI:GetModule("CooldownManager", true)
end

local function BuildCooldownManagerOptions(parent)
    EdiUI:ResetLayout()

    EdiUI:AddHeader(parent, "Cooldown Manager")
    EdiUI:AddDescription(parent, "Control Blizzard's Cooldown Manager sizing, spacing, and fonts.")
    EdiUI:AddSpacer(parent, 10)

    local db = EdiUI.db.profile.cooldownManager
    local manager = GetManager()

    local function Apply()
        if manager and manager.Update then
            manager:Update()
        end
    end
    if not db.text then
        db.text = {}
    end
    db.text.essentials = db.text.essentials or {}
    db.text.utility = db.text.utility or {}
    db.text.tracked = db.text.tracked or {}

    local tabs = {}
    local tabButtons = {}
    local currentTab
    local tabStartYOffset = 0

    local function CreateSubTabButton(name, index)
        local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
        btn:SetSize(96, 22)
        btn:SetPoint("TOPLEFT", 0 + (index - 1) * 100, -EdiUI:GetCurrentYOffset())

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyButton(btn)
        else
            btn:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            btn:SetBackdropColor(0.08, 0.08, 0.1, 1)
            btn:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        text:SetPoint("CENTER")
        text:SetText(name)
        text:SetTextColor(1, 0.78, 0.29)
        btn.text = text
        return btn
    end

    local function SelectTab(key)
        if currentTab and tabs[currentTab] then
            tabs[currentTab]:Hide()
            if tabButtons[currentTab] and tabButtons[currentTab].text then
                tabButtons[currentTab].text:SetTextColor(1, 0.78, 0.29)
            end
        end

        currentTab = key
        if tabs[currentTab] then
            tabs[currentTab]:Show()
        end
        if tabButtons[currentTab] and tabButtons[currentTab].text then
            tabButtons[currentTab].text:SetTextColor(0.906, 0.298, 0.235)
        end
    end

    local function RegisterTab(key, buildFunc)
        local frame = CreateFrame("Frame", nil, parent)
        frame:SetPoint("TOPLEFT", 0, -(tabStartYOffset + 6))
        frame:SetPoint("TOPRIGHT", 0, 0)
        frame:Hide()
        tabs[key] = frame

        EdiUI:ResetLayout()
        buildFunc(frame)
        frame:SetHeight(EdiUI:GetCurrentYOffset() + 20)
        EdiUI:SetCurrentYOffset(tabStartYOffset)
    end

    local labels = { "General", "Essentials", "Utility", "Tracked Buffs", "Trinkets" }
    local keys = { "general", "essentials", "utility", "tracked", "trinkets" }
    for i, key in ipairs(keys) do
        local btn = CreateSubTabButton(labels[i], i)
        tabButtons[key] = btn
        btn:SetScript("OnClick", function() SelectTab(key) end)
    end

    EdiUI:AddSpacer(parent, 28)
    tabStartYOffset = EdiUI:GetCurrentYOffset()

    local function BuildFontList()
        local fonts = {}
        local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
        if E and E.Libs and E.Libs.LSM then
            for name in pairs(E.Libs.LSM:HashTable("font")) do
                fonts[name] = name
            end
        end
        if next(fonts) == nil and db.font then
            fonts[db.font] = db.font
        end
        return fonts
    end

    local function AddPanel(container, title, buildFunc)
        local startYOffset = EdiUI:GetCurrentYOffset()
        local panel = CreateFrame("Frame", nil, container, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 6, -startYOffset)
        panel:SetPoint("TOPRIGHT", -6, -startYOffset)
        panel:SetHeight(1)

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyFrame(panel, 'Transparent')
        else
            panel:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            panel:SetBackdropColor(0.05, 0.05, 0.07, 1)
            panel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local outerYOffset = EdiUI:GetCurrentYOffset()
        EdiUI:SetCurrentYOffset(12)
        EdiUI:AddHeader(panel, title)
        EdiUI:AddSpacer(panel, 8)
        buildFunc(panel)
        local panelHeight = EdiUI:GetCurrentYOffset() + 12
        panel:SetHeight(panelHeight)
        EdiUI:SetCurrentYOffset(outerYOffset + panelHeight + 18)
    end

    local function AddFontControls(container, title, cfg, isCount)
        local fontLabel = isCount and "Count Font" or "Font"
        local sizeLabel = isCount and "Count Size" or "Font Size"
        local outlineLabel = isCount and "Count Outline" or "Font Outline"
        local xLabel = isCount and "Count X Offset" or "Text X Offset"
        local yLabel = isCount and "Count Y Offset" or "Text Y Offset"

        AddPanel(container, title, function(panel)
            EdiUI:AddDropdownRow(panel, {
                label = fontLabel,
                tooltip = "Choose a font (ElvUI SharedMedia)",
                options = BuildFontList(),
                get = function()
                    return isCount and (cfg.countFont or db.font) or (cfg.font or db.font)
                end,
                set = function(val)
                    if isCount then
                        cfg.countFont = val
                    else
                        cfg.font = val
                    end
                    Apply()
                end,
            }, {
                label = outlineLabel,
                tooltip = "Outline and shadow",
                options = {
                    ["NONE"] = "None",
                    ["SHADOW"] = "Shadow",
                    ["OUTLINE"] = "Outline",
                    ["OUTLINE_SHADOW"] = "Outline + Shadow",
                    ["THICKOUTLINE"] = "Thick Outline",
                    ["THICKOUTLINE_SHADOW"] = "Thick Outline + Shadow",
                },
                get = function()
                    local outline = isCount and (cfg.countOutline or db.fontOutline) or (cfg.fontOutline or db.fontOutline)
                    local shadow = isCount and (cfg.countShadow ~= nil and cfg.countShadow or db.fontShadow) or (cfg.fontShadow ~= nil and cfg.fontShadow or db.fontShadow)
                    if shadow and outline == "THICKOUTLINE" then
                        return "THICKOUTLINE_SHADOW"
                    end
                    if shadow and outline == "OUTLINE" then
                        return "OUTLINE_SHADOW"
                    end
                    if shadow and (outline == "NONE" or not outline) then
                        return "SHADOW"
                    end
                    return outline or "OUTLINE"
                end,
                set = function(val)
                    if val == "SHADOW" then
                        if isCount then
                            cfg.countOutline = "NONE"
                            cfg.countShadow = true
                        else
                            cfg.fontOutline = "NONE"
                            cfg.fontShadow = true
                        end
                    elseif val == "OUTLINE_SHADOW" then
                        if isCount then
                            cfg.countOutline = "OUTLINE"
                            cfg.countShadow = true
                        else
                            cfg.fontOutline = "OUTLINE"
                            cfg.fontShadow = true
                        end
                    elseif val == "THICKOUTLINE_SHADOW" then
                        if isCount then
                            cfg.countOutline = "THICKOUTLINE"
                            cfg.countShadow = true
                        else
                            cfg.fontOutline = "THICKOUTLINE"
                            cfg.fontShadow = true
                        end
                    else
                        if isCount then
                            cfg.countOutline = val
                            cfg.countShadow = false
                        else
                            cfg.fontOutline = val
                            cfg.fontShadow = false
                        end
                    end
                    Apply()
                end,
            }, true)
            EdiUI:AddSliderBare(panel, sizeLabel, "Text size", 8, 24, 1,
                function()
                    return isCount and (cfg.countSize or db.fontSize) or (cfg.fontSize or db.fontSize)
                end,
                function(val)
                    if isCount then
                        cfg.countSize = val
                    else
                        cfg.fontSize = val
                    end
                    Apply()
                end
            )
            EdiUI:AddSliderRow(panel, {
                label = xLabel,
                tooltip = "Horizontal offset",
                min = -50,
                max = 50,
                step = 1,
                get = function()
                    return isCount and (cfg.countX or 0) or (cfg.xOffset or 0)
                end,
                set = function(val)
                    if isCount then
                        cfg.countX = val
                    else
                        cfg.xOffset = val
                    end
                    Apply()
                end,
            }, {
                label = yLabel,
                tooltip = "Vertical offset",
                min = -50,
                max = 50,
                step = 1,
                get = function()
                    return isCount and (cfg.countY or 0) or (cfg.yOffset or 0)
                end,
                set = function(val)
                    if isCount then
                        cfg.countY = val
                    else
                        cfg.yOffset = val
                    end
                    Apply()
                end,
            }, true)
        end)
    end

    RegisterTab("general", function(container)
        AddPanel(container, "Cluster Positioning", function(panel)
            EdiUI:AddCheckbox(panel,
                "Anchored to PlayerFrame",
                "Anchor ElvUI unit frames to Essential cooldowns",
                function() return EdiUI.db.profile.clusterPositioning.enabled end,
                function(val)
                    EdiUI.db.profile.clusterPositioning.enabled = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.UpdateSettings then
                        cluster:UpdateSettings()
                    end
                end
            )
        end)
        AddPanel(container, "Player Frame Offset", function(panel)
            EdiUI:AddSliderRow(panel, {
                label = "Player X Offset",
                tooltip = "Horizontal offset for Player frame",
                min = -200,
                max = 200,
                step = 1,
                get = function() return EdiUI.db.profile.clusterPositioning.playerOffsetX or 0 end,
                set = function(val)
                    EdiUI.db.profile.clusterPositioning.playerOffsetX = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, {
                label = "Player Y Offset",
                tooltip = "Vertical offset for Player frame",
                min = -200,
                max = 200,
                step = 1,
                get = function() return EdiUI.db.profile.clusterPositioning.playerOffsetY or 0 end,
                set = function(val)
                    EdiUI.db.profile.clusterPositioning.playerOffsetY = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, true)
        end)
        AddPanel(container, "Player Power Bar Follow", function(panel)
            EdiUI:AddCheckbox(panel,
                "Follow Player Frame",
                "Make detached Player Power Bar follow the player frame position",
                function() return EdiUI.db.profile.clusterPositioning.playerPowerBar and EdiUI.db.profile.clusterPositioning.playerPowerBar.enabled end,
                function(val)
                    if not EdiUI.db.profile.clusterPositioning.playerPowerBar then
                        EdiUI.db.profile.clusterPositioning.playerPowerBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.playerPowerBar.enabled = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end
            )
            EdiUI:AddSliderRow(panel, {
                label = "X Offset",
                tooltip = "Horizontal offset for power bar",
                min = -200,
                max = 200,
                step = 1,
                get = function()
                    if not EdiUI.db.profile.clusterPositioning.playerPowerBar then
                        EdiUI.db.profile.clusterPositioning.playerPowerBar = {}
                    end
                    return EdiUI.db.profile.clusterPositioning.playerPowerBar.xOffset or 0
                end,
                set = function(val)
                    if not EdiUI.db.profile.clusterPositioning.playerPowerBar then
                        EdiUI.db.profile.clusterPositioning.playerPowerBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.playerPowerBar.xOffset = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, {
                label = "Y Offset",
                tooltip = "Vertical offset between player and power bar (negative = above, positive = below)",
                min = -50,
                max = 50,
                step = 1,
                get = function()
                    if not EdiUI.db.profile.clusterPositioning.playerPowerBar then
                        EdiUI.db.profile.clusterPositioning.playerPowerBar = {}
                    end
                    return EdiUI.db.profile.clusterPositioning.playerPowerBar.gap or 1
                end,
                set = function(val)
                    if not EdiUI.db.profile.clusterPositioning.playerPowerBar then
                        EdiUI.db.profile.clusterPositioning.playerPowerBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.playerPowerBar.gap = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, true)
        end)
        AddPanel(container, "Target Frame Offset", function(panel)
            EdiUI:AddSliderRow(panel, {
                label = "Target X Offset",
                tooltip = "Horizontal offset for Target frame",
                min = -200,
                max = 200,
                step = 1,
                get = function() return EdiUI.db.profile.clusterPositioning.targetOffsetX or 0 end,
                set = function(val)
                    EdiUI.db.profile.clusterPositioning.targetOffsetX = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, {
                label = "Target Y Offset",
                tooltip = "Vertical offset for Target frame",
                min = -200,
                max = 200,
                step = 1,
                get = function() return EdiUI.db.profile.clusterPositioning.targetOffsetY or 0 end,
                set = function(val)
                    EdiUI.db.profile.clusterPositioning.targetOffsetY = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, true)
        end)
        AddPanel(container, "Target Power Bar Follow", function(panel)
            EdiUI:AddCheckbox(panel,
                "Follow Target Frame",
                "Make detached Target Power Bar follow the target frame position",
                function() return EdiUI.db.profile.clusterPositioning.targetPowerBar and EdiUI.db.profile.clusterPositioning.targetPowerBar.enabled end,
                function(val)
                    if not EdiUI.db.profile.clusterPositioning.targetPowerBar then
                        EdiUI.db.profile.clusterPositioning.targetPowerBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.targetPowerBar.enabled = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end
            )
            EdiUI:AddSliderRow(panel, {
                label = "X Offset",
                tooltip = "Horizontal offset for power bar",
                min = -200,
                max = 200,
                step = 1,
                get = function()
                    if not EdiUI.db.profile.clusterPositioning.targetPowerBar then
                        EdiUI.db.profile.clusterPositioning.targetPowerBar = {}
                    end
                    return EdiUI.db.profile.clusterPositioning.targetPowerBar.xOffset or 0
                end,
                set = function(val)
                    if not EdiUI.db.profile.clusterPositioning.targetPowerBar then
                        EdiUI.db.profile.clusterPositioning.targetPowerBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.targetPowerBar.xOffset = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, {
                label = "Y Offset",
                tooltip = "Vertical offset between target and power bar (negative = above, positive = below)",
                min = -50,
                max = 50,
                step = 1,
                get = function()
                    if not EdiUI.db.profile.clusterPositioning.targetPowerBar then
                        EdiUI.db.profile.clusterPositioning.targetPowerBar = {}
                    end
                    return EdiUI.db.profile.clusterPositioning.targetPowerBar.gap or 1
                end,
                set = function(val)
                    if not EdiUI.db.profile.clusterPositioning.targetPowerBar then
                        EdiUI.db.profile.clusterPositioning.targetPowerBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.targetPowerBar.gap = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, true)
        end)
        AddPanel(container, "Target Cast Bar", function(panel)
            EdiUI:AddCheckbox(panel,
                "Enable Target Cast Bar",
                "Position target cast bar in cluster",
                function() return EdiUI.db.profile.clusterPositioning.targetCastBar and EdiUI.db.profile.clusterPositioning.targetCastBar.enabled end,
                function(val)
                    if not EdiUI.db.profile.clusterPositioning.targetCastBar then
                        EdiUI.db.profile.clusterPositioning.targetCastBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.targetCastBar.enabled = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end
            )
            EdiUI:AddSliderRow(panel, {
                label = "X Offset",
                tooltip = "Horizontal offset from target frame",
                min = -200,
                max = 200,
                step = 1,
                get = function()
                    if not EdiUI.db.profile.clusterPositioning.targetCastBar then
                        EdiUI.db.profile.clusterPositioning.targetCastBar = {}
                    end
                    return EdiUI.db.profile.clusterPositioning.targetCastBar.xOffset or 0
                end,
                set = function(val)
                    if not EdiUI.db.profile.clusterPositioning.targetCastBar then
                        EdiUI.db.profile.clusterPositioning.targetCastBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.targetCastBar.xOffset = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, {
                label = "Y Offset",
                tooltip = "Vertical offset from target frame",
                min = -50,
                max = 50,
                step = 1,
                get = function()
                    if not EdiUI.db.profile.clusterPositioning.targetCastBar then
                        EdiUI.db.profile.clusterPositioning.targetCastBar = {}
                    end
                    return EdiUI.db.profile.clusterPositioning.targetCastBar.gap or 1
                end,
                set = function(val)
                    if not EdiUI.db.profile.clusterPositioning.targetCastBar then
                        EdiUI.db.profile.clusterPositioning.targetCastBar = {}
                    end
                    EdiUI.db.profile.clusterPositioning.targetCastBar.gap = val
                    local cluster = EdiUI:GetModule("ClusterPositioning", true)
                    if cluster and cluster.Recalculate then
                        cluster:Recalculate()
                    end
                end,
            }, true)
        end)
    end)

    RegisterTab("essentials", function(container)
        AddPanel(container, "Essential Icons", function(panel)
            EdiUI:AddSliderBare(panel, "Essential Width", "Width of Essential icons", 20, 80, 1,
                function() return db.essentialWidth end,
                function(val) db.essentialWidth = val Apply() end
            )
            EdiUI:AddSliderBare(panel, "Essential Height", "Height of Essential icons", 20, 80, 1,
                function() return db.essentialHeight or db.essentialWidth end,
                function(val) db.essentialHeight = val Apply() end
            )
        end)
        AddPanel(container, "Icon Zoom", function(panel)
            EdiUI:AddSliderBare(panel, "Zoom", "Crop amount on icons", 0, 0.3, 0.01,
                function() return db.essentialZoom or db.iconZoom end,
                function(val) db.essentialZoom = val Apply() end
            )
        end)
        AddFontControls(container, "Cooldown Text", db.text.essentials, false)
        AddFontControls(container, "Count Text", db.text.essentials, true)
    end)

    RegisterTab("utility", function(container)
        AddPanel(container, "Utility Icons", function(panel)
            EdiUI:AddCheckbox(panel,
                "Center Utility Icons",
                "Center utility cooldown icons regardless of EditMode alignment",
                function() return db.centerUtilityIcons end,
                function(val)
                    db.centerUtilityIcons = val
                    Apply()
                end
            )
            EdiUI:AddSliderBare(panel, "Utility Width", "Width of Utility icons", 15, 80, 1,
                function() return db.utilityWidth end,
                function(val) db.utilityWidth = val Apply() end
            )
            EdiUI:AddSliderBare(panel, "Utility Height", "Height of Utility icons", 15, 80, 1,
                function() return db.utilityHeight or db.utilityWidth end,
                function(val) db.utilityHeight = val Apply() end
            )
        end)
        AddPanel(container, "Icon Zoom", function(panel)
            EdiUI:AddSliderBare(panel, "Zoom", "Crop amount on icons", 0, 0.3, 0.01,
                function() return db.utilityZoom or db.iconZoom end,
                function(val) db.utilityZoom = val Apply() end
            )
        end)
        AddFontControls(container, "Cooldown Text", db.text.utility, false)
        AddFontControls(container, "Count Text", db.text.utility, true)
    end)

    RegisterTab("tracked", function(container)
        AddPanel(container, "Tracked Buffs", function(panel)
            EdiUI:AddSliderBare(panel, "Tracked Buff Width", "Width of tracked buffs", 15, 80, 1,
                function() return db.buffIconWidth end,
                function(val) db.buffIconWidth = val Apply() end
            )
            EdiUI:AddSliderBare(panel, "Tracked Buff Height", "Height of tracked buffs", 15, 80, 1,
                function() return db.buffIconHeight or db.buffIconWidth end,
                function(val) db.buffIconHeight = val Apply() end
            )
        end)
        AddPanel(container, "Icon Zoom", function(panel)
            EdiUI:AddSliderBare(panel, "Zoom", "Crop amount on icons", 0, 0.3, 0.01,
                function() return db.trackedZoom or db.iconZoom end,
                function(val) db.trackedZoom = val Apply() end
            )
        end)
        AddFontControls(container, "Cooldown Text", db.text.tracked, false)
        AddFontControls(container, "Count Text", db.text.tracked, true)
    end)

    RegisterTab("trinkets", function(container)
        if not db.trinkets then
            db.trinkets = {}
        end
        if db.trinkets.enabled == nil then db.trinkets.enabled = true end
        if not db.trinkets.anchor then db.trinkets.anchor = "BOTTOMLEFT" end
        if db.trinkets.offsetX == nil then db.trinkets.offsetX = 0 end
        if db.trinkets.offsetY == nil then db.trinkets.offsetY = 0 end
        if not db.trinkets.size then db.trinkets.size = 20 end
        if db.trinkets.spacing == nil then db.trinkets.spacing = 4 end
        if not db.trinkets.strata then db.trinkets.strata = "HIGH" end

        local trinkets = EdiUI:GetModule("Trinkets", true)
        local function ApplyTrinkets()
            if trinkets and trinkets.Update then
                trinkets:Update()
            end
        end

        AddPanel(container, "Trinket Tracker", function(panel)
            EdiUI:AddCheckbox(panel, "Enabled", "Show on-use trinkets with cooldowns.",
                function() return db.trinkets.enabled end,
                function(val)
                    db.trinkets.enabled = val
                    ApplyTrinkets()
                end
            )
            EdiUI:AddSpacer(panel, 6)

            local anchorOptions = {
                BOTTOMLEFT = "Bottom Left",
                LEFT = "Left",
                TOPLEFT = "Top Left",
                CENTER = "Center",
                BOTTOM = "Bottom",
                TOP = "Top",
                TOPRIGHT = "Top Right",
                RIGHT = "Right",
                BOTTOMRIGHT = "Bottom Right",
            }

            local strataOptions = {
                BACKGROUND = "Background",
                LOW = "Low",
                MEDIUM = "Medium",
                HIGH = "High",
                DIALOG = "Dialog",
                FULLSCREEN = "Fullscreen",
                FULLSCREEN_DIALOG = "Fullscreen Dialog",
                TOOLTIP = "Tooltip",
            }

            EdiUI:AddDropdownRow(panel, {
                label = "Anchor",
                tooltip = "Anchor point on ElvUI Player frame.",
                options = anchorOptions,
                get = function() return db.trinkets.anchor or "BOTTOMLEFT" end,
                set = function(val)
                    db.trinkets.anchor = val
                    ApplyTrinkets()
                end,
            }, {
                label = "Strata",
                tooltip = "Frame strata for trinket icons.",
                options = strataOptions,
                get = function() return db.trinkets.strata or "HIGH" end,
                set = function(val)
                    db.trinkets.strata = val
                    ApplyTrinkets()
                end,
            })
        end)

        AddPanel(container, "Position", function(panel)
            EdiUI:AddSliderBare(panel, "X Offset", "Horizontal offset from the anchor point.", -200, 200, 1,
                function() return db.trinkets.offsetX or 0 end,
                function(val)
                    db.trinkets.offsetX = val
                    ApplyTrinkets()
                end
            )
            EdiUI:AddSpacer(panel, 6)
            EdiUI:AddSliderBare(panel, "Y Offset", "Vertical offset from the anchor point.", -200, 200, 1,
                function() return db.trinkets.offsetY or 0 end,
                function(val)
                    db.trinkets.offsetY = val
                    ApplyTrinkets()
                end
            )
        end)

        AddPanel(container, "Icons", function(panel)
            EdiUI:AddSliderBare(panel, "Icon Size", "Size of trinket icons.", 12, 64, 1,
                function() return db.trinkets.size or 20 end,
                function(val)
                    db.trinkets.size = val
                    ApplyTrinkets()
                end
            )
            EdiUI:AddSpacer(panel, 6)
            EdiUI:AddSliderBare(panel, "Spacing", "Spacing between trinket icons.", 0, 20, 1,
                function() return db.trinkets.spacing or 4 end,
                function(val)
                    db.trinkets.spacing = val
                    ApplyTrinkets()
                end
            )
        end)
    end)

    SelectTab("general")
    parent:SetHeight(420)
end

C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        EdiUI:RegisterOptionsTab("cooldownmanager", "Cooldown Manager", BuildCooldownManagerOptions, 6)
    end
end)
