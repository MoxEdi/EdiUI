-- EdiUI Options Panel
-- Main Sushi-based options interface
local EdiUI = EdiUI
local Sushi = LibStub('Sushi-3.2')
local ElvUI = _G.ElvUI
local E, S
if ElvUI then
    E = unpack(ElvUI)
    if E and E.GetModule then
        S = E:GetModule('Skins', true)
    end
end

-- Store reference to Sushi for other modules
EdiUI.Sushi = Sushi

-- ============================================================================
-- MAIN OPTIONS FRAME
-- ============================================================================
local OptionsFrame = nil
local TabButtons = {}
local ContentFrames = {}
local CurrentTab = nil

-- Helper functions to get modules (lazy loading)
local function GetColors()
    return EdiUI.Colors
end

local function GetCompat()
    return EdiUI.Compat
end

-- Color constants (using centralized Colors module)
local COLOR_GOLD, COLOR_BLUE, HEADER_COLOR, ACCENT_COLOR

local function InitColors()
    if COLOR_GOLD then return end
    local Colors = GetColors()
    if Colors then
        COLOR_GOLD = Colors.GOLD
        COLOR_BLUE = Colors.BLUE
        HEADER_COLOR = Colors.HEADER_COLOR
        ACCENT_COLOR = Colors.ACCENT_COLOR
    else
        -- Fallback colors if Colors module not loaded
        COLOR_GOLD = { r = 1.0, g = 0.78, b = 0.29 }
        COLOR_BLUE = { r = 0.906, g = 0.298, b = 0.235 }
        HEADER_COLOR = "|cffffc84a"
        ACCENT_COLOR = "|cffffc84a"
    end
end

-- ElvUI skin hooks (optional)
EdiUI.Skin = EdiUI.Skin or {}
EdiUI.Skin.enabled = (E ~= nil and S ~= nil)

function EdiUI.Skin:IsEnabled()
    return self.enabled == true
end

function EdiUI.Skin:ApplyFrame(frame, template)
    if not (self.enabled and frame) then
        return
    end
    if frame.SetBackdrop then
        frame:SetBackdrop(nil)
    end
    if frame.SetBackdropColor then
        frame:SetBackdropColor(0, 0, 0, 0)
    end
    if frame.SetBackdropBorderColor then
        frame:SetBackdropBorderColor(0, 0, 0, 0)
    end
    if frame.CreateBackdrop then
        frame:CreateBackdrop(template or 'Transparent')
    elseif frame.SetTemplate then
        frame:SetTemplate(template or 'Transparent')
    elseif E and E.CreateBackdrop then
        E:CreateBackdrop(frame, template or 'Transparent')
    end
end

function EdiUI.Skin:ApplyButton(button)
    if self.enabled and button then
        pcall(S.HandleButton, S, button, true)
    end
end

function EdiUI.Skin:ApplySlider(slider)
    if self.enabled and slider then
        pcall(S.HandleSliderFrame, S, slider)
        if slider.Edit then
            pcall(S.HandleEditBox, S, slider.Edit)
        end
    end
end

function EdiUI.Skin:ApplyDropdown(dropdown, width)
    if self.enabled and dropdown then
        pcall(S.HandleDropDownBox, S, dropdown, width or dropdown:GetWidth())
    end
end

function EdiUI.Skin:ApplyCheckBox(check)
    if self.enabled and check then
        pcall(S.HandleCheckBox, S, check, true)
    end
end

function EdiUI.Skin:ApplyEditBox(edit)
    if self.enabled and edit then
        pcall(S.HandleEditBox, S, edit)
    end
end

function EdiUI.Skin:ApplyCloseButton(button)
    if self.enabled and button then
        pcall(S.HandleCloseButton, S, button)
    end
end

function EdiUI.Skin:ApplyScrollBar(scrollBar)
    if self.enabled and scrollBar then
        pcall(S.HandleScrollBar, S, scrollBar)
    end
end

function EdiUI.Skin:ApplyStatusBar(statusBar, color)
    if self.enabled and statusBar then
        pcall(S.HandleStatusBar, S, statusBar, color, 'Transparent')
    end
end

-- Create main frame
local function CreateMainFrame()
    if OptionsFrame then return OptionsFrame end

    -- Initialize colors
    InitColors()
    local Compat = GetCompat()

    -- Create main backdrop frame
    local frame = CreateFrame("Frame", "EdiUIOptionsFrame", UIParent, "BackdropTemplate")
    frame:SetSize(800, 600)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("HIGH")
    frame:SetFrameLevel(100)
    frame:SetToplevel(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:SetResizable(true)
    -- Use Compat layer for 12.0+ SetResizeBounds
    if Compat then
        Compat.SetFrameResize(frame, 720, 520, 1200, 900)
    else
        frame:SetResizeBounds(720, 520, 1200, 900)
    end
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)
    frame:Hide()
    
    -- Outer border
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        tile = false,
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    frame:SetBackdropColor(0.02, 0.02, 0.03, 1)
    frame:SetBackdropBorderColor(0.15, 0.15, 0.2, 1)

    local inner = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    inner:SetPoint("TOPLEFT", 1, -1)
    inner:SetPoint("BOTTOMRIGHT", -1, 1)
    inner:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    inner:SetBackdropColor(0.07, 0.07, 0.09, 1)
    inner:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
    frame.inner = inner
    
    -- Title bar
    local titleBar = CreateFrame("Frame", nil, inner, "BackdropTemplate")
    titleBar:SetHeight(35)
    titleBar:SetPoint("TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", 0, 0)
    titleBar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
    })
    titleBar:SetBackdropColor(0.1, 0.1, 0.13, 1)

    -- Title text (left side)
    local title = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("LEFT", 15, 0)
    title:SetText(ACCENT_COLOR .. "Settings|r")
    frame.title = title

    -- Version text (beside title)
    local version = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    version:SetPoint("LEFT", title, "RIGHT", 8, 0)
    version:SetText(HEADER_COLOR .. "v" .. (EdiUI.Version or "1.0") .. "|r")
    frame.version = version

    -- Install button with backdrop (styled like ElvUI)
    local installBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    installBtn:SetSize(70, 22)
    installBtn:SetPoint("LEFT", version, "RIGHT", 15, 0)
    installBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    installBtn:SetBackdropColor(0.15, 0.15, 0.18, 1)
    installBtn:SetBackdropBorderColor(0.4, 0.4, 0.45, 1)
    installBtn:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
    end)
    installBtn:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(0.4, 0.4, 0.45, 1)
    end)
    local installText = installBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    installText:SetPoint("CENTER")
    installText:SetText("Install")
    installText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    installBtn.text = installText
    installBtn:SetScript("OnClick", function()
        if EdiUI and EdiUI.Installer and EdiUI.Installer.Show then
            EdiUI.Installer:Show()
        elseif EdiUI and EdiUI.Installer and EdiUI.Installer.Open then
            EdiUI.Installer:Open()
        end
        frame:Hide()
    end)
    frame.installBtn = installBtn

    -- Changelog button (styled like Install button)
    local changelogBtn = CreateFrame("Button", nil, titleBar, "BackdropTemplate")
    changelogBtn:SetSize(80, 22)
    changelogBtn:SetPoint("RIGHT", -115, 0)
    changelogBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    changelogBtn:SetBackdropColor(0.15, 0.15, 0.18, 1)
    changelogBtn:SetBackdropBorderColor(0.4, 0.4, 0.45, 1)
    changelogBtn:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
    end)
    changelogBtn:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(0.4, 0.4, 0.45, 1)
    end)
    local changelogText = changelogBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    changelogText:SetPoint("CENTER")
    changelogText:SetText("Changelog")
    changelogText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    changelogBtn.text = changelogText
    changelogBtn:SetScript("OnClick", function()
        if EdiUI.Changelog and EdiUI.Changelog.Show then
            EdiUI.Changelog:Show()
        end
    end)
    frame.changelogBtn = changelogBtn

    -- Reset size button (top right, styled like ElvUI)
    local resizeBtn = CreateFrame("Button", nil, titleBar)
    resizeBtn:SetSize(18, 18)
    resizeBtn:SetPoint("RIGHT", -40, 0)

    -- Use ElvUI's texture if available, otherwise use a fallback
    local resizeTexture = resizeBtn:CreateTexture(nil, "ARTWORK")
    if E and E.Media and E.Media.Textures and E.Media.Textures.Resize2 then
        resizeTexture:SetTexture(E.Media.Textures.Resize2)
    else
        -- Fallback: use a simple resize icon texture
        resizeTexture:SetTexture(386859) -- Blizzard resize texture
    end
    resizeTexture:SetAllPoints()
    resizeTexture:SetVertexColor(1, 1, 1, 0.8)
    resizeBtn.texture = resizeTexture

    resizeBtn:SetScript("OnClick", function()
        -- Reset to default size
        frame:SetSize(900, 700)
    end)
    resizeBtn:SetScript("OnEnter", function(self)
        if E and E.media and E.media.rgbvaluecolor then
            local r, g, b = unpack(E.media.rgbvaluecolor)
            self.texture:SetVertexColor(r, g, b, 1)
        else
            self.texture:SetVertexColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
        GameTooltip:SetOwner(self, "ANCHOR_TOP")
        GameTooltip:SetText("Reset Size", 1, 1, 1)
        GameTooltip:Show()
    end)
    resizeBtn:SetScript("OnLeave", function(self)
        self.texture:SetVertexColor(1, 1, 1, 0.8)
        GameTooltip:Hide()
    end)
    frame.resizeBtn = resizeBtn

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar)
    closeBtn:SetSize(30, 30)
    closeBtn:SetPoint("RIGHT", -5, 0)
    closeBtn:SetNormalFontObject("GameFontNormalLarge")
    closeBtn:SetHighlightFontObject("GameFontHighlightLarge")
    closeBtn:SetText("X")
    closeBtn:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    closeBtn:SetScript("OnClick", function() frame:Hide() end)
    closeBtn:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(1, 0.3, 0.3) end)
    closeBtn:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b) end)

    -- Resize grip (bottom-right, like ElvUI with arrow)
    local resize = CreateFrame("Button", nil, inner)
    resize:SetSize(24, 24)
    resize:SetPoint("BOTTOMRIGHT", 1, -1)
    resize:SetFrameLevel(200)

    -- Create arrow texture like ElvUI
    local resizeArrow = resize:CreateTexture(nil, "OVERLAY")
    if E and E.Media and E.Media.Textures and E.Media.Textures.ArrowUp then
        resizeArrow:SetTexture(E.Media.Textures.ArrowUp)
    else
        -- Fallback: use Blizzard's arrow texture
        resizeArrow:SetTexture("Interface\\Buttons\\UI-ScrollBar-ScrollDownButton-Up")
        resizeArrow:SetTexCoord(0.25, 0.75, 0.25, 0.75)
    end
    resizeArrow:SetAllPoints()
    resizeArrow:SetRotation(-2.35) -- Rotate to point to bottom-right corner (like ElvUI)
    resize.texture = resizeArrow

    resize:SetScript("OnMouseDown", function()
        frame:StartSizing("BOTTOMRIGHT")
    end)
    resize:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
    end)
    resize:SetScript("OnEnter", function(self)
        if E and E.media and E.media.rgbvaluecolor then
            local r, g, b = unpack(E.media.rgbvaluecolor)
            self.texture:SetVertexColor(r, g, b, 1)
        else
            self.texture:SetVertexColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
    end)
    resize:SetScript("OnLeave", function(self)
        self.texture:SetVertexColor(1, 1, 1, 1)
    end)
    frame.resizeGrip = resize
    
    -- Left sidebar for tabs
    local sidebar = CreateFrame("Frame", nil, inner, "BackdropTemplate")
    sidebar:SetWidth(160)
    sidebar:SetPoint("TOPLEFT", 0, -35)
    sidebar:SetPoint("BOTTOMLEFT", 0, 0)
    sidebar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
    })
    sidebar:SetBackdropColor(0.05, 0.05, 0.07, 1)
    local sidebarBorder = sidebar:CreateTexture(nil, "BORDER")
    sidebarBorder:SetPoint("TOPRIGHT", 0, 0)
    sidebarBorder:SetPoint("BOTTOMRIGHT", 0, 0)
    sidebarBorder:SetWidth(1)
    sidebarBorder:SetColorTexture(0.2, 0.2, 0.25, 1)
    frame.sidebar = sidebar

    -- Logo at top of sidebar
    local logoFrame = CreateFrame("Frame", nil, sidebar)
    logoFrame:SetSize(110, 110)
    logoFrame:SetPoint("TOP", 0, -10)

    local logo = logoFrame:CreateTexture(nil, "ARTWORK")
    logo:SetTexture("Interface\\AddOns\\EdiUI\\Media\\Logo\\logo.tga")
    logo:SetAllPoints()
    logoFrame.texture = logo
    frame.logo = logoFrame

    -- Apply glitch effect (cyberpunk preset for more intense effect)
    if EdiUI.GlitchEffect then
        EdiUI.GlitchEffect:Apply(logoFrame, EdiUI.GlitchEffect.Presets.cyberpunk)
    end

    -- Content area
    local content = CreateFrame("Frame", nil, inner)
    content:SetPoint("TOPLEFT", sidebar, "TOPRIGHT", 0, 0)
    content:SetPoint("BOTTOMRIGHT", 0, 0)
    frame.content = content

    local contentHolder = CreateFrame("Frame", nil, content, "BackdropTemplate")
    contentHolder:SetPoint("TOPLEFT", 6, -6)
    contentHolder:SetPoint("BOTTOMRIGHT", -6, 6)
    frame.contentHolder = contentHolder

    if EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(contentHolder, 'Transparent')
    else
        contentHolder:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        contentHolder:SetBackdropColor(0.04, 0.04, 0.06, 1)
        contentHolder:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
    end

    -- Scroll frame for content
    local scrollFrame = CreateFrame("ScrollFrame", nil, contentHolder, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 8, -8)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 8)
    frame.scrollFrame = scrollFrame
    
    -- Scroll child
    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(590, 1) -- Height will be dynamic
    scrollFrame:SetScrollChild(scrollChild)
    frame.scrollChild = scrollChild

    local function RefreshLayout()
        local width = frame:GetWidth()
        local height = frame:GetHeight()

        sidebar:SetHeight(height - 35)
        content:SetSize(width - 160, height - 35)
        contentHolder:SetPoint("TOPLEFT", 6, -6)
        contentHolder:SetPoint("BOTTOMRIGHT", -6, 6)
        scrollFrame:SetPoint("TOPLEFT", 8, -8)
        scrollFrame:SetPoint("BOTTOMRIGHT", -28, 8)

        local scrollWidth = contentHolder:GetWidth() - 36
        if scrollWidth < 520 then
            scrollWidth = 520
        end
        scrollChild:SetWidth(scrollWidth)
    end

    frame:SetScript("OnSizeChanged", function()
        RefreshLayout()
    end)
    RefreshLayout()
    
    -- Style the scrollbar
    local scrollBar = scrollFrame.ScrollBar or _G[scrollFrame:GetName() .. "ScrollBar"]
    if scrollBar then
        if EdiUI.Skin:IsEnabled() then
            pcall(S.HandleScrollBar, S, scrollBar)
        else
            scrollBar:SetPoint("TOPLEFT", scrollFrame, "TOPRIGHT", 6, -16)
            scrollBar:SetPoint("BOTTOMLEFT", scrollFrame, "BOTTOMRIGHT", 6, 16)
            scrollBar:SetWidth(8)

            local up = scrollBar.ScrollUpButton or _G[scrollBar:GetName() .. "ScrollUpButton"]
            local down = scrollBar.ScrollDownButton or _G[scrollBar:GetName() .. "ScrollDownButton"]
            if up then up:Hide() up:EnableMouse(false) end
            if down then down:Hide() down:EnableMouse(false) end

            local track = scrollBar:CreateTexture(nil, "BACKGROUND")
            track:SetPoint("TOPLEFT", 0, 0)
            track:SetPoint("BOTTOMRIGHT", 0, 0)
            track:SetColorTexture(0.08, 0.08, 0.1, 1)

            local thumb = scrollBar.ThumbTexture or scrollBar:GetThumbTexture()
            if thumb then
                thumb:SetTexture("Interface\\Buttons\\WHITE8x8")
                thumb:SetColorTexture(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
                thumb:SetSize(8, 40)
            end
        end
    end

    if EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(frame, 'Transparent')
        EdiUI.Skin:ApplyFrame(inner, 'Transparent')
        EdiUI.Skin:ApplyFrame(titleBar, 'Transparent')
        EdiUI.Skin:ApplyFrame(sidebar, 'Transparent')
        EdiUI.Skin:ApplyCloseButton(closeBtn)
        -- Hide the text "X" since ElvUI's skin provides its own styled close icon
        closeBtn:SetText("")
        if sidebarBorder then
            sidebarBorder:Hide()
        end
    end
    
    -- ESC to close
    tinsert(UISpecialFrames, "EdiUIOptionsFrame")
    
    OptionsFrame = frame
    return frame
end

-- ============================================================================
-- TAB SYSTEM
-- ============================================================================
local function CreateTabButton(parent, name, index)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(150, 30)
    -- Start tabs below logo (logo is 110px + 10px offset + 10px gap = 130px)
    local logoOffset = 130
    btn:SetPoint("TOPLEFT", 5, -(logoOffset + (index - 1) * 32))

    local backdrop = CreateFrame("Frame", nil, btn, "BackdropTemplate")
    backdrop:SetAllPoints()
    backdrop:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    backdrop:SetBackdropColor(0.08, 0.08, 0.1, 1)
    backdrop:SetBackdropBorderColor(0.18, 0.18, 0.22, 1)
    btn.backdrop = backdrop
    
    -- Background
    local bg = btn:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.1, 0.1, 0.12, 0)
    btn.bg = bg
    
    -- Highlight
    local highlight = btn:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetAllPoints()
    highlight:SetColorTexture(0.2, 0.2, 0.25, 0.5)
    
    -- Selected indicator
    local selected = btn:CreateTexture(nil, "OVERLAY")
    selected:SetSize(3, 24)
    selected:SetPoint("LEFT", 0, 0)
    selected:SetColorTexture(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
    selected:Hide()
    btn.selected = selected
    
    -- Text
    local text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("CENTER", 0, 0)
    text:SetText(name)
    text:SetJustifyH("CENTER")
    text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    local font, _, flags = text:GetFont()
    if font then
        text:SetFont(font, 12, flags)
    end
    btn.text = text

    if EdiUI.Skin:IsEnabled() then
        backdrop:Hide()
        bg:Hide()
        EdiUI.Skin:ApplyButton(btn)
    end
    
    btn:SetScript("OnEnter", function(self)
        if self.bg then
            self.bg:SetColorTexture(0.12, 0.12, 0.16, 1)
        end
        if self.backdrop and self.backdrop.SetBackdropBorderColor then
            self.backdrop:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
        if self.text and CurrentTab ~= self then
            self.text:SetTextColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b)
        end
    end)
    
    btn:SetScript("OnLeave", function(self)
        if CurrentTab ~= self then
            if self.bg then
                self.bg:SetColorTexture(0.1, 0.1, 0.12, 0)
            end
            if self.backdrop and self.backdrop.SetBackdropBorderColor then
                self.backdrop:SetBackdropBorderColor(0.18, 0.18, 0.22, 1)
            end
            if self.text then
                self.text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
            end
        else
            if self.bg then
                self.bg:SetColorTexture(0.15, 0.15, 0.2, 1)
            end
            if self.backdrop and self.backdrop.SetBackdropBorderColor then
                self.backdrop:SetBackdropBorderColor(0.18, 0.18, 0.22, 1)
            end
            if self.text then
                self.text:SetTextColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b)
            end
        end
    end)
    
    return btn
end

local function SelectTab(tabName)
    -- Deselect current
    if CurrentTab then
        CurrentTab.selected:Hide()
        if CurrentTab.bg then
            CurrentTab.bg:SetColorTexture(0.1, 0.1, 0.12, 0)
        end
        CurrentTab.text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end
    
    -- Hide all content frames
    for name, frame in pairs(ContentFrames) do
        frame:Hide()
    end
    
    -- Select new tab
    local btn = TabButtons[tabName]
    if btn then
        btn.selected:Show()
        if btn.bg then
            btn.bg:SetColorTexture(0.15, 0.15, 0.2, 1)
        end
        btn.text:SetTextColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b)
        CurrentTab = btn
    end
    
    -- Show content
    if ContentFrames[tabName] then
        ContentFrames[tabName]:Show()
    end
    
    -- Reset scroll
    if OptionsFrame and OptionsFrame.scrollFrame then
        OptionsFrame.scrollFrame:SetVerticalScroll(0)
    end
end

-- ============================================================================
-- TAB REGISTRATION
-- ============================================================================
local tabOrder = {}

function EdiUI:RegisterOptionsTab(name, displayName, createFunc, order)
    order = order or (#tabOrder + 1)
    
    table.insert(tabOrder, {
        name = name,
        displayName = displayName,
        createFunc = createFunc,
        order = order
    })
    
    -- Sort by order
    table.sort(tabOrder, function(a, b) return a.order < b.order end)
end

function EdiUI:BuildOptionsPanel()
    local frame = CreateMainFrame()
    
    -- Clear existing tabs
    for _, btn in pairs(TabButtons) do
        btn:Hide()
    end
    TabButtons = {}
    ContentFrames = {}
    
    -- Create tabs from registered modules
    for i, tabInfo in ipairs(tabOrder) do
        -- Create tab button
        local btn = CreateTabButton(frame.sidebar, tabInfo.displayName, i)
        btn:SetScript("OnClick", function()
            SelectTab(tabInfo.name)
        end)
        TabButtons[tabInfo.name] = btn
        
        -- Create content frame
        local contentFrame = CreateFrame("Frame", nil, frame.scrollChild)
        contentFrame:SetPoint("TOPLEFT", 0, 0)
        contentFrame:SetPoint("TOPRIGHT", 0, 0)
        contentFrame:Hide()
        ContentFrames[tabInfo.name] = contentFrame
        
        -- Build content if function provided
        if tabInfo.createFunc then
            local ok, err = pcall(tabInfo.createFunc, contentFrame)
            if not ok then
                EdiUI:Print("Options build error: " .. tostring(err))
            end
        end
    end
    
    -- Select first tab
    if tabOrder[1] then
        SelectTab(tabOrder[1].name)
    end
end

-- ============================================================================
-- WIDGET HELPERS
-- ============================================================================
-- These helpers create consistent Sushi widgets with our styling

local currentYOffset = 0
local CONTROL_BG_WIDTH = 520
local CONTROL_ROW_GAP = 16
local CONTROL_INSET_X = 14
local CONTROL_ROW_PADDING = 14
local CHECKBOX_INSET_X = 10

function EdiUI:AddControlBackdrop(parent, anchor, topOffset, bottomOffset)
    local bg = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    local width = anchor and anchor.__ediBgWidth or nil
    local pad = anchor and anchor.__ediBgPad or 0
    if width then
        bg:SetPoint("TOPLEFT", anchor, "TOPLEFT", -pad, topOffset or 12)
        bg:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMLEFT", width + pad, bottomOffset or -12)
    else
        bg:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, topOffset or 12)
        bg:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", 10, bottomOffset or -12)
    end
    bg:SetFrameLevel(math.max(0, (anchor:GetFrameLevel() or 1) - 1))

    if EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(bg, 'Transparent')
    else
        bg:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        bg:SetBackdropColor(0.05, 0.05, 0.07, 1)
        bg:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
    end

    if not bg.__ediBorderLines then
        local left = bg:CreateTexture(nil, "BORDER")
        left:SetPoint("TOPLEFT", 0, 0)
        left:SetPoint("BOTTOMLEFT", 0, 0)
        left:SetWidth(1)
        left:SetColorTexture(0.2, 0.2, 0.25, 1)

        local right = bg:CreateTexture(nil, "BORDER")
        right:SetPoint("TOPRIGHT", 0, 0)
        right:SetPoint("BOTTOMRIGHT", 0, 0)
        right:SetWidth(1)
        right:SetColorTexture(0.2, 0.2, 0.25, 1)

        bg.__ediBorderLines = true
    end

    return bg
end

local function StyleSlider(slider)
    if slider.__ediStyled then
        return
    end

    if EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplySlider(slider)
        if slider.Text then
            slider.Text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
        end
        if slider.Low then
            slider.Low:SetTextColor(0.8, 0.8, 0.8)
            slider.Low:ClearAllPoints()
            slider.Low:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 8, -6)
        end
        if slider.High then
            slider.High:SetTextColor(0.8, 0.8, 0.8)
            slider.High:ClearAllPoints()
            slider.High:SetPoint("TOPRIGHT", slider, "BOTTOMRIGHT", -4, -6)
        end
        if slider.Edit then
            slider.Edit:ClearAllPoints()
            slider.Edit:SetPoint("TOP", slider, "BOTTOM", 0, -6)
            slider.Edit:SetSize(60, 18)
            slider.Edit:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
        end
        slider:SetWidth(slider.__ediWidth or 260)
        slider.__ediStyled = true
        return
    end

    slider:StripTextures()

    local minVal, maxVal = slider:GetMinMaxValues()

    local thumb = slider:GetThumbTexture()
    if thumb then
        thumb:SetTexture("Interface\\Buttons\\WHITE8x8")
        thumb:SetSize(8, 14)
        thumb:SetColorTexture(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        thumb:SetDrawLayer("OVERLAY")
    end

    slider:SetHeight(20)

    if not slider.TrackFrame then
        local trackFrame = CreateFrame("StatusBar", nil, slider, "BackdropTemplate")
        trackFrame:SetPoint("LEFT", 6, 0)
        trackFrame:SetPoint("RIGHT", -6, 0)
        trackFrame:SetHeight(8)
        trackFrame:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
        trackFrame:SetStatusBarColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        trackFrame:SetMinMaxValues(minVal, maxVal)
        trackFrame:SetFrameLevel(slider:GetFrameLevel() - 1)
        trackFrame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        trackFrame:SetBackdropColor(0.08, 0.08, 0.1, 1)
        trackFrame:SetBackdropBorderColor(0.2, 0.2, 0.2, 1)

        local thumbBlock = slider:CreateTexture(nil, "OVERLAY")
        thumbBlock:SetTexture("Interface\\Buttons\\WHITE8x8")
        thumbBlock:SetSize(8, 14)
        thumbBlock:SetColorTexture(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        thumbBlock:SetDrawLayer("OVERLAY", 7)

        slider.TrackFrame = trackFrame
        slider.ThumbBlock = thumbBlock
    end

    if slider.Text then
        slider.Text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
        slider.Text:ClearAllPoints()
        slider.Text:SetPoint("BOTTOM", slider, "TOP", 0, 6)
    end
    if slider.Low then
        slider.Low:SetTextColor(0.8, 0.8, 0.8)
        slider.Low:ClearAllPoints()
        slider.Low:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 0, -6)
    end
    if slider.High then
        slider.High:SetTextColor(0.8, 0.8, 0.8)
        slider.High:ClearAllPoints()
        slider.High:SetPoint("TOPRIGHT", slider, "BOTTOMRIGHT", 0, -6)
    end

    if slider.Edit then
        slider.Edit:ClearAllPoints()
        slider.Edit:SetPoint("TOP", slider, "BOTTOM", 0, -6)
        slider.Edit:SetSize(60, 18)
        slider.Edit:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        slider.Edit:SetBackdropColor(0.08, 0.08, 0.1, 1)
        slider.Edit:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        slider.Edit:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end

    local function UpdateFill(self, value)
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if not maxVal or maxVal == minVal then
            return
        end
        local val = tonumber(value) or self:GetValue()
        if val < minVal then
            val = minVal
        elseif val > maxVal then
            val = maxVal
        end
        local pct = (val - minVal) / (maxVal - minVal)
        local width = self.TrackFrame and self.TrackFrame:GetWidth()
        if width and width > 0 then
            self.TrackFrame:SetMinMaxValues(minVal, maxVal)
            self.TrackFrame:SetValue(val)
            local x = (width - 2) * pct
            self.ThumbBlock:ClearAllPoints()
            self.ThumbBlock:SetPoint("CENTER", self.TrackFrame, "LEFT", 1 + x, 0)
        end
    end

    slider:HookScript("OnValueChanged", function(self, value)
        if self.__ediClamp then
            return
        end
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        local val = tonumber(value) or self:GetValue()
        if minVal and maxVal then
            local clamped = val
            if val < minVal then
                clamped = minVal
            elseif val > maxVal then
                clamped = maxVal
            end
            if clamped ~= val then
                self.__ediClamp = true
                self:SetValue(clamped, true)
                self.__ediClamp = nil
                UpdateFill(self, clamped)
                return
            end
        end
        UpdateFill(self, val)
    end)

    slider:HookScript("OnSizeChanged", function(self)
        UpdateFill(self, self:GetValue())
    end)

    UpdateFill(slider, slider:GetValue())

    slider.__ediStyled = true
end

function EdiUI:ResetLayout()
    currentYOffset = 0
end

function EdiUI:AddHeader(parent, text)
    local header = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    header:SetPoint("TOPLEFT", 0, -currentYOffset)
    header:SetText(HEADER_COLOR .. text .. "|r")
    currentYOffset = currentYOffset + 30
    return header
end

function EdiUI:AddDescription(parent, text)
    local desc = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    desc:SetPoint("TOPLEFT", 0, -currentYOffset)
    desc:SetPoint("RIGHT", -10, 0)
    desc:SetJustifyH("LEFT")
    desc:SetText(text)
    desc:SetTextColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b)
    local font, _, flags = desc:GetFont()
    if font then
        desc:SetFont(font, 14, flags)
    end
    desc:SetWordWrap(true)
    local height = desc:GetStringHeight() + 10
    currentYOffset = currentYOffset + height
    return desc
end

function EdiUI:AddSpacer(parent, height)
    height = height or 15
    currentYOffset = currentYOffset + height
end

function EdiUI:AddCheckbox(parent, label, tooltip, getValue, setValue)
    local check = Sushi.Check(parent)
    check:SetPoint("TOPLEFT", CHECKBOX_INSET_X, -currentYOffset)
    check:SetLabel(label)
    if tooltip then check:SetTip(tooltip) end
    check:SetChecked(getValue())
    check:SetCall('OnClick', function(self)
        setValue(self:GetChecked())
    end)
    if EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyCheckBox(check)
    end
    if not check.__ediBackdrop then
        local normal = check.GetNormalTexture and check:GetNormalTexture() or nil
        local checked = check.GetCheckedTexture and check:GetCheckedTexture() or nil
        local pushed = check.GetPushedTexture and check:GetPushedTexture() or nil
        local highlight = check.GetHighlightTexture and check:GetHighlightTexture() or nil
        local box = CreateFrame("Frame", nil, check, "BackdropTemplate")
        box:SetSize(18, 18)
        box:SetPoint("LEFT", check, "LEFT", 2, 0)
        box:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        box:SetBackdropColor(0.08, 0.08, 0.1, 1)
        box:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        box:SetFrameLevel(math.max(0, check:GetFrameLevel() - 1))
        check.__ediBackdrop = box

        if normal then
            normal:ClearAllPoints()
            normal:SetAllPoints(box)
        end
        if checked then
            checked:ClearAllPoints()
            checked:SetAllPoints(box)
        end
        if pushed then
            pushed:ClearAllPoints()
            pushed:SetAllPoints(box)
        end
        if highlight then
            highlight:ClearAllPoints()
            highlight:SetAllPoints(box)
        end
    end
    currentYOffset = currentYOffset + 32
    return check
end

function EdiUI:AddSlider(parent, label, tooltip, minVal, maxVal, step, getValue, setValue)
    local slider = Sushi.Slider(parent, label, getValue(), minVal, maxVal, step)
    slider:SetPoint("TOPLEFT", 0, -currentYOffset)
    slider.__ediWidth = slider.__ediWidth or 170
    slider.__ediBgPad = CONTROL_ROW_PADDING
    slider.__ediBgWidth = CONTROL_BG_WIDTH - (CONTROL_ROW_PADDING * 2)
    slider:SetWidth(slider.__ediWidth)
    slider.__ediMin = minVal
    slider.__ediMax = maxVal
    if minVal and maxVal then
        slider:SetRange(minVal, maxVal)
    end
    if step then
        slider:SetValueStep(step)
        slider:SetObeyStepOnDrag(true)
    end
    if tooltip then slider:SetTip(tooltip) end
    slider:SetCall('OnInput', function(self, value)
        local val = tonumber(value)
        if not val then
            return
        end
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        if self:GetValue() ~= val then
            self.__ediClamp = true
            self:SetValue(val, true)
            self.__ediClamp = nil
        end
        setValue(val)
    end)
    slider:HookScript("OnMouseWheel", function(self, delta)
        local stepVal = self:GetStep() or step or 1
        local val = (self:GetValue() or 0) + (stepVal * delta)
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        self.__ediClamp = true
        self:SetValue(val, true)
        self.__ediClamp = nil
    end)
    pcall(StyleSlider, slider)
    self:AddControlBackdrop(parent, slider, 16, -28)
    if EdiUI.Skin:IsEnabled() then
        currentYOffset = currentYOffset + 70
    else
        currentYOffset = currentYOffset + 60
    end
    return slider
end

function EdiUI:AddDropdown(parent, label, tooltip, options, getValue, setValue, noBackdrop)
    local dropdown = Sushi.DropChoice(parent)
    dropdown:SetPoint("TOPLEFT", 0, -currentYOffset)
    dropdown.__ediWidth = dropdown.__ediWidth or 230
    dropdown.__ediBgPad = CONTROL_ROW_PADDING
    dropdown.__ediBgWidth = CONTROL_BG_WIDTH - (CONTROL_ROW_PADDING * 2)
    dropdown:SetWidth(dropdown.__ediWidth)
    dropdown:SetLabel(label)
    if tooltip then dropdown:SetTip(tooltip) end

    -- Add choices (key = internal value, text = display text)
    for value, displayText in pairs(options) do
        dropdown:Add(value, displayText)
    end

    dropdown:SetValue(getValue())
    dropdown:SetCall('OnInput', function(self, value)
        setValue(value)
    end)
    dropdown:SetCall('OnValue', function(self, value)
        setValue(value)
    end)
    dropdown:SetScript("OnClick", nil)
    dropdown:SetScript("OnMouseDown", function(self)
        if self.OnClick then
            self:OnClick()
        end
    end)

    if not EdiUI.Skin:IsEnabled() then
        if dropdown.Left then dropdown.Left:Hide() end
        if dropdown.Middle then dropdown.Middle:Hide() end
        if dropdown.Right then dropdown.Right:Hide() end
        if dropdown.SetBackdrop then
            dropdown:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            dropdown:SetBackdropColor(0.08, 0.08, 0.1, 1)
            dropdown:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
        dropdown:SetHeight(24)
    else
        EdiUI.Skin:ApplyDropdown(dropdown, dropdown:GetWidth())
    end

    local text = dropdown.Text or _G[dropdown:GetName() .. "Text"]
    if text then
        text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end
    if dropdown.Label then
        dropdown.Label:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end

    if not noBackdrop then
        self:AddControlBackdrop(parent, dropdown, 14, -14)
    end

    currentYOffset = currentYOffset + 55
    return dropdown
end

function EdiUI:AddTextureDropdown(parent, label, tooltip, options, getValue, setValue, mediaType)
    local dropdown = Sushi.DropChoice(parent)
    dropdown:SetPoint("TOPLEFT", 0, -currentYOffset)
    dropdown.__ediWidth = dropdown.__ediWidth or 230
    dropdown.__ediBgPad = CONTROL_ROW_PADDING
    dropdown.__ediBgWidth = CONTROL_BG_WIDTH - (CONTROL_ROW_PADDING * 2)
    dropdown:SetWidth(dropdown.__ediWidth)
    dropdown:SetLabel(label)
    if tooltip then dropdown:SetTip(tooltip) end

    local list = {}
    for value, displayText in pairs(options) do
        list[#list + 1] = { key = value, text = displayText }
        dropdown:Add(value, displayText)
    end
    table.sort(list, function(a, b) return tostring(a.text) < tostring(b.text) end)

    dropdown:SetValue(getValue())
    dropdown:SetCall('OnInput', function(self, value)
        setValue(value)
    end)
    dropdown:SetCall('OnValue', function(self, value)
        setValue(value)
    end)

    local function EnsureTextureMenu()
        if dropdown.__ediTextureMenu then
            return dropdown.__ediTextureMenu
        end

        local menu = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        if EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyFrame(menu, 'Transparent')
        else
            menu:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            menu:SetBackdropColor(0.08, 0.08, 0.1, 0.98)
            menu:SetBackdropBorderColor(0, 0, 0, 1)
        end
        menu:SetSize(dropdown:GetWidth() + 40, 260)
        menu:Hide()

        local scroll = CreateFrame("ScrollFrame", nil, menu, "FauxScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 8, -8)
        scroll:SetPoint("BOTTOMRIGHT", -28, 8)
        if scroll.ScrollBar then
            EdiUI.Skin:ApplyScrollBar(scroll.ScrollBar)
        end

        local lines = {}
        local lineHeight = 26
        local maxLines = 9

        for i = 1, maxLines do
            local line = CreateFrame("Button", nil, menu)
            line:SetHeight(lineHeight)
            line:SetPoint("TOPLEFT", 8, -8 - (i - 1) * lineHeight)
            line:SetPoint("RIGHT", -28, 0)

            line:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")

            local preview = line:CreateTexture(nil, "ARTWORK")
            preview:SetPoint("LEFT", line, "LEFT", 6, 0)
            preview:SetSize(120, 12)
            line.preview = preview

            local text = line:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            text:SetPoint("LEFT", preview, "RIGHT", 8, 0)
            text:SetJustifyH("LEFT")
            line.text = text

            lines[i] = line
        end

        local function Update()
            local offset = FauxScrollFrame_GetOffset(scroll)
            local total = #list
            FauxScrollFrame_Update(scroll, total, maxLines, lineHeight)

            local lsm = nil
            if mediaType then
                local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
                if E and E.Libs and E.Libs.LSM then
                    lsm = E.Libs.LSM
                end
            end

            for i = 1, maxLines do
                local idx = i + offset
                local entry = list[idx]
                local line = lines[i]
                if entry then
                    local tex = entry.key
                    if lsm then
                        tex = lsm:Fetch(mediaType, entry.key) or entry.key
                    end
                    line.preview:SetTexture(tex)
                    line.text:SetText(entry.text)
                    line:Show()
                    line:SetScript("OnClick", function()
                        dropdown:SetValue(entry.key)
                        setValue(entry.key)
                        menu:Hide()
                    end)
                else
                    line:Hide()
                end
            end
        end

        scroll:SetScript("OnVerticalScroll", function(_, offset)
            FauxScrollFrame_OnVerticalScroll(scroll, offset, lineHeight, Update)
        end)
        menu.Update = Update
        dropdown.__ediTextureMenu = menu

        dropdown:HookScript("OnHide", function()
            if menu:IsShown() then
                menu:Hide()
            end
        end)

        return menu
    end

    dropdown:SetScript("OnClick", nil)
    dropdown:SetScript("OnMouseDown", function()
        local menu = EnsureTextureMenu()
        if menu:IsShown() then
            menu:Hide()
        else
            menu:ClearAllPoints()
            menu:SetPoint("TOPLEFT", dropdown, "BOTTOMLEFT", 0, -2)
            menu:Show()
            menu:Update()
        end
    end)

    if not EdiUI.Skin:IsEnabled() then
        if dropdown.Left then dropdown.Left:Hide() end
        if dropdown.Middle then dropdown.Middle:Hide() end
        if dropdown.Right then dropdown.Right:Hide() end
        if dropdown.SetBackdrop then
            dropdown:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            dropdown:SetBackdropColor(0.08, 0.08, 0.1, 1)
            dropdown:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
        dropdown:SetHeight(24)
    else
        EdiUI.Skin:ApplyDropdown(dropdown, dropdown:GetWidth())
    end

    local text = dropdown.Text or _G[dropdown:GetName() .. "Text"]
    if text then
        text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end
    if dropdown.Label then
        dropdown.Label:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end

    self:AddControlBackdrop(parent, dropdown, 14, -14)

    currentYOffset = currentYOffset + 55
    return dropdown
end


function EdiUI:AddButton(parent, label, tooltip, onClick)
    local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
    btn:SetPoint("TOPLEFT", 0, -currentYOffset)
    btn:SetSize(320, 34)
    if not EdiUI.Skin:IsEnabled() then
        btn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        btn:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        btn:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
    else
        EdiUI.Skin:ApplyButton(btn)
    end

    local text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("CENTER")
    text:SetText(label)
    text:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    btn.text = text

    if tooltip then
        btn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(tooltip, 1, 1, 1)
            GameTooltip:Show()
        end)
        btn:SetScript("OnLeave", function()
            GameTooltip:Hide()
        end)
    end

    if not EdiUI.Skin:IsEnabled() then
        btn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.35, 0.7, 1, 1)
        end)
        btn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        end)
    end

    if onClick then
        btn:SetScript("OnClick", onClick)
    end
    currentYOffset = currentYOffset + 40
    return btn
end

function EdiUI:AddEditBox(parent, label, tooltip, getValue, setValue, multiline)
    local edit
    if multiline then
        edit = Sushi.DarkEdit(parent)
        edit:SetHeight(100)
    else
        edit = Sushi.BoxEdit(parent)
    end
    edit:SetPoint("TOPLEFT", 0, -currentYOffset)
    edit:SetWidth(400)
    edit:SetLabel(label)
    if tooltip then edit:SetTip(tooltip) end
    edit:SetText(getValue() or "")
    edit:SetCall('OnTextChanged', function(self)
        setValue(self:GetText())
    end)
    if EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyEditBox(edit)
    end
    currentYOffset = currentYOffset + (multiline and 130 or 50)
    return edit
end

function EdiUI:AddDropdownRow(parent, left, right, noBackdrop)
    local row = CreateFrame("Frame", nil, parent)
    row:SetPoint("TOPLEFT", CONTROL_INSET_X, -currentYOffset)
    row:SetSize(CONTROL_BG_WIDTH, 36)
    row.__ediBgWidth = CONTROL_BG_WIDTH
    row.__ediBgPad = 0

    local width = math.floor((CONTROL_BG_WIDTH - CONTROL_ROW_GAP - (CONTROL_ROW_PADDING * 2)) / 2)

    local leftDrop = Sushi.DropChoice(row)
    leftDrop:SetPoint("TOPLEFT", CONTROL_ROW_PADDING, 0)
    leftDrop.__ediWidth = width
    leftDrop:SetWidth(width)
    leftDrop:SetLabel(left.label)
    if left.tooltip then leftDrop:SetTip(left.tooltip) end
    for value, displayText in pairs(left.options) do
        leftDrop:Add(value, displayText)
    end
    leftDrop:SetValue(left.get())
    leftDrop:SetCall('OnInput', function(self, value) left.set(value) end)
    leftDrop:SetCall('OnValue', function(self, value) left.set(value) end)
    leftDrop:SetScript("OnClick", nil)
    leftDrop:SetScript("OnMouseDown", function(self)
        if self.OnClick then
            self:OnClick()
        end
    end)
    if not EdiUI.Skin:IsEnabled() then
        if leftDrop.Left then leftDrop.Left:Hide() end
        if leftDrop.Middle then leftDrop.Middle:Hide() end
        if leftDrop.Right then leftDrop.Right:Hide() end
        if leftDrop.SetBackdrop then
            leftDrop:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            leftDrop:SetBackdropColor(0.08, 0.08, 0.1, 1)
            leftDrop:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
        leftDrop:SetHeight(24)
    else
        EdiUI.Skin:ApplyDropdown(leftDrop, leftDrop:GetWidth())
    end
    local leftText = leftDrop.Text or _G[leftDrop:GetName() .. "Text"]
    if leftText then
        leftText:SetTextColor(1, 1, 1)
    end
    if leftDrop.Label then
        leftDrop.Label:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end

    local rightDrop = Sushi.DropChoice(row)
    rightDrop:SetPoint("TOPLEFT", leftDrop, "TOPRIGHT", CONTROL_ROW_GAP, 0)
    rightDrop.__ediWidth = width
    rightDrop:SetWidth(width)
    rightDrop:SetLabel(right.label)
    if right.tooltip then rightDrop:SetTip(right.tooltip) end
    for value, displayText in pairs(right.options) do
        rightDrop:Add(value, displayText)
    end
    rightDrop:SetValue(right.get())
    rightDrop:SetCall('OnInput', function(self, value) right.set(value) end)
    rightDrop:SetCall('OnValue', function(self, value) right.set(value) end)
    rightDrop:SetScript("OnClick", nil)
    rightDrop:SetScript("OnMouseDown", function(self)
        if self.OnClick then
            self:OnClick()
        end
    end)
    if not EdiUI.Skin:IsEnabled() then
        if rightDrop.Left then rightDrop.Left:Hide() end
        if rightDrop.Middle then rightDrop.Middle:Hide() end
        if rightDrop.Right then rightDrop.Right:Hide() end
        if rightDrop.SetBackdrop then
            rightDrop:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            rightDrop:SetBackdropColor(0.08, 0.08, 0.1, 1)
            rightDrop:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
        end
        rightDrop:SetHeight(24)
    else
        EdiUI.Skin:ApplyDropdown(rightDrop, rightDrop:GetWidth())
    end
    local rightText = rightDrop.Text or _G[rightDrop:GetName() .. "Text"]
    if rightText then
        rightText:SetTextColor(1, 1, 1)
    end
    if rightDrop.Label then
        rightDrop.Label:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end

    if not noBackdrop then
        self:AddControlBackdrop(parent, row, 8, -10)
    end

    currentYOffset = currentYOffset + 52
    return leftDrop, rightDrop
end

function EdiUI:AddSliderRow(parent, left, right, noBackdrop)
    local row = CreateFrame("Frame", nil, parent)
    row:SetPoint("TOPLEFT", CONTROL_INSET_X, -currentYOffset)
    row:SetSize(CONTROL_BG_WIDTH, 50)
    row.__ediBgWidth = CONTROL_BG_WIDTH
    row.__ediBgPad = 0

    local width = math.floor((CONTROL_BG_WIDTH - CONTROL_ROW_GAP - (CONTROL_ROW_PADDING * 2)) / 2)

    local leftSlider = Sushi.Slider(row, left.label, left.get(), left.min, left.max, left.step)
    leftSlider.__ediWidth = width
    leftSlider:SetPoint("TOPLEFT", CONTROL_ROW_PADDING, 0)
    leftSlider.__ediMin = left.min
    leftSlider.__ediMax = left.max
    if left.min and left.max then
        leftSlider:SetRange(left.min, left.max)
    end
    if left.step then
        leftSlider:SetValueStep(left.step)
        leftSlider:SetObeyStepOnDrag(true)
    end
    if left.tooltip then leftSlider:SetTip(left.tooltip) end
    leftSlider:SetCall('OnInput', function(self, value)
        local val = tonumber(value)
        if not val then return end
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        if self:GetValue() ~= val then
            self.__ediClamp = true
            self:SetValue(val, true)
            self.__ediClamp = nil
        end
        left.set(val)
    end)
    leftSlider:HookScript("OnMouseWheel", function(self, delta)
        local stepVal = self:GetStep() or left.step or 1
        local val = (self:GetValue() or 0) + (stepVal * delta)
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        self.__ediClamp = true
        self:SetValue(val, true)
        self.__ediClamp = nil
    end)
    pcall(StyleSlider, leftSlider)

    local rightSlider = Sushi.Slider(row, right.label, right.get(), right.min, right.max, right.step)
    rightSlider.__ediWidth = width
    rightSlider:SetPoint("TOPLEFT", leftSlider, "TOPRIGHT", CONTROL_ROW_GAP, 0)
    rightSlider.__ediMin = right.min
    rightSlider.__ediMax = right.max
    if right.min and right.max then
        rightSlider:SetRange(right.min, right.max)
    end
    if right.step then
        rightSlider:SetValueStep(right.step)
        rightSlider:SetObeyStepOnDrag(true)
    end
    if right.tooltip then rightSlider:SetTip(right.tooltip) end
    rightSlider:SetCall('OnInput', function(self, value)
        local val = tonumber(value)
        if not val then return end
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        if self:GetValue() ~= val then
            self.__ediClamp = true
            self:SetValue(val, true)
            self.__ediClamp = nil
        end
        right.set(val)
    end)
    rightSlider:HookScript("OnMouseWheel", function(self, delta)
        local stepVal = self:GetStep() or right.step or 1
        local val = (self:GetValue() or 0) + (stepVal * delta)
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        self.__ediClamp = true
        self:SetValue(val, true)
        self.__ediClamp = nil
    end)
    pcall(StyleSlider, rightSlider)

    if not noBackdrop then
        self:AddControlBackdrop(parent, row, 12, -12)
    end

    if EdiUI.Skin:IsEnabled() then
        currentYOffset = currentYOffset + 66
    else
        currentYOffset = currentYOffset + 60
    end

    return leftSlider, rightSlider
end

function EdiUI:AddSliderBare(parent, label, tooltip, minVal, maxVal, step, getValue, setValue, width)
    local slider = Sushi.Slider(parent, label, getValue(), minVal, maxVal, step)
    slider:SetPoint("TOPLEFT", CONTROL_ROW_PADDING, -currentYOffset)
    slider.__ediWidth = width or (CONTROL_BG_WIDTH - (CONTROL_ROW_PADDING * 2) - 60)
    slider:SetWidth(slider.__ediWidth)
    slider.__ediMin = minVal
    slider.__ediMax = maxVal
    if minVal and maxVal then
        slider:SetRange(minVal, maxVal)
    end
    if step then
        slider:SetValueStep(step)
        slider:SetObeyStepOnDrag(true)
    end
    if tooltip then slider:SetTip(tooltip) end
    slider:SetCall('OnInput', function(self, value)
        local val = tonumber(value)
        if not val then
            return
        end
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        if self:GetValue() ~= val then
            self.__ediClamp = true
            self:SetValue(val, true)
            self.__ediClamp = nil
        end
        setValue(val)
    end)
    slider:HookScript("OnMouseWheel", function(self, delta)
        local stepVal = self:GetStep() or step or 1
        local val = (self:GetValue() or 0) + (stepVal * delta)
        local minVal = self.__ediMin or (select(1, self:GetMinMaxValues()))
        local maxVal = self.__ediMax or (select(2, self:GetMinMaxValues()))
        if minVal and maxVal then
            if val < minVal then
                val = minVal
            elseif val > maxVal then
                val = maxVal
            end
        end
        self.__ediClamp = true
        self:SetValue(val, true)
        self.__ediClamp = nil
    end)
    pcall(StyleSlider, slider)
    if EdiUI.Skin:IsEnabled() then
        currentYOffset = currentYOffset + 66
    else
        currentYOffset = currentYOffset + 60
    end
    return slider
end

function EdiUI:AddColorPicker(parent, label, tooltip, getColor, setColor)
    local color = Sushi.ColorPicker(parent)
    color:SetPoint("TOPLEFT", 0, -currentYOffset)
    color:SetLabel(label)
    if tooltip then color:SetTip(tooltip) end
    
    local r, g, b, a = getColor()
    local colorObj
    if type(r) == "table" and r.GetRGB then
        colorObj = r
    elseif type(r) == "table" and r.r then
        if CreateColor then
            colorObj = CreateColor(r.r, r.g, r.b, r.a or 1)
        else
            colorObj = { r = r.r, g = r.g, b = r.b, a = r.a or 1, GetRGB = function(self) return self.r, self.g, self.b end }
        end
    else
        if CreateColor then
            colorObj = CreateColor(r or 1, g or 1, b or 1, a or 1)
        else
            colorObj = { r = r or 1, g = g or 1, b = b or 1, a = a or 1, GetRGB = function(self) return self.r, self.g, self.b end }
        end
    end
    pcall(function() color:SetColor(colorObj) end)
    color:SetCall('OnColor', function(self, value)
        if type(value) == "table" and value.GetRGB then
            local cr, cg, cb = value:GetRGB()
            setColor(cr, cg, cb, value.a)
        elseif type(value) == "table" then
            setColor(value.r, value.g, value.b, value.a)
        else
            setColor(value)
        end
    end)
    currentYOffset = currentYOffset + 30
    return color
end

function EdiUI:GetCurrentYOffset()
    return currentYOffset
end

function EdiUI:SetCurrentYOffset(offset)
    currentYOffset = offset
end

-- ============================================================================
-- PUBLIC API
-- ============================================================================
function EdiUI:OpenOptions()
    if not OptionsFrame then
        self:BuildOptionsPanel()
    end
    OptionsFrame:Show()
end

function EdiUI:CloseOptions()
    if OptionsFrame then
        OptionsFrame:Hide()
    end
end

function EdiUI:ToggleOptions()
    if OptionsFrame and OptionsFrame:IsShown() then
        self:CloseOptions()
    else
        self:OpenOptions()
    end
end
