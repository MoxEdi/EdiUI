-- EdiUI Power Bar Options
local EdiUI = EdiUI

local function BuildPowerBarOptions(parent)
    EdiUI:ResetLayout()

    EdiUI:AddHeader(parent, "Power Bar")
    EdiUI:AddDescription(parent, "Control the player resource bar shown above Essential cooldowns.")
    EdiUI:AddSpacer(parent, 10)

    local db = EdiUI.db.profile.powerBar
    if not db then
        db = {}
        EdiUI.db.profile.powerBar = db
    end

    if db.enabled == nil then db.enabled = true end
    if not db.width then db.width = 320 end
    if not db.height then db.height = 12 end
    if db.offsetX == nil then db.offsetX = 0 end
    if db.offsetY == nil then db.offsetY = 6 end
    if db.matchEssentials == nil then db.matchEssentials = true end
    if db.showText == nil then db.showText = true end
    if db.showMax == nil then db.showMax = false end
    if not db.font then db.font = "Expressway" end
    if not db.fontSize then db.fontSize = 12 end
    if not db.fontOutline then db.fontOutline = "OUTLINE" end
    if db.fontShadow == nil then db.fontShadow = true end
    if db.textOffsetX == nil then db.textOffsetX = 0 end
    if db.textOffsetY == nil then db.textOffsetY = 0 end
    if not db.texture then db.texture = "ElvUI Norm" end
    if db.usePowerColor == nil then db.usePowerColor = true end
    if not db.color then db.color = { r = 0.906, g = 0.298, b = 0.235 } end
    local bar = EdiUI:GetModule("PowerBar", true)

    local function Apply()
        if bar and bar.UpdateAll then
            bar:UpdateAll()
        end
    end

    local function BuildFontList()
        local fonts = {}
        local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
        if E and E.Libs and E.Libs.LSM then
            for name in pairs(E.Libs.LSM:HashTable("font")) do
                fonts[name] = name
            end
        end
        if next(fonts) == nil and db.font then
            fonts[db.font] = db.font
        end
        return fonts
    end

    local function BuildTextureList()
        local textures = {}
        local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
        if E and E.Libs and E.Libs.LSM then
            for name in pairs(E.Libs.LSM:HashTable("statusbar")) do
                textures[name] = name
            end
        end
        if next(textures) == nil and db.texture then
            textures[db.texture] = db.texture
        end
        return textures
    end

    local function AddPanel(title, buildFunc)
        local startYOffset = EdiUI:GetCurrentYOffset()
        local panel = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 6, -startYOffset)
        panel:SetPoint("TOPRIGHT", -6, -startYOffset)
        panel:SetHeight(1)

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyFrame(panel, 'Transparent')
        else
            panel:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            panel:SetBackdropColor(0.05, 0.05, 0.07, 1)
            panel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local outerYOffset = EdiUI:GetCurrentYOffset()
        EdiUI:SetCurrentYOffset(12)
        EdiUI:AddHeader(panel, title)
        EdiUI:AddSpacer(panel, 8)
        buildFunc(panel)
        local panelHeight = EdiUI:GetCurrentYOffset() + 12
        panel:SetHeight(panelHeight)
        EdiUI:SetCurrentYOffset(outerYOffset + panelHeight + 18)
    end

    parent.__ediWidthStateCallbacks = parent.__ediWidthStateCallbacks or {}
    AddPanel("Settings", function(panel)
        EdiUI:AddCheckbox(panel, "Enabled", "Show the power bar above Essential cooldowns.",
            function() return db.enabled end,
            function(val) db.enabled = val Apply() end
        )
        EdiUI:AddCheckbox(panel, "Match Essentials Width", "Match the Essential cooldown bar width.",
            function() return db.matchEssentials end,
            function(val)
                db.matchEssentials = val
                Apply()
                for _, cb in ipairs(parent.__ediWidthStateCallbacks or {}) do
                    cb()
                end
            end
        )
        EdiUI:AddCheckbox(panel, "Show Text", "Show resource percentage on the bar.",
            function() return db.showText end,
            function(val) db.showText = val Apply() end
        )
    end)

    AddPanel("Performance & Visibility", function(panel)
        EdiUI:AddSliderBare(panel, "Update Throttle", "Min time between updates (seconds)", 0.01, 0.2, 0.01,
            function() return db.updateThrottle or 0.05 end,
            function(val) db.updateThrottle = val Apply() end
        )
        EdiUI:AddCheckbox(panel, "Hide When Mounted", "Hide power bar when mounted.",
            function() return db.hideWhenMounted end,
            function(val) db.hideWhenMounted = val Apply() end
        )
        EdiUI:AddCheckbox(panel, "Hide In Vehicle", "Hide power bar when in a vehicle.",
            function() return db.hideInVehicle end,
            function(val) db.hideInVehicle = val Apply() end
        )
        EdiUI:AddCheckbox(panel, "Hide In Pet Battle", "Hide power bar during pet battles.",
            function() return db.hideInPetBattle end,
            function(val) db.hideInPetBattle = val Apply() end
        )
    end)

    AddPanel("Size & Position", function(panel)
        local widthSlider = EdiUI:AddSliderBare(panel, "Width", "Bar width", 180, 700, 1,
            function() return db.width end,
            function(val) db.width = val Apply() end
        )
        local function UpdateWidthState()
            local disabled = db.matchEssentials
            if widthSlider and widthSlider.SetEnabled then
                widthSlider:SetEnabled(not disabled)
            end
            local text = widthSlider and widthSlider.Text or nil
            if text then
                text:SetTextColor(disabled and 0.5 or 1, disabled and 0.5 or 0.78, disabled and 0.5 or 0.29)
            end
            if widthSlider and widthSlider.Edit then
                widthSlider.Edit:SetTextColor(disabled and 0.5 or 1, disabled and 0.5 or 0.78, disabled and 0.5 or 0.29)
            end
        end
        UpdateWidthState()
        EdiUI:AddSliderBare(panel, "Height", "Bar height", 6, 30, 1,
            function() return db.height end,
            function(val) db.height = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "X Offset", "Horizontal offset", -200, 200, 1,
            function() return db.offsetX end,
            function(val) db.offsetX = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "Y Offset", "Vertical offset", -200, 200, 1,
            function() return db.offsetY end,
            function(val) db.offsetY = val Apply() end
        )
        -- expose updater to settings panel
        local parent = panel:GetParent()
        if parent and parent.__ediWidthStateCallbacks then
            table.insert(parent.__ediWidthStateCallbacks, UpdateWidthState)
        end
    end)

    AddPanel("Appearance", function(panel)
        EdiUI:AddTextureDropdown(panel, "Texture", "Status bar texture", BuildTextureList(),
            function() return db.texture end,
            function(val) db.texture = val Apply() end,
            "statusbar"
        )
        EdiUI:AddCheckbox(panel, "Use Power Color", "Use class/spec resource colors.",
            function() return db.usePowerColor end,
            function(val) db.usePowerColor = val Apply() end
        )
        EdiUI:AddColorPicker(panel, "Bar Color", "Bar color when power colors are disabled.",
            function()
                local c = db.color or {}
                return c.r or 0.906, c.g or 0.298, c.b or 0.235, 1
            end,
            function(r, g, b)
                db.color = db.color or {}
                db.color.r = r
                db.color.g = g
                db.color.b = b
                Apply()
            end
        )
    end)

    AddPanel("Font", function(panel)
        EdiUI:AddDropdown(panel, "Font", "Choose a font (ElvUI SharedMedia)", BuildFontList(),
            function() return db.font end,
            function(val) db.font = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "Font Size", "Text size", 8, 24, 1,
            function() return db.fontSize end,
            function(val) db.fontSize = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "Text X Offset", "Horizontal text offset", -50, 50, 1,
            function() return db.textOffsetX end,
            function(val) db.textOffsetX = val Apply() end
        )
        EdiUI:AddSliderBare(panel, "Text Y Offset", "Vertical text offset", -50, 50, 1,
            function() return db.textOffsetY end,
            function(val) db.textOffsetY = val Apply() end
        )
        EdiUI:AddDropdown(panel, "Font Outline", "Outline and shadow", {
            ["NONE"] = "None",
            ["SHADOW"] = "Shadow",
            ["OUTLINE"] = "Outline",
            ["OUTLINE_SHADOW"] = "Outline + Shadow",
            ["THICKOUTLINE"] = "Thick Outline",
            ["THICKOUTLINE_SHADOW"] = "Thick Outline + Shadow",
        }, function()
            if db.fontShadow and db.fontOutline == "THICKOUTLINE" then
                return "THICKOUTLINE_SHADOW"
            end
            if db.fontShadow and db.fontOutline == "OUTLINE" then
                return "OUTLINE_SHADOW"
            end
            if db.fontShadow and (db.fontOutline == "NONE" or not db.fontOutline) then
                return "SHADOW"
            end
            return db.fontOutline or "OUTLINE"
        end, function(val)
            if val == "SHADOW" then
                db.fontOutline = "NONE"
                db.fontShadow = true
            elseif val == "OUTLINE_SHADOW" then
                db.fontOutline = "OUTLINE"
                db.fontShadow = true
            elseif val == "THICKOUTLINE_SHADOW" then
                db.fontOutline = "THICKOUTLINE"
                db.fontShadow = true
            else
                db.fontOutline = val
                db.fontShadow = false
            end
            Apply()
        end)
    end)

    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        EdiUI:RegisterOptionsTab("powerbar", "Power Bar", BuildPowerBarOptions, 7)
    end
end)
