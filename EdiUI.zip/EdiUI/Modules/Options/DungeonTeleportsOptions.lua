-- EdiUI Dungeon Teleports Options
local EdiUI = EdiUI

local Data = EdiUI.DungeonPortalData

local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.dungeonTeleports
end

local function BuildDungeonTeleportsOptions(parent)
    EdiUI:ResetLayout()
    EdiUI:AddHeader(parent, "Dungeon Teleports")
    EdiUI:AddDescription(parent, "Shows dungeon teleport buttons when opening the Group Finder. Ported from M+ Dungeon Teleports by peepoStudy.")
    EdiUI:AddSpacer(parent, 10)

    local function ApplyUpdate()
        local mod = EdiUI:GetModule("DungeonTeleports", true)
        if mod and mod.Update then
            mod:Update()
        end
    end

    local function AddPanel(title, buildFunc)
        local startYOffset = EdiUI:GetCurrentYOffset()
        local panel = CreateFrame("Frame", nil, parent, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 6, -startYOffset)
        panel:SetPoint("TOPRIGHT", -6, -startYOffset)
        panel:SetHeight(1)

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyFrame(panel, 'Transparent')
        else
            panel:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            panel:SetBackdropColor(0.05, 0.05, 0.07, 1)
            panel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local outerYOffset = EdiUI:GetCurrentYOffset()
        EdiUI:SetCurrentYOffset(12)
        EdiUI:AddHeader(panel, title)
        EdiUI:AddSpacer(panel, 8)
        buildFunc(panel)
        local panelHeight = EdiUI:GetCurrentYOffset() + 12
        panel:SetHeight(panelHeight)
        EdiUI:SetCurrentYOffset(outerYOffset + panelHeight + 18)
    end

    -- General Settings Panel
    AddPanel("General Settings", function(panel)
        EdiUI:AddCheckbox(panel, "Enabled", "Show dungeon teleport buttons when Group Finder is open.",
            function()
                local db = GetDb()
                return db and db.enabled
            end,
            function(value)
                local db = GetDb()
                if not db then return end
                db.enabled = value and true or false
                ApplyUpdate()
            end
        )

        EdiUI:AddCheckbox(panel, "Show Tooltips", "Display spell tooltips when hovering buttons.",
            function()
                local db = GetDb()
                return db and db.showTooltips
            end,
            function(value)
                local db = GetDb()
                if not db then return end
                db.showTooltips = value and true or false
            end
        )

        EdiUI:AddCheckbox(panel, "Darken Locked Text", "Gray out text for unavailable teleports.",
            function()
                local db = GetDb()
                return db and db.darkenText
            end,
            function(value)
                local db = GetDb()
                if not db then return end
                db.darkenText = value and true or false
                local mod = EdiUI:GetModule("DungeonTeleports", true)
                if mod and mod.UpdateFonts then
                    mod:UpdateFonts()
                end
            end
        )
    end)

    -- Text Size Panel
    AddPanel("Text Settings", function(panel)
        EdiUI:AddSliderBare(panel, "Title Size", "Size of the main title text.", 8, 20, 1,
            function()
                local db = GetDb()
                return db and db.titleFontSize or 12
            end,
            function(value)
                local db = GetDb()
                if not db then return end
                db.titleFontSize = value
                local mod = EdiUI:GetModule("DungeonTeleports", true)
                if mod and mod.UpdateFonts then
                    mod:UpdateFonts()
                end
            end
        )

        EdiUI:AddSliderBare(panel, "Expansion Size", "Size of expansion header text.", 8, 20, 1,
            function()
                local db = GetDb()
                return db and db.expansionFontSize or 12
            end,
            function(value)
                local db = GetDb()
                if not db then return end
                db.expansionFontSize = value
                local mod = EdiUI:GetModule("DungeonTeleports", true)
                if mod and mod.UpdateFonts then
                    mod:UpdateFonts()
                end
            end
        )

        EdiUI:AddSliderBare(panel, "Button Text Size", "Size of dungeon name text.", 8, 16, 1,
            function()
                local db = GetDb()
                return db and db.buttonFontSize or 11
            end,
            function(value)
                local db = GetDb()
                if not db then return end
                db.buttonFontSize = value
                local mod = EdiUI:GetModule("DungeonTeleports", true)
                if mod and mod.UpdateFonts then
                    mod:UpdateFonts()
                end
            end
        )
    end)

    -- Expansion Visibility Panel
    AddPanel("Expansion Visibility", function(panel)
        if not Data or not Data.Expansions then return end

        for _, expansion in ipairs(Data.Expansions) do
            EdiUI:AddCheckbox(panel, expansion.title, "Show " .. expansion.title .. " dungeons.",
                function()
                    local db = GetDb()
                    if not db or not db.expansionVisibility then return true end
                    local val = db.expansionVisibility[expansion.key]
                    if val == nil then return true end
                    return val
                end,
                function(value)
                    local db = GetDb()
                    if not db then return end
                    db.expansionVisibility = db.expansionVisibility or {}
                    db.expansionVisibility[expansion.key] = value and true or false
                    local mod = EdiUI:GetModule("DungeonTeleports", true)
                    if mod and mod.UpdateLayout then
                        mod:UpdateLayout()
                    end
                end
            )
        end
    end)

    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        EdiUI:RegisterOptionsTab("dungeonteleports", "Dungeon Teleports", BuildDungeonTeleportsOptions, 11)
    end
end)
