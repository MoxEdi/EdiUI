-- EdiUI Profile Options
-- Profile management and import/export using Sushi framework
local EdiUI = EdiUI
local COLOR_BLUE = { r = 0.906, g = 0.298, b = 0.235 }
local COLOR_GOLD = { r = 1.0, g = 0.78, b = 0.29 }
local BLUE_HEX = "|cffe74c3c"
local GOLD_HEX = "|cffffc84a"

-- Helper to get Profiles module
local function GetProfiles()
    return EdiUI and EdiUI.Profiles
end

-- ============================================================================
-- IMPORT POPUP (reusing the existing popup logic)
-- ============================================================================
local ImportFrame = nil

local function ShowImportPopup()
    if ImportFrame then
        ImportFrame:Show()
        return
    end

    -- Create Main Frame
    local frame = CreateFrame("Frame", "EdiUI_ImportFrame", UIParent, "BackdropTemplate")
    frame:SetSize(500, 400)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("TOOLTIP")
    frame:SetFrameLevel(100)
    frame:SetToplevel(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    
    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        tile = false,
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    frame:SetBackdropColor(0.08, 0.08, 0.1, 0.98)
    frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    
    -- Register reload popup
    if not StaticPopupDialogs["EdiUI_RELOAD"] then
        StaticPopupDialogs["EdiUI_RELOAD"] = {
            text = "Profile imported successfully.\nReload UI to apply changes?",
            button1 = "Reload",
            button2 = "Later",
            OnAccept = ReloadUI,
            timeout = 0,
            whileDead = true,
            hideOnEscape = true,
            preferredIndex = 3,
        }
    end
    
    -- Title bar
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(35)
    titleBar:SetPoint("TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", 0, 0)
    titleBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    titleBar:SetBackdropColor(0.12, 0.12, 0.15, 1)
    
    -- Title
    local title = titleBar:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("LEFT", 15, 0)
    title:SetText(BLUE_HEX .. "Import " .. GOLD_HEX .. "Profile|r")
    
    -- Close Button
    local close = CreateFrame("Button", nil, titleBar)
    close:SetSize(25, 25)
    close:SetPoint("RIGHT", -5, 0)
    close:SetNormalFontObject("GameFontNormalLarge")
    close:SetText("X")
    close:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    close:SetScript("OnClick", function() frame:Hide() end)
    close:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b) end)
    close:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b) end)
    
    -- Instructions
    local desc = frame:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    desc:SetPoint("TOP", 0, -50)
    desc:SetText("Paste the profile string below (Ctrl+V) and click Import.")
    desc:SetTextColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b)
    
    -- ScrollFrame + EditBox
    local scrollFrame = CreateFrame("ScrollFrame", "EdiUI_ImportScrollFrame", frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 20, -75)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 60)
    
    local editBox = CreateFrame("EditBox", nil, scrollFrame)
    editBox:SetSize(430, 280)
    editBox:SetMultiLine(true)
    editBox:SetFontObject("ChatFontNormal")
    editBox:SetAutoFocus(true)
    editBox:SetScript("OnEscapePressed", function() frame:Hide() end)
    
    scrollFrame:SetScrollChild(editBox)
    
    -- Import Button
    local importBtn = CreateFrame("Button", nil, frame, "BackdropTemplate")
    importBtn:SetSize(120, 30)
    importBtn:SetPoint("BOTTOM", 0, 15)
    if not (EdiUI.Skin and EdiUI.Skin:IsEnabled()) then
        importBtn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        importBtn:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        importBtn:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
    else
        EdiUI.Skin:ApplyButton(importBtn)
    end
    
    local btnText = importBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    btnText:SetPoint("CENTER")
    btnText:SetText("Import")
    btnText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    
    if not (EdiUI.Skin and EdiUI.Skin:IsEnabled()) then
        importBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.35, 0.7, 1, 1)
        end)
        importBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        end)
    end
    importBtn:SetScript("OnClick", function()
        local text = editBox:GetText()
        if not text or text:gsub("%s+", "") == "" then
            EdiUI:Print("|cffff0000No text to import.|r")
            return
        end

        local Profiles = GetProfiles()
        if not Profiles then
            EdiUI:Print("|cffff0000Profiles module not loaded! Try /reload|r")
            return
        end

        -- First validate
        local validOk, validErr = Profiles:Validate(text)
        if not validOk then
            EdiUI:Print("|cffff0000Validation failed: " .. (validErr or "Unknown error") .. "|r")
            return
        end

        -- Then import
        local ok, err = Profiles:Import(text)
        if ok then
            frame:Hide()
            EdiUI:Print("|cff00ff00Profile imported successfully!|r")
            StaticPopup_Show("EdiUI_RELOAD")
        else
            EdiUI:Print("|cffff0000Import failed: " .. (err or "Unknown error") .. "|r")
        end
    end)
    
    if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(frame, 'Transparent')
        EdiUI.Skin:ApplyFrame(titleBar, 'Transparent')
        EdiUI.Skin:ApplyCloseButton(close)
        if scrollFrame.ScrollBar then
            EdiUI.Skin:ApplyScrollBar(scrollFrame.ScrollBar)
        end
        if editBox then
            EdiUI.Skin:ApplyEditBox(editBox)
        end
    end

    -- ESC to close
    tinsert(UISpecialFrames, "EdiUI_ImportFrame")
    
    ImportFrame = frame
end

-- ============================================================================
-- BUILD HOME/WELCOME TAB
-- ============================================================================
local function BuildHomeOptions(parent)
    EdiUI:ResetLayout()
    
    -- Banner image
    local bannerPath = "Interface\\AddOns\\EdiUI\\Media\\Banner\\ediui"
    local banner = parent:CreateTexture(nil, "ARTWORK")
    banner:SetPoint("TOP", parent, "TOP", 0, 10)
    banner:SetSize(321, 173)
    banner:SetTexture(bannerPath)
    EdiUI:SetCurrentYOffset(EdiUI:GetCurrentYOffset() + 150)
    
    EdiUI:AddSpacer(parent, 0)
    
    -- Welcome header
    local welcome = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalHuge")
    welcome:SetPoint("TOP", parent, "TOP", 0, -EdiUI:GetCurrentYOffset() - 10)
    welcome:SetText(GOLD_HEX .. "Welcome!|r")
    welcome:SetJustifyH("CENTER")
    local font, _, flags = welcome:GetFont()
    if font then
        welcome:SetFont(font, 26, flags)
    end
    EdiUI:SetCurrentYOffset(EdiUI:GetCurrentYOffset() + 100)
    
    -- Features
    local featuresHeader = EdiUI:AddHeader(parent, "Features")
    featuresHeader:SetText(GOLD_HEX .. "Features|r")
    EdiUI:AddDescription(parent,
        GOLD_HEX .. "•|r " .. BLUE_HEX .. "Profiles|r - Easy import strings for ElvUI, Details, and EditMode."
    )
    EdiUI:AddSpacer(parent, 5)

    -- Version info (bottom-left)
    EdiUI:SetCurrentYOffset(EdiUI:GetCurrentYOffset() + 100)
    local versionText = EdiUI:AddDescription(parent, "|cff888888Version: " .. (EdiUI.Version or "1.0") .. "|r")
    local createdText = EdiUI:AddDescription(parent, "|cff888888Created by Editor|r")
    local font, _, flags = versionText:GetFont()
    if font then
        versionText:SetFont(font, 11, flags)
        createdText:SetFont(font, 11, flags)
    end
    
    -- Set content height
    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

-- ============================================================================
-- BUILD RESET TAB
-- ============================================================================
local function BuildResetOptions(parent)
    EdiUI:ResetLayout()

    EdiUI:AddHeader(parent, "Reset Installer")
    EdiUI:AddDescription(parent, BLUE_HEX .. "Reset the installer so it opens like a fresh install.|r")
    EdiUI:AddSpacer(parent, 10)

    EdiUI:AddButton(parent,
        "Reset Installer",
        "Reset installer progress and reopen it",
        function()
            if EdiUI.Installer and EdiUI.Installer.Reset then
                EdiUI.Installer:Reset()
            else
                EdiUI:Print("Installer not available yet. Please wait a moment and try again.")
            end
        end
    )

    parent:SetHeight(EdiUI:GetCurrentYOffset() + 40)
end

-- ============================================================================
-- BUILD PROFILE IMPORT/EXPORT TAB
-- ============================================================================
local exportEditBox = nil

local function BuildProfileOptions(parent)
    EdiUI:ResetLayout()

    -- Header
    EdiUI:AddHeader(parent, "Profile Import/Export")
    EdiUI:AddDescription(parent, "Export your current profile as text to share, or paste a string to import.")
    EdiUI:AddSpacer(parent, 10)

    -- System Status
    local Profiles = GetProfiles()
    if Profiles then
        local libsAvailable = Profiles:LibrariesAvailable()
        if libsAvailable then
            EdiUI:AddDescription(parent, "|cff00ff00System Status: Ready|r")
        else
            EdiUI:AddDescription(parent, "|cffff0000System Status: Libraries not loaded! Try /reload|r")
        end
    else
        EdiUI:AddDescription(parent, "|cffff0000Profiles module not loaded!|r")
    end

    -- Test button
    EdiUI:AddButton(parent,
        "Test System",
        "Run diagnostics on the export/import system",
        function()
            local Profiles = GetProfiles()
            if Profiles and Profiles.Test then
                Profiles:Test()
            else
                EdiUI:Print("Profiles module not available")
            end
        end
    )

    EdiUI:AddSpacer(parent, 15)
    
    -- Export section
    EdiUI:AddHeader(parent, "Export Current Profile")
    EdiUI:AddDescription(parent, "Click the text box below and press Ctrl+A to select all, then Ctrl+C to copy.")
    EdiUI:AddSpacer(parent, 5)
    
    -- Export editbox
    local Sushi = LibStub('Sushi-3.2')
    
    local exportFrame = CreateFrame("Frame", nil, parent, "BackdropTemplate")
    exportFrame:SetPoint("TOPLEFT", 0, -EdiUI:GetCurrentYOffset())
    exportFrame:SetSize(560, 120)
    exportFrame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    exportFrame:SetBackdropColor(0.05, 0.05, 0.07, 1)
    exportFrame:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
    
    local scrollFrame = CreateFrame("ScrollFrame", nil, exportFrame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 5, -5)
    scrollFrame:SetPoint("BOTTOMRIGHT", -25, 5)
    
    exportEditBox = CreateFrame("EditBox", nil, scrollFrame)
    exportEditBox:SetSize(520, 100)
    exportEditBox:SetMultiLine(true)
    exportEditBox:SetFontObject("ChatFontNormal")
    exportEditBox:SetAutoFocus(false)
    scrollFrame:SetScrollChild(exportEditBox)

    if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(exportFrame, 'Transparent')
        if scrollFrame.ScrollBar then
            EdiUI.Skin:ApplyScrollBar(scrollFrame.ScrollBar)
        end
        EdiUI.Skin:ApplyEditBox(exportEditBox)
    end
    
    EdiUI:SetCurrentYOffset(EdiUI:GetCurrentYOffset() + 130)
    
    -- Refresh button
    EdiUI:AddButton(parent,
        "Generate Export String",
        "Generate a new export string from current profile",
        function()
            local Profiles = GetProfiles()
            if not Profiles then
                EdiUI:Print("|cffff0000Profiles module not loaded!|r")
                return
            end

            local str, err = Profiles:Export()
            if str and type(str) == "string" then
                exportEditBox:SetText(str)
                exportEditBox:HighlightText()
                exportEditBox:SetFocus()
                EdiUI:Print("|cff00ff00Profile exported! (" .. #str .. " characters) Press Ctrl+A then Ctrl+C to copy.|r")
            else
                EdiUI:Print(GOLD_HEX .. "Export failed: " .. (err or "Unknown error") .. "|r")
            end
        end
    )
    
    EdiUI:AddSpacer(parent, 20)
    
    -- Import section
    EdiUI:AddHeader(parent, "Import Profile")
    EdiUI:AddDescription(parent, GOLD_HEX .. "Warning: Importing will overwrite your current profile!|r")
    EdiUI:AddSpacer(parent, 5)
    
    EdiUI:AddButton(parent,
        "Open Import Window",
        "Open a window to paste and import a profile string",
        function()
            ShowImportPopup()
        end
    )
    
    -- Set content height
    parent:SetHeight(EdiUI:GetCurrentYOffset() + 40)
end

-- ============================================================================
-- BUILD ADDON STRINGS TAB
-- ============================================================================
local function BuildAddonStringsOptions(parent)
    EdiUI:ResetLayout()
    
    -- Header
    EdiUI:AddHeader(parent, "Addon Import Strings")
    EdiUI:AddDescription(parent, "Copy these strings to import settings into other addons.")
    EdiUI:AddSpacer(parent, 15)
    
    -- Get import strings from Profiles module
    local Profiles = GetProfiles()
    if not Profiles or not Profiles.ImportStrings then
        EdiUI:AddDescription(parent, BLUE_HEX .. "No import strings available.|r")
        parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
        return
    end
    
    local displayNames = {
        ["Details"] = "Details! Damage Meter",
        ["EditMode"] = "Blizzard EditMode",
        ["ElvUI"] = "ElvUI Profile",
        ["ElvUIDark"] = "ElvUI Dark Profile",
        ["ElvUIAuras"] = "ElvUI Auras",
        ["ElvUIPrivate"] = "ElvUI Private",
        ["ElvUIGlobal"] = "ElvUI Global",
        ["Plater"] = "Plater Profile",
    }
    
    local sortedKeys = {
        "Details",
        "Plater",
        "EditMode",
        "ElvUI",
        "ElvUIDark",
        "ElvUIAuras",
        "ElvUIPrivate",
        "ElvUIGlobal",
    }

    local textOnlyKeys = {
        ["EditMode"] = true,
    }
    
    for _, key in ipairs(sortedKeys) do
        local content = Profiles.ImportStrings[key]
        EdiUI:AddHeader(parent, displayNames[key] or key)
        
        if not textOnlyKeys[key] then
            local buttonLabel = "Apply " .. (displayNames[key] or key)
            EdiUI:AddButton(parent, buttonLabel, "Apply this profile now", function()
                local ok, err
                if key == "ElvUI" then
                    ok, err = Profiles:ImportElvUIProfile()
                elseif key == "ElvUIDark" then
                    ok, err = Profiles:ImportElvUIDarkProfile()
                elseif key == "ElvUIAuras" then
                    ok, err = Profiles:ImportElvUIAuras()
                elseif key == "ElvUIPrivate" then
                    ok, err = Profiles:ImportElvUIPrivate()
                elseif key == "ElvUIGlobal" then
                    ok, err = Profiles:ImportElvUIGlobal()
                elseif key == "Details" then
                    ok, err = Profiles:ImportDetailsProfile()
                elseif key == "Plater" then
                    ok, err = Profiles:ImportPlaterProfile()
                end
                if ok then
                    EdiUI:Print(BLUE_HEX .. (displayNames[key] or key) .. " applied.|r")
                else
                    EdiUI:Print(GOLD_HEX .. (displayNames[key] or key) .. " failed: " .. (err or "Unknown error") .. "|r")
                end
            end)
            EdiUI:AddSpacer(parent, 5)
        elseif content and content ~= "" then
            -- Create editbox for this string
            local frame = CreateFrame("Frame", nil, parent, "BackdropTemplate")
            frame:SetPoint("TOPLEFT", 0, -EdiUI:GetCurrentYOffset())
            frame:SetSize(560, 80)
            frame:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            frame:SetBackdropColor(0.05, 0.05, 0.07, 1)
            frame:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
            
            local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
            scrollFrame:SetPoint("TOPLEFT", 5, -5)
            scrollFrame:SetPoint("BOTTOMRIGHT", -25, 5)
            
            local editBox = CreateFrame("EditBox", nil, scrollFrame)
            editBox:SetSize(520, 70)
            editBox:SetMultiLine(true)
            editBox:SetFontObject("ChatFontNormal")
            editBox:SetAutoFocus(false)
            editBox:SetText(content)
            editBox:SetScript("OnEditFocusGained", function(self)
                self:HighlightText()
            end)
            scrollFrame:SetScrollChild(editBox)

            if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
                EdiUI.Skin:ApplyFrame(frame, 'Transparent')
                if scrollFrame.ScrollBar then
                    EdiUI.Skin:ApplyScrollBar(scrollFrame.ScrollBar)
                end
                EdiUI.Skin:ApplyEditBox(editBox)
            end
            
            EdiUI:SetCurrentYOffset(EdiUI:GetCurrentYOffset() + 90)
        else
            EdiUI:AddDescription(parent, BLUE_HEX .. "No import string available.|r")
        end
        
        EdiUI:AddSpacer(parent, 10)
    end
    
    -- Set content height
    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

-- ============================================================================
-- BUILD AceDB PROFILE MANAGEMENT TAB
-- ============================================================================
local function AddPanel(container, title, buildFunc)
    local startYOffset = EdiUI:GetCurrentYOffset()
    local panel = CreateFrame("Frame", nil, container, "BackdropTemplate")
    panel:SetPoint("TOPLEFT", 6, -startYOffset)
    panel:SetPoint("TOPRIGHT", -6, -startYOffset)
    panel:SetHeight(1)

    if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(panel, 'Transparent')
    else
        panel:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        panel:SetBackdropColor(0.05, 0.05, 0.07, 1)
        panel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
    end

    local outerYOffset = EdiUI:GetCurrentYOffset()
    EdiUI:SetCurrentYOffset(12)
    EdiUI:AddHeader(panel, title)
    EdiUI:AddSpacer(panel, 8)
    buildFunc(panel)
    local panelHeight = EdiUI:GetCurrentYOffset() + 12
    panel:SetHeight(panelHeight)
    EdiUI:SetCurrentYOffset(outerYOffset + panelHeight + 18)
end

local function BuildProfileManagement(parent)
    EdiUI:ResetLayout()

    -- Header
    EdiUI:AddHeader(parent, "EdiUI Profiles")
    EdiUI:AddDescription(parent, "Manage your EdiUI profiles. Changes take effect immediately.")
    EdiUI:AddSpacer(parent, 15)

    -- Current profile info
    local currentProfile = EdiUI.db and EdiUI.db:GetCurrentProfile() or "Default"
    EdiUI:AddDescription(parent, GOLD_HEX .. "Current Profile:|r " .. currentProfile)
    EdiUI:AddSpacer(parent, 15)

    -- Profile selection dropdown
    AddPanel(parent, "Switch Profile", function(panel)
        local profiles = {}
        if EdiUI.db then
            for _, name in pairs(EdiUI.db:GetProfiles()) do
                profiles[name] = name
            end
        end

        local dropdown = EdiUI:AddDropdown(panel,
            "Select Profile",
            "Choose a profile to switch to",
            profiles,
            function() return EdiUI.db and EdiUI.db:GetCurrentProfile() or "Default" end,
            function(val)
                if EdiUI.db then
                    EdiUI.db:SetProfile(val)
                    EdiUI:Print("Switched to profile: " .. val)
                end
            end,
            true  -- noBackdrop
        )
        dropdown:ClearAllPoints()
        dropdown:SetPoint("TOPLEFT", 12, -EdiUI:GetCurrentYOffset() + 55)
    end)

    -- Profile actions
    AddPanel(parent, "Profile Actions", function(panel)
        -- Create New Profile
        local btn1 = EdiUI:AddButton(panel,
            "Create New Profile",
            "Create a new profile with default settings",
            function()
                StaticPopupDialogs["EdiUI_NEW_PROFILE"] = {
                    text = "Enter a name for the new profile:",
                    button1 = "Create",
                    button2 = "Cancel",
                    hasEditBox = true,
                    editBoxWidth = 200,
                    OnAccept = function(self)
                        local name = self.EditBox:GetText()
                        if name and name ~= "" and EdiUI.db then
                            EdiUI.db:SetProfile(name)
                            EdiUI:Print("Created and switched to profile: " .. name)
                            ReloadUI()
                        end
                    end,
                    OnShow = function(self)
                        self.EditBox:SetText("")
                        self.EditBox:SetFocus()
                    end,
                    EditBoxOnEnterPressed = function(self)
                        local popup = self:GetParent()
                        local name = popup.EditBox:GetText()
                        if name and name ~= "" and EdiUI.db then
                            EdiUI.db:SetProfile(name)
                            EdiUI:Print("Created and switched to profile: " .. name)
                            popup:Hide()
                            ReloadUI()
                        end
                    end,
                    timeout = 0,
                    whileDead = true,
                    hideOnEscape = true,
                    preferredIndex = 3,
                }
                StaticPopup_Show("EdiUI_NEW_PROFILE")
            end
        )
        btn1:ClearAllPoints()
        btn1:SetPoint("TOPLEFT", 12, -EdiUI:GetCurrentYOffset() + 40)
        EdiUI:AddSpacer(panel, 10)

        local copyOptions = {}
        if EdiUI.db then
            for _, name in pairs(EdiUI.db:GetProfiles()) do
                if name ~= currentProfile then
                    copyOptions[name] = name
                end
            end
        end
        if next(copyOptions) then
            local dropdown1 = EdiUI:AddDropdown(panel,
                "Copy From",
                "Copy settings from another profile",
                copyOptions,
                function() return nil end,
                function(val)
                    if EdiUI.db and val then
                        EdiUI.db:CopyProfile(val)
                        EdiUI:Print("Copied profile: " .. val)
                    end
                end,
                true  -- noBackdrop
            )
            dropdown1:ClearAllPoints()
            dropdown1:SetPoint("TOPLEFT", 12, -EdiUI:GetCurrentYOffset() + 55)
        else
            EdiUI:AddDescription(panel, BLUE_HEX .. "No other profiles to copy from.|r")
        end
        EdiUI:AddSpacer(panel, 10)

        local btn2 = EdiUI:AddButton(panel,
            "Reset Profile",
            "Reset current profile to defaults",
            function()
                if EdiUI.db then
                    StaticPopupDialogs["EdiUI_RESET_PROFILE"] = {
                        text = "Are you sure you want to reset your profile to defaults?",
                        button1 = "Yes",
                        button2 = "No",
                        OnAccept = function()
                            EdiUI.db:ResetProfile()
                            ReloadUI()
                        end,
                        timeout = 0,
                        whileDead = true,
                        hideOnEscape = true,
                    }
                    StaticPopup_Show("EdiUI_RESET_PROFILE")
                end
            end
        )
        btn2:ClearAllPoints()
        btn2:SetPoint("TOPLEFT", 12, -EdiUI:GetCurrentYOffset() + 40)
        EdiUI:AddSpacer(panel, 10)

        local deleteOptions = {}
        if EdiUI.db then
            for _, name in pairs(EdiUI.db:GetProfiles()) do
                if name ~= currentProfile and name ~= "Edi" then
                    deleteOptions[name] = name
                end
            end
        end
        if next(deleteOptions) then
            local dropdown2 = EdiUI:AddDropdown(panel,
                "Delete Profile",
                "Delete a profile (cannot delete current or Edi)",
                deleteOptions,
                function() return nil end,
                function(val)
                    if not (EdiUI.db and val) then return end
                    StaticPopupDialogs["EdiUI_DELETE_PROFILE"] = {
                        text = "Delete profile '" .. val .. "'?",
                        button1 = "Delete",
                        button2 = "Cancel",
                        OnAccept = function()
                            EdiUI.db:DeleteProfile(val)
                            EdiUI:Print("Deleted profile: " .. val)
                            ReloadUI()
                        end,
                        timeout = 0,
                        whileDead = true,
                        hideOnEscape = true,
                        preferredIndex = 3,
                    }
                    StaticPopup_Show("EdiUI_DELETE_PROFILE")
                end,
                true  -- noBackdrop
            )
            dropdown2:ClearAllPoints()
            dropdown2:SetPoint("TOPLEFT", 12, -EdiUI:GetCurrentYOffset() + 55)
        end
        EdiUI:AddSpacer(panel, 10)

        local playerName = UnitName("player")
        local realmName = GetRealmName()
        if playerName and realmName then
            local btn3 = EdiUI:AddButton(panel,
                "Use Character Profile",
                "Switch to a profile for this character only",
                function()
                    if not EdiUI.db then return end
                    local charProfile = playerName .. " - " .. realmName
                    EdiUI.db:SetProfile(charProfile)
                    EdiUI:Print("Switched to character profile: " .. charProfile)
                    ReloadUI()
                end
            )
            btn3:ClearAllPoints()
            btn3:SetPoint("TOPLEFT", 12, -EdiUI:GetCurrentYOffset() + 40)
        end
    end)
    
    -- Set content height
    parent:SetHeight(EdiUI:GetCurrentYOffset() + 40)
end

-- ============================================================================
-- REGISTER TABS
-- ============================================================================
C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        -- Home tab removed
        EdiUI:RegisterOptionsTab("ediprofiles", "EdiUI Profiles", BuildProfileManagement, 11)
        EdiUI:RegisterOptionsTab("addonstrings", "Addons Profiles", BuildAddonStringsOptions, 12)
        EdiUI:RegisterOptionsTab("reset", "Reset", BuildResetOptions, 13)
    end
end)
