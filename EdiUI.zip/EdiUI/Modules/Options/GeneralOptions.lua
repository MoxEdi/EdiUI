-- EdiUI General Options
-- General UI settings tab using Sushi framework
local EdiUI = EdiUI

-- Helper to get General module
local function GetGeneral()
    return EdiUI and EdiUI.General
end

-- Build the General options content
local function BuildGeneralOptions(parent)
    EdiUI:ResetLayout()
    
    -- Header
    EdiUI:AddHeader(parent, "General UI Settings")
    EdiUI:AddDescription(parent, "Miscellaneous UI tweaks and customizations.")
    EdiUI:AddSpacer(parent, 10)
    
    -- Action Bars Section
    EdiUI:AddHeader(parent, "Action Bars")
    
    EdiUI:AddCheckbox(parent,
        "Hide Stance Bar",
        "Completely hide the stance/shapeshift bar",
        function() return EdiUI.db.profile.general.hideStanceBar end,
        function(val)
            EdiUI.db.profile.general.hideStanceBar = val
            local General = GetGeneral()
            if General and General.UpdateStanceBar then
                General:UpdateStanceBar()
            end
        end
    )
    
    EdiUI:AddCheckbox(parent,
        "Micro Menu Mouseover",
        "Only show the Micro Menu (Game Menu, Character Info, etc.) when hovering over it",
        function() return EdiUI.db.profile.general.microMenuMouseover end,
        function(val)
            EdiUI.db.profile.general.microMenuMouseover = val
            local General = GetGeneral()
            if General and General.UpdateMicroMenuMouseover then
                General:UpdateMicroMenuMouseover()
            end
        end
    )
    
    EdiUI:AddSpacer(parent, 10)
    
    -- Minimap Section
    EdiUI:AddHeader(parent, "Minimap")
    
    EdiUI:AddCheckbox(parent,
        "Minimap Border",
        "Add a 1px black border around the minimap",
        function() return EdiUI.db.profile.general.minimapBorder end,
        function(val)
            EdiUI.db.profile.general.minimapBorder = val
            local General = GetGeneral()
            if General and General.UpdateMinimapBorder then
                General:UpdateMinimapBorder()
            end
        end
    )
    
    -- Set content height
    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

-- Register the tab when addon loads
-- Tab registration removed per configuration.
