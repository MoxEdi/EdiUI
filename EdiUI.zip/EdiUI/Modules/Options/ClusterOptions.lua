-- EdiUI Cluster Positioning Options
local EdiUI = EdiUI

local function GetCluster()
    return EdiUI and EdiUI:GetModule("ClusterPositioning", true)
end

local function BuildClusterOptions(parent)
    EdiUI:ResetLayout()

    EdiUI:AddHeader(parent, "Cluster Positioning")
    EdiUI:AddDescription(parent, "Anchor ElvUI unit frames to the Essential Cooldown Viewer.")
    EdiUI:AddDescription(parent, "|cffff4040Warning:|r This overrides ElvUI unit frame positioning.")
    EdiUI:AddSpacer(parent, 10)

    local db = EdiUI.db.profile.clusterPositioning
    local cluster = GetCluster()

    -- Initialize targetCastBar if it doesn't exist
    if not db.targetCastBar then
        db.targetCastBar = {
            enabled = true,
            gap = 1,
            xOffset = 0,
        }
    end
    if db.targetCastBar.enabled == nil then db.targetCastBar.enabled = true end
    if db.targetCastBar.gap == nil then db.targetCastBar.gap = 1 end
    if db.targetCastBar.xOffset == nil then db.targetCastBar.xOffset = 0 end

    local function UpdateCluster()
        if cluster and cluster.UpdateSettings then
            cluster:UpdateSettings()
        end
    end

    local function RecalcCluster()
        if cluster and cluster.Recalculate then
            cluster:Recalculate()
        end
    end

    EdiUI:AddCheckbox(parent,
        "Enable Cluster Positioning",
        "Anchor unit frames to the Essential Cooldown Viewer",
        function() return db.enabled end,
        function(val)
            db.enabled = val
            UpdateCluster()
        end
    )

    EdiUI:AddButton(parent,
        "Recalculate Now",
        "Manually trigger repositioning",
        function()
            RecalcCluster()
        end
    )

    EdiUI:AddSpacer(parent, 10)

    EdiUI:AddHeader(parent, "Icon Settings")
    EdiUI:AddSlider(parent,
        "Essential Icon Width",
        "Width of Essential cooldown icons",
        20, 80, 1,
        function() return db.essentialIconWidth end,
        function(val)
            db.essentialIconWidth = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Essential Icon Padding",
        "Padding between Essential cooldown icons",
        0, 10, 1,
        function() return db.essentialIconPadding end,
        function(val)
            db.essentialIconPadding = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Utility Icon Width",
        "Width of Utility cooldown icons",
        15, 60, 1,
        function() return db.utilityIconWidth end,
        function(val)
            db.utilityIconWidth = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Utility Icon Padding",
        "Padding between Utility cooldown icons",
        0, 10, 1,
        function() return db.utilityIconPadding end,
        function(val)
            db.utilityIconPadding = val
            RecalcCluster()
        end
    )

    EdiUI:AddCheckbox(parent,
        "Account for Utility Overflow",
        "Move frames outward if Utility icons exceed Essential icons",
        function() return db.accountForUtility end,
        function(val)
            db.accountForUtility = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Utility Threshold",
        "How many more Utility icons than Essential to trigger movement",
        1, 10, 1,
        function() return db.utilityThreshold end,
        function(val)
            db.utilityThreshold = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Overflow Offset",
        "Pixels to move each frame outward when overflow triggers",
        10, 200, 5,
        function() return db.utilityOverflowOffset end,
        function(val)
            db.utilityOverflowOffset = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Y Offset",
        "Vertical offset for all frames",
        -100, 100, 1,
        function() return db.yOffset end,
        function(val)
            db.yOffset = val
            RecalcCluster()
        end
    )

    EdiUI:AddSpacer(parent, 10)
    EdiUI:AddHeader(parent, "Target Cast Bar")

    EdiUI:AddCheckbox(parent,
        "Enable Target Cast Bar",
        "Position target cast bar in cluster",
        function() return db.targetCastBar.enabled end,
        function(val)
            db.targetCastBar.enabled = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "X Offset",
        "Horizontal offset from target frame",
        -200, 200, 1,
        function() return db.targetCastBar.xOffset end,
        function(val)
            db.targetCastBar.xOffset = val
            RecalcCluster()
        end
    )

    EdiUI:AddSlider(parent,
        "Y Offset",
        "Vertical offset from target frame",
        -50, 50, 1,
        function() return db.targetCastBar.gap end,
        function(val)
            db.targetCastBar.gap = val
            RecalcCluster()
        end
    )

    parent:SetHeight(EdiUI:GetCurrentYOffset() + 20)
end

C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        EdiUI:RegisterOptionsTab("cluster", "Cluster", BuildClusterOptions, 5)
    end
end)
