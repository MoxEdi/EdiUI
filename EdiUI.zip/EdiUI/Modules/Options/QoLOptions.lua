-- EdiUI Quality of Life Options
local EdiUI = EdiUI

local function GetQoL()
    return EdiUI and EdiUI:GetModule("QoL", true)
end

local function GetCrosshair()
    return EdiUI and EdiUI:GetModule("Crosshair", true)
end

local function BuildQoLOptions(parent)
    EdiUI:ResetLayout()

    EdiUI:AddHeader(parent, "Quality of Life")
    EdiUI:AddDescription(parent, "Automation, social features, and system utilities.")
    EdiUI:AddSpacer(parent, 10)

    local db = EdiUI.db.profile.qol
    local qol = GetQoL()

    local function Apply()
        if qol and qol.ApplySettings then
            qol:ApplySettings()
        end
    end

    local function ApplyCrosshair()
        local crosshair = GetCrosshair()
        if crosshair and crosshair.Update then
            crosshair:Update()
        end
    end

    local tabs = {}
    local tabButtons = {}
    local currentTab
    local tabStartYOffset = 0

    local function CreateSubTabButton(name, index)
        local btn = CreateFrame("Button", nil, parent, "BackdropTemplate")
        btn:SetSize(96, 22)
        btn:SetPoint("TOPLEFT", 0 + (index - 1) * 100, -EdiUI:GetCurrentYOffset())

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyButton(btn)
        else
            btn:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            btn:SetBackdropColor(0.08, 0.08, 0.1, 1)
            btn:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        text:SetPoint("CENTER")
        text:SetText(name)
        text:SetTextColor(1, 0.78, 0.29)
        btn.text = text
        return btn
    end

    local function SelectTab(key)
        if currentTab and tabs[currentTab] then
            tabs[currentTab]:Hide()
            if tabButtons[currentTab] and tabButtons[currentTab].text then
                tabButtons[currentTab].text:SetTextColor(1, 0.78, 0.29)
            end
        end

        currentTab = key
        if tabs[currentTab] then
            tabs[currentTab]:Show()
        end
        if tabButtons[currentTab] and tabButtons[currentTab].text then
            tabButtons[currentTab].text:SetTextColor(0.906, 0.298, 0.235)
        end
    end

    local function RegisterTab(key, buildFunc)
        local frame = CreateFrame("Frame", nil, parent)
        frame:SetPoint("TOPLEFT", 0, -(tabStartYOffset + 6))
        frame:SetPoint("TOPRIGHT", 0, 0)
        frame:Hide()
        tabs[key] = frame

        EdiUI:ResetLayout()
        buildFunc(frame)
        frame:SetHeight(EdiUI:GetCurrentYOffset() + 20)
        EdiUI:SetCurrentYOffset(tabStartYOffset)
    end

    local function AddPanel(container, title, buildFunc)
        local startYOffset = EdiUI:GetCurrentYOffset()
        local panel = CreateFrame("Frame", nil, container, "BackdropTemplate")
        panel:SetPoint("TOPLEFT", 6, -startYOffset)
        panel:SetPoint("TOPRIGHT", -6, -startYOffset)
        panel:SetHeight(1)

        if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
            EdiUI.Skin:ApplyFrame(panel, 'Transparent')
        else
            panel:SetBackdrop({
                bgFile = "Interface\\Buttons\\WHITE8x8",
                edgeFile = "Interface\\Buttons\\WHITE8x8",
                edgeSize = 1,
            })
            panel:SetBackdropColor(0.05, 0.05, 0.07, 1)
            panel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
        end

        local outerYOffset = EdiUI:GetCurrentYOffset()
        EdiUI:SetCurrentYOffset(12)
        EdiUI:AddHeader(panel, title)
        EdiUI:AddSpacer(panel, 8)
        buildFunc(panel)
        local panelHeight = EdiUI:GetCurrentYOffset() + 12
        panel:SetHeight(panelHeight)
        EdiUI:SetCurrentYOffset(outerYOffset + panelHeight + 18)
    end

    local labels = { "Automation", "Social", "System", "Cursor", "Crosshair" }
    local keys = { "automation", "social", "system", "cursor", "crosshair" }
    for i, key in ipairs(keys) do
        local btn = CreateSubTabButton(labels[i], i)
        tabButtons[key] = btn
        btn:SetScript("OnClick", function() SelectTab(key) end)
    end

    EdiUI:AddSpacer(parent, 28)
    tabStartYOffset = EdiUI:GetCurrentYOffset()

    -- ============================================================
    -- AUTOMATION SUB-TAB
    -- ============================================================
    RegisterTab("automation", function(container)
        -- Quests Panel
        AddPanel(container, "Quests", function(panel)
            EdiUI:AddCheckbox(panel,
                "Automate quests",
                "If checked, quests will be selected, accepted and turned-in automatically.",
                function() return db.automation.automateQuests end,
                function(val) db.automation.automateQuests = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Require override key",
                "If checked, hold the override key for quest automation. If unchecked, hold to prevent automation.",
                function() return db.automation.autoQuestShift end,
                function(val) db.automation.autoQuestShift = val Apply() end
            )
            EdiUI:AddDropdown(panel,
                "Override Key",
                "Key to hold for override behavior",
                { ["1"] = "Shift", ["2"] = "Alt", ["3"] = "Control" },
                function() return tostring(db.automation.autoQuestKeyMenu) end,
                function(val) db.automation.autoQuestKeyMenu = tonumber(val) Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Accept regular quests",
                "If checked, regular quests will be accepted automatically.",
                function() return db.automation.autoQuestRegular end,
                function(val) db.automation.autoQuestRegular = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Accept daily quests",
                "If checked, daily quests will be accepted automatically.",
                function() return db.automation.autoQuestDaily end,
                function(val) db.automation.autoQuestDaily = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Accept weekly quests",
                "If checked, weekly quests will be accepted automatically.",
                function() return db.automation.autoQuestWeekly end,
                function(val) db.automation.autoQuestWeekly = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Turn-in completed quests",
                "If checked, completed quests will be turned-in automatically.",
                function() return db.automation.autoQuestCompleted end,
                function(val) db.automation.autoQuestCompleted = val Apply() end
            )
        end)

        -- Gossip Panel
        AddPanel(container, "Gossip", function(panel)
            EdiUI:AddCheckbox(panel,
                "Automate gossip",
                "If checked, hold alt while opening a gossip window to automatically select a single gossip option.",
                function() return db.automation.automateGossip end,
                function(val) db.automation.automateGossip = val Apply() end
            )
        end)

        -- Summon & Resurrection Panel
        AddPanel(container, "Summon & Resurrection", function(panel)
            EdiUI:AddCheckbox(panel,
                "Accept summon",
                "If checked, summon requests will be accepted automatically unless you are in combat.",
                function() return db.automation.autoAcceptSummon end,
                function(val) db.automation.autoAcceptSummon = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Accept resurrection",
                "If checked, resurrection requests will be accepted automatically.",
                function() return db.automation.autoAcceptRes end,
                function(val) db.automation.autoAcceptRes = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Exclude combat resurrection",
                "If checked, resurrection requests will not be accepted if the resurrecting player is in combat.",
                function() return db.automation.autoResNoCombat end,
                function(val) db.automation.autoResNoCombat = val Apply() end
            )
        end)

        -- PvP Release Panel
        AddPanel(container, "PvP Release", function(panel)
            EdiUI:AddCheckbox(panel,
                "Release in PvP",
                "If checked, you will release automatically after dying in battlegrounds or PvP zones.",
                function() return db.automation.autoReleasePvP end,
                function(val) db.automation.autoReleasePvP = val Apply() end
            )
            EdiUI:AddSliderBare(panel, "Release Delay (ms)", "Milliseconds before automatic release", 0, 3000, 100,
                function() return db.automation.autoReleaseDelay end,
                function(val) db.automation.autoReleaseDelay = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Exclude Alterac Valley",
                "If checked, auto-release will not work in Alterac Valley.",
                function() return db.automation.autoReleaseNoAlterac end,
                function(val) db.automation.autoReleaseNoAlterac = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Exclude Wintergrasp",
                "If checked, auto-release will not work in Wintergrasp.",
                function() return db.automation.autoReleaseNoWintergrasp end,
                function(val) db.automation.autoReleaseNoWintergrasp = val Apply() end
            )
        end)

        -- Vendors Panel
        AddPanel(container, "Vendors", function(panel)
            EdiUI:AddCheckbox(panel,
                "Sell junk automatically",
                "If checked, grey items will be sold automatically when visiting a merchant. Hold shift to override.",
                function() return db.automation.autoSellJunk end,
                function(val) db.automation.autoSellJunk = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Show sell summary",
                "If checked, a summary will be shown in chat when junk is sold.",
                function() return db.automation.autoSellShowSummary end,
                function(val) db.automation.autoSellShowSummary = val Apply() end
            )
            EdiUI:AddEditBox(panel,
                "Exclude Item IDs",
                "Enter item IDs separated by commas to prevent them from being sold.",
                function() return db.automation.autoSellExcludeList end,
                function(val) db.automation.autoSellExcludeList = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Repair automatically",
                "If checked, gear will be repaired automatically at suitable merchants. Hold shift to override.",
                function() return db.automation.autoRepairGear end,
                function(val) db.automation.autoRepairGear = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Use guild funds",
                "If checked, repair costs will be taken from guild funds if available.",
                function() return db.automation.autoRepairGuildFunds end,
                function(val) db.automation.autoRepairGuildFunds = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Show repair summary",
                "If checked, a repair summary will be shown in chat.",
                function() return db.automation.autoRepairShowSummary end,
                function(val) db.automation.autoRepairShowSummary = val Apply() end
            )
        end)
    end)

    -- ============================================================
    -- SOCIAL SUB-TAB
    -- ============================================================
    RegisterTab("social", function(container)
        -- Block Panel
        AddPanel(container, "Block Requests", function(panel)
            EdiUI:AddCheckbox(panel,
                "Block duels",
                "If checked, duel requests will be blocked unless the player is a friend.",
                function() return db.social.noDuelRequests end,
                function(val) db.social.noDuelRequests = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Block pet battle duels",
                "If checked, pet battle duel requests will be blocked unless the player is a friend.",
                function() return db.social.noPetDuels end,
                function(val) db.social.noPetDuels = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Block party invites",
                "If checked, party invitations will be blocked unless the player is a friend.",
                function() return db.social.noPartyInvites end,
                function(val) db.social.noPartyInvites = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Block friend requests",
                "If checked, BattleTag and Real ID friend requests will be automatically declined.",
                function() return db.social.noFriendRequests end,
                function(val) db.social.noFriendRequests = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Block shared quests",
                "If checked, shared quests will be declined unless the player is a friend.",
                function() return db.social.noSharedQuests end,
                function(val) db.social.noSharedQuests = val Apply() end
            )
        end)

        -- Auto-Accept Panel
        AddPanel(container, "Auto-Accept", function(panel)
            EdiUI:AddCheckbox(panel,
                "Party from friends",
                "If checked, party invitations from friends will be automatically accepted.",
                function() return db.social.acceptPartyFriends end,
                function(val) db.social.acceptPartyFriends = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Sync from friends",
                "If checked, party sync requests from friends will be automatically accepted.",
                function() return db.social.syncFromFriends end,
                function(val) db.social.syncFromFriends = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Queue from friends",
                "If checked, dungeon finder queue requests from friends will be automatically accepted.",
                function() return db.social.autoConfirmRole end,
                function(val) db.social.autoConfirmRole = val Apply() end
            )
        end)

        -- Invite from Whisper Panel
        AddPanel(container, "Invite from Whispers", function(panel)
            EdiUI:AddCheckbox(panel,
                "Invite from whispers",
                "If checked, group invites will be sent to anyone who whispers you with a keyword.",
                function() return db.social.inviteFromWhisper end,
                function(val) db.social.inviteFromWhisper = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Restrict to friends",
                "If checked, group invites will only be sent to friends who whisper the keyword.",
                function() return db.social.inviteFriendsOnly end,
                function(val) db.social.inviteFriendsOnly = val Apply() end
            )
            EdiUI:AddEditBox(panel,
                "Invite Keyword",
                "The keyword players must whisper to request a group invite.",
                function() return db.social.inviteKeyword end,
                function(val) db.social.inviteKeyword = val Apply() end
            )
        end)

        -- Friend Treatment Panel
        AddPanel(container, "Friend Treatment", function(panel)
            EdiUI:AddDescription(panel, "Treat these groups as friends for all social options above.")
            EdiUI:AddCheckbox(panel,
                "Guild members",
                "If checked, guild members will be treated as friends for all social options.",
                function() return db.social.friendlyGuild end,
                function(val) db.social.friendlyGuild = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Community members",
                "If checked, community members will be treated as friends for all social options.",
                function() return db.social.friendlyCommunities end,
                function(val) db.social.friendlyCommunities = val Apply() end
            )
        end)
    end)

    -- ============================================================
    -- SYSTEM SUB-TAB
    -- ============================================================
    RegisterTab("system", function(container)
        -- Graphics Panel
        AddPanel(container, "Graphics", function(panel)
            EdiUI:AddCheckbox(panel,
                "Disable screen glow",
                "If checked, the screen glow and drunken haze effect will be disabled.",
                function() return db.system.noScreenGlow end,
                function(val) db.system.noScreenGlow = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Disable screen effects",
                "If checked, the grey screen of death and similar effects will be disabled.",
                function() return db.system.noScreenEffects end,
                function(val) db.system.noScreenEffects = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Set weather density",
                "If checked, you can control the density of weather effects.",
                function() return db.system.setWeatherDensity end,
                function(val) db.system.setWeatherDensity = val Apply() end
            )
            EdiUI:AddSliderBare(panel, "Weather Level", "Density of weather effects (0 = none, 3 = full)", 0, 3, 1,
                function() return db.system.weatherLevel end,
                function(val) db.system.weatherLevel = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Max camera zoom",
                "If checked, you will be able to zoom out to a greater distance.",
                function() return db.system.maxCameraZoom end,
                function(val) db.system.maxCameraZoom = val Apply() end
            )
        end)

        -- Sound Panel
        AddPanel(container, "Sound", function(panel)
            EdiUI:AddCheckbox(panel,
                "Silence rested emotes",
                "If checked, emote sounds will be silenced while resting or in pet battles.",
                function() return db.system.noRestedEmotes end,
                function(val) db.system.noRestedEmotes = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Mute mount sounds",
                "If checked, certain mount sounds will be muted.",
                function() return db.system.muteMountSounds end,
                function(val) db.system.muteMountSounds = val Apply() end
            )
        end)

        -- Gameplay Panel
        AddPanel(container, "Gameplay", function(panel)
            EdiUI:AddCheckbox(panel,
                "Disable bag automation",
                "If checked, bags will not open/close automatically at merchants or banks.",
                function() return db.system.noBagAutomation end,
                function(val) db.system.noBagAutomation = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Disable loot warnings",
                "If checked, loot roll confirmations will be skipped.",
                function() return db.system.noConfirmLoot end,
                function(val) db.system.noConfirmLoot = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Faster auto loot",
                "If checked, auto looting will be significantly faster.",
                function() return db.system.fasterLooting end,
                function(val) db.system.fasterLooting = val Apply() end
            )
            EdiUI:AddSliderBare(panel, "Loot Delay", "Delay between loot attempts (lower = faster)", 0.1, 0.3, 0.05,
                function() return db.system.fasterLootDelay end,
                function(val) db.system.fasterLootDelay = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Faster movie skip",
                "If checked, movies can be cancelled without confirmation.",
                function() return db.system.fasterMovieSkip end,
                function(val) db.system.fasterMovieSkip = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Combat plates",
                "If checked, enemy nameplates will show during combat and hide when combat ends.",
                function() return db.system.combatPlates end,
                function(val) db.system.combatPlates = val Apply() end
            )
            EdiUI:AddCheckbox(panel,
                "Easy item destroy",
                "If checked, you won't need to type 'delete' when destroying superior items.",
                function() return db.system.easyItemDestroy end,
                function(val) db.system.easyItemDestroy = val Apply() end
            )
        end)
    end)

    -- ============================================================
    -- CURSOR CIRCLE SUB-TAB
    -- ============================================================
    RegisterTab("cursor", function(container)
        local cursorDb = EdiUI.db.profile.cursorCircle
        local cursorMod = EdiUI:GetModule("CursorCircle", true)

        local function ApplyCursor()
            if cursorMod and cursorMod.ApplySettings then
                cursorMod:ApplySettings()
            end
        end

        local function ApplyReticle()
            if cursorMod and cursorMod.UpdateReticle then
                cursorMod:UpdateReticle()
            end
        end

        local function ApplyRingColors()
            if cursorMod and cursorMod.UpdateRingColors then
                cursorMod:UpdateRingColors()
            end
        end

        local ringOptions = {"None", "Main Ring", "Main Ring + GCD", "Main Ring + Cast", "Cast", "GCD", "Health and Power", "Health", "Power", "High Contrast Ring"}
        local reticleOptions = {"Dot", "Chevron", "Crosshair", "Diamond", "Flatline", "Star", "Ring", "Tech Arrow", "X", "No Reticle"}
        local modifierOptions = {"None", "Show Rings", "Ping with ring", "Ping with area", "Ping with crosshair", "Show Crosshair"}
        local colorModeOptions = {["default"] = "Default", ["class"] = "Class Color", ["custom"] = "Custom"}
        local fillDrainOptions = {["fill"] = "Fill", ["drain"] = "Drain"}

        -- Settings Panel
        AddPanel(container, "General Settings", function(panel)
            EdiUI:AddCheckbox(panel, "Enabled", "Enable the cursor circle overlay.",
                function() return cursorDb.enabled end,
                function(val) cursorDb.enabled = val ApplyCursor() end
            )
            EdiUI:AddCheckbox(panel, "Only in combat", "Show the cursor circle only while in combat.",
                function() return cursorDb.showOnlyInCombat end,
                function(val) cursorDb.showOnlyInCombat = val ApplyCursor() end
            )
            EdiUI:AddSliderBare(panel, "Scale", "Overall scale of the cursor circle.", 0.5, 4.0, 0.1,
                function() return cursorDb.scale or 1.0 end,
                function(val) cursorDb.scale = val ApplyCursor() end
            )
            EdiUI:AddSliderBare(panel, "Transparency", "Transparency of the cursor circle.", 0.1, 1.0, 0.05,
                function() return cursorDb.transparency or 1.0 end,
                function(val) cursorDb.transparency = val ApplyCursor() end
            )
        end)

        -- Ring Slot Assignment Panel
        AddPanel(container, "Ring Slot Assignment", function(panel)
            local ringDropdownOptions = {}
            for _, opt in ipairs(ringOptions) do ringDropdownOptions[opt] = opt end

            EdiUI:AddDropdown(panel, "Inner Ring (Small)", "Select what to display in the inner ring slot.",
                ringDropdownOptions,
                function() return cursorDb.innerRing or "GCD" end,
                function(val) cursorDb.innerRing = val ApplyCursor() end
            )
            EdiUI:AddDropdown(panel, "Main Ring (Medium)", "Select what to display in the main ring slot.",
                ringDropdownOptions,
                function() return cursorDb.mainRing or "Main Ring" end,
                function(val) cursorDb.mainRing = val ApplyCursor() end
            )
            EdiUI:AddDropdown(panel, "Outer Ring (Large)", "Select what to display in the outer ring slot.",
                ringDropdownOptions,
                function() return cursorDb.outerRing or "Cast" end,
                function(val) cursorDb.outerRing = val ApplyCursor() end
            )
        end)

        -- Reticle Panel
        AddPanel(container, "Reticle", function(panel)
            local reticleDropdownOptions = {}
            for _, opt in ipairs(reticleOptions) do reticleDropdownOptions[opt] = opt end

            EdiUI:AddDropdown(panel, "Reticle Style", "Select the reticle style.",
                reticleDropdownOptions,
                function() return cursorDb.reticle or "Dot" end,
                function(val) cursorDb.reticle = val ApplyReticle() end
            )
            EdiUI:AddSliderBare(panel, "Reticle Scale", "Size of the reticle.", 0.5, 3.0, 0.1,
                function() return cursorDb.reticleScale or 1.5 end,
                function(val) cursorDb.reticleScale = val ApplyReticle() end
            )
            EdiUI:AddDropdown(panel, "Reticle Color Mode", "Select the color mode for the reticle.",
                colorModeOptions,
                function() return cursorDb.reticleColorMode or "default" end,
                function(val) cursorDb.reticleColorMode = val ApplyReticle() end
            )
            EdiUI:AddColorPicker(panel, "Custom Reticle Color", "Custom color when mode is set to Custom.",
                function()
                    local c = cursorDb.reticleCustomColor or {r=1,g=1,b=1}
                    return c.r, c.g, c.b, 1
                end,
                function(r, g, b)
                    cursorDb.reticleCustomColor = {r=r, g=g, b=b}
                    ApplyReticle()
                end
            )
        end)

        -- Ring Colors Panel
        AddPanel(container, "Ring Colors", function(panel)
            EdiUI:AddDropdown(panel, "Main Ring Color", "Color mode for the main ring.",
                colorModeOptions,
                function() return cursorDb.mainRingColorMode or "default" end,
                function(val) cursorDb.mainRingColorMode = val ApplyRingColors() end
            )
            EdiUI:AddDropdown(panel, "GCD Ring Color", "Color mode for the GCD ring.",
                colorModeOptions,
                function() return cursorDb.gcdColorMode or "default" end,
                function(val) cursorDb.gcdColorMode = val ApplyRingColors() end
            )
            EdiUI:AddDropdown(panel, "Cast Ring Color", "Color mode for the Cast ring.",
                colorModeOptions,
                function() return cursorDb.castColorMode or "default" end,
                function(val) cursorDb.castColorMode = val ApplyRingColors() end
            )
        end)

        -- Animation Panel
        AddPanel(container, "Animation Settings", function(panel)
            EdiUI:AddDropdown(panel, "GCD Fill/Drain", "Direction of GCD animation.",
                fillDrainOptions,
                function() return cursorDb.gcdFillDrain or "fill" end,
                function(val) cursorDb.gcdFillDrain = val if cursorMod and cursorMod.ResetCooldownFrames then cursorMod:ResetCooldownFrames() end end
            )
            EdiUI:AddSliderBare(panel, "GCD Start Position", "Clock position where GCD animation starts (12 = top).", 1, 12, 1,
                function() return cursorDb.gcdRotation or 12 end,
                function(val) cursorDb.gcdRotation = val if cursorMod and cursorMod.ResetCooldownFrames then cursorMod:ResetCooldownFrames() end end
            )
            EdiUI:AddDropdown(panel, "Cast Fill/Drain", "Direction of Cast animation.",
                fillDrainOptions,
                function() return cursorDb.castFillDrain or "fill" end,
                function(val) cursorDb.castFillDrain = val if cursorMod and cursorMod.ResetCooldownFrames then cursorMod:ResetCooldownFrames() end end
            )
            EdiUI:AddSliderBare(panel, "Cast Start Position", "Clock position where Cast animation starts (12 = top).", 1, 12, 1,
                function() return cursorDb.castRotation or 12 end,
                function(val) cursorDb.castRotation = val if cursorMod and cursorMod.ResetCooldownFrames then cursorMod:ResetCooldownFrames() end end
            )
        end)

        -- Modifier Keys Panel
        AddPanel(container, "Modifier Keys", function(panel)
            local modDropdownOptions = {}
            for _, opt in ipairs(modifierOptions) do modDropdownOptions[opt] = opt end

            EdiUI:AddDropdown(panel, "Shift Action", "Action when Shift is pressed.",
                modDropdownOptions,
                function() return cursorDb.shiftAction or "None" end,
                function(val) cursorDb.shiftAction = val ApplyCursor() end
            )
            EdiUI:AddDropdown(panel, "Ctrl Action", "Action when Control is pressed.",
                modDropdownOptions,
                function() return cursorDb.ctrlAction or "None" end,
                function(val) cursorDb.ctrlAction = val ApplyCursor() end
            )
            EdiUI:AddDropdown(panel, "Alt Action", "Action when Alt is pressed.",
                modDropdownOptions,
                function() return cursorDb.altAction or "None" end,
                function(val) cursorDb.altAction = val ApplyCursor() end
            )
        end)

        -- Cursor Trail Panel
        AddPanel(container, "Cursor Trail", function(panel)
            EdiUI:AddCheckbox(panel, "Enable Trail", "Enable a trail effect behind the cursor.",
                function() return cursorDb.enableTrail end,
                function(val) cursorDb.enableTrail = val end
            )
            EdiUI:AddSliderBare(panel, "Trail Duration", "How long trail elements last.", 0.2, 1.0, 0.05,
                function() return cursorDb.trailDuration or 0.5 end,
                function(val) cursorDb.trailDuration = val end
            )
            EdiUI:AddSliderBare(panel, "Trail Scale", "Size of trail elements.", 0.5, 2.0, 0.1,
                function() return cursorDb.trailScale or 1.0 end,
                function(val) cursorDb.trailScale = val end
            )
            local trailColorOptions = {["default"] = "Default (White)", ["class"] = "Class Color", ["custom"] = "Custom", ["seasonal"] = "Winter Veil"}
            EdiUI:AddDropdown(panel, "Trail Color", "Color mode for the cursor trail.",
                trailColorOptions,
                function() return cursorDb.trailColorMode or "default" end,
                function(val) cursorDb.trailColorMode = val end
            )
        end)
    end)

    -- ============================================================
    -- CROSSHAIR SUB-TAB
    -- ============================================================
    RegisterTab("crosshair", function(container)
        local crosshairDb = EdiUI.db.profile.crosshair

        AddPanel(container, "Crosshair Settings", function(panel)
            EdiUI:AddCheckbox(panel, "Enabled", "Show a crosshair overlay on screen.",
                function() return crosshairDb.enabled end,
                function(val)
                    crosshairDb.enabled = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddSliderBare(panel, "Line Width", "Thickness of the crosshair lines.", 1, 10, 1,
                function() return crosshairDb.width or 2 end,
                function(val)
                    crosshairDb.width = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddSliderBare(panel, "Line Length", "Length of the crosshair lines.", 4, 50, 1,
                function() return crosshairDb.size or 12 end,
                function(val)
                    crosshairDb.size = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddSliderBare(panel, "Gap", "Gap around the center of the crosshair.", 0, 100, 5,
                function() return crosshairDb.gap or 35 end,
                function(val)
                    crosshairDb.gap = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddSliderBare(panel, "Vertical Offset", "Move the crosshair up or down.", -200, 200, 1,
                function() return crosshairDb.offsetY or 0 end,
                function(val)
                    crosshairDb.offsetY = val
                    ApplyCrosshair()
                end
            )
            local strataOptions = {
                BACKGROUND = "Background",
                LOW = "Low",
                MEDIUM = "Medium",
                HIGH = "High",
                DIALOG = "Dialog",
                FULLSCREEN = "Fullscreen",
                FULLSCREEN_DIALOG = "Fullscreen Dialog",
                TOOLTIP = "Tooltip",
            }
            EdiUI:AddDropdown(panel, "Strata", "Frame strata for the crosshair.", strataOptions,
                function() return crosshairDb.strata or "HIGH" end,
                function(val)
                    crosshairDb.strata = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddCheckbox(panel, "Only in Combat", "Show the crosshair only while in combat.",
                function() return crosshairDb.onlyInCombat end,
                function(val)
                    crosshairDb.onlyInCombat = val
                    ApplyCrosshair()
                end
            )
        end)

        AddPanel(container, "Colors", function(panel)
            EdiUI:AddColorPicker(panel, "Line Color", "Color of the crosshair lines.",
                function()
                    local c = crosshairDb.color or {r=1,g=1,b=1,a=0.5}
                    return c.r, c.g, c.b, c.a or 0.5
                end,
                function(r, g, b, a)
                    crosshairDb.color = {r=r, g=g, b=b, a=a or 0.5}
                    ApplyCrosshair()
                end
            )
            EdiUI:AddSliderBare(panel, "Alpha", "Transparency of the crosshair lines.", 0.1, 1.0, 0.05,
                function()
                    local c = crosshairDb.color or {a=0.5}
                    return c.a or 0.5
                end,
                function(val)
                    crosshairDb.color = crosshairDb.color or {r=1,g=1,b=1}
                    crosshairDb.color.a = val
                    ApplyCrosshair()
                end
            )
        end)

        AddPanel(container, "Border", function(panel)
            EdiUI:AddCheckbox(panel, "Show Border", "Add a border around the crosshair lines for visibility.",
                function() return crosshairDb.showBorder end,
                function(val)
                    crosshairDb.showBorder = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddSliderBare(panel, "Border Width", "Thickness of the border.", 1, 5, 1,
                function() return crosshairDb.borderWidth or 1 end,
                function(val)
                    crosshairDb.borderWidth = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddColorPicker(panel, "Border Color", "Color of the border.",
                function()
                    local c = crosshairDb.borderColor or {r=0,g=0,b=0,a=0.8}
                    return c.r, c.g, c.b, c.a or 0.8
                end,
                function(r, g, b, a)
                    crosshairDb.borderColor = {r=r, g=g, b=b, a=a or 0.8}
                    ApplyCrosshair()
                end
            )
        end)

        AddPanel(container, "Range Colors", function(panel)
            EdiUI:AddCheckbox(panel, "Change Color on Range", "Shift crosshair color based on target range.",
                function() return crosshairDb.changeColorOnRange end,
                function(val)
                    crosshairDb.changeColorOnRange = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddCheckbox(panel, "Melee Range Check", "Use 5-yard melee range checks.",
                function() return crosshairDb.enableMeleeRangeCheck ~= false end,
                function(val)
                    crosshairDb.enableMeleeRangeCheck = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddCheckbox(panel, "Mid Range Check", "Enable 25-yard range checks for supported specs.",
                function() return crosshairDb.enableMidRangeCheck == true end,
                function(val)
                    crosshairDb.enableMidRangeCheck = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddCheckbox(panel, "Combat Only Range", "Only update range colors while in combat.",
                function() return crosshairDb.rangeColorInCombatOnly end,
                function(val)
                    crosshairDb.rangeColorInCombatOnly = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddCheckbox(panel, "Hide Until Out of Range", "Hide crosshair until target is out of range.",
                function() return crosshairDb.hideUntilOutOfRange end,
                function(val)
                    crosshairDb.hideUntilOutOfRange = val
                    ApplyCrosshair()
                end
            )
            EdiUI:AddColorPicker(panel, "Out of Range Color", "Color when target is out of range.",
                function()
                    local c = crosshairDb.outOfRangeColor or {1, 0.2, 0.2, 1}
                    return c[1] or 1, c[2] or 0.2, c[3] or 0.2, c[4] or 1
                end,
                function(r, g, b, a)
                    crosshairDb.outOfRangeColor = { r, g, b, a or 1 }
                    ApplyCrosshair()
                end
            )
            EdiUI:AddColorPicker(panel, "Mid Range Color", "Color when target is out of melee but within 25y.",
                function()
                    local c = crosshairDb.midRangeColor or {1, 0.6, 0.2, 1}
                    return c[1] or 1, c[2] or 0.6, c[3] or 0.2, c[4] or 1
                end,
                function(r, g, b, a)
                    crosshairDb.midRangeColor = { r, g, b, a or 1 }
                    ApplyCrosshair()
                end
            )
        end)
    end)

    SelectTab("automation")
    parent:SetHeight(420)
end

C_Timer.After(0.2, function()
    if EdiUI.RegisterOptionsTab then
        EdiUI:RegisterOptionsTab("qol", "QoL", BuildQoLOptions, 10.5)
    end
end)
