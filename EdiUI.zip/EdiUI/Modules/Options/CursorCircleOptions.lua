-- EdiUI Cursor Circle Options
-- Note: Cursor Circle options are now integrated into the QoL tab as a sub-tab.
-- This file is kept for backwards compatibility but the main options are in QoLOptions.lua

local EdiUI = EdiUI

-- The standalone Cursor Circle tab has been removed.
-- Cursor Circle settings are now accessible via QoL > Cursor sub-tab.
