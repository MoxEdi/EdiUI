-- EdiUI General UI Settings
-- Hide stance bar, minimap border, and other general tweaks
local EdiUI = EdiUI

local General = {}
EdiUI.General = General

-- Minimap border frame
local minimapBorderFrame = nil

-- Hide/Show stance bar
function General:UpdateStanceBar()
    local db = EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.general
    if not db then return end

    local Compat = EdiUI and EdiUI.Compat

    -- Skip EditMode system interaction to avoid taint/secret value errors
    -- Just use direct stance bar manipulation
    local stanceBar = (Compat and Compat.GetStanceBar and Compat.GetStanceBar()) or _G.StanceBar
    if stanceBar then
        if db.hideStanceBar then
            stanceBar:Hide()
            stanceBar:SetAlpha(0)
            -- Prevent it from showing again
            if not stanceBar._ediHooked then
                stanceBar._ediHooked = true
                hooksecurefunc(stanceBar, "Show", function(self)
                    if EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.general and EdiUI.db.profile.general.hideStanceBar then
                        self:Hide()
                        self:SetAlpha(0)
                    end
                end)
            end
        else
            stanceBar:Show()
            stanceBar:SetAlpha(1)
        end
    end
end

-- Create/Update minimap border
function General:UpdateMinimapBorder()
    local db = EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.general
    if not db then return end

    local Compat = EdiUI and EdiUI.Compat
    local minimap = (Compat and Compat.GetMinimap and Compat.GetMinimap()) or Minimap or (MinimapCluster and MinimapCluster.Minimap)
    if not minimap then return end

    if db.minimapBorder then
        if not minimapBorderFrame then
            minimapBorderFrame = CreateFrame("Frame", "EdiUI_MinimapBorder", minimap, "BackdropTemplate")
            minimapBorderFrame:SetPoint("TOPLEFT", minimap, "TOPLEFT", -1, 1)
            minimapBorderFrame:SetPoint("BOTTOMRIGHT", minimap, "BOTTOMRIGHT", 1, -1)
            minimapBorderFrame:SetFrameStrata("BACKGROUND")
            minimapBorderFrame:SetFrameLevel(0)
            minimapBorderFrame:SetBackdrop({
                edgeFile = "Interface\\Buttons\\WHITE8X8",
                edgeSize = 1,
            })
            minimapBorderFrame:SetBackdropBorderColor(0, 0, 0, 1)
        end
        minimapBorderFrame:Show()
    else
        if minimapBorderFrame then
            minimapBorderFrame:Hide()
        end
    end
end

-- Micro Menu Mouseover
local microMenuHooked = false

function General:UpdateMicroMenuMouseover()
    local db = EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.general
    if not db then return end

    local Compat = EdiUI and EdiUI.Compat

    -- Find the actual parent frame of the buttons (usually MicroButtonAndBagsBar or MicroMenu)
    local buttons
    if Compat and Compat.GetMicroButtons then
        buttons = Compat.GetMicroButtons()
    else
        -- Fallback
        buttons = {}
        local buttonNames = {
            "CharacterMicroButton", "SpellbookMicroButton", "TalentMicroButton",
            "AchievementMicroButton", "QuestLogMicroButton", "GuildMicroButton",
            "LFDMicroButton", "EJMicroButton", "CollectionsMicroButton",
            "StoreMicroButton", "MainMenuMicroButton", "HelpMicroButton",
        }
        for _, name in ipairs(buttonNames) do
            local btn = _G[name]
            if btn then table.insert(buttons, btn) end
        end
    end
    if #buttons == 0 then return end
    
    local bar = buttons[1]:GetParent()
    if not bar then return end

    if db.microMenuMouseover then
        bar:SetAlpha(0)
        
        if not microMenuHooked then
            microMenuHooked = true
            
            local fadeTimer
            
            local function FadeIn()
                if fadeTimer then fadeTimer:Cancel() end
                if EdiUI.db.profile.general.microMenuMouseover then
                    bar:SetAlpha(1)
                end
            end
            
            local function FadeOut()
                if fadeTimer then fadeTimer:Cancel() end
                fadeTimer = C_Timer.NewTimer(0.1, function()
                    if not EdiUI.db.profile.general.microMenuMouseover then return end
                    
                    -- Check if mouse is over the bar
                    if MouseIsOver(bar) then return end
                    
                    -- Check if mouse is over any button (just in case bar hitrect is weird)
                    for _, btn in ipairs(buttons) do
                        if MouseIsOver(btn) then return end
                    end
                    
                    bar:SetAlpha(0)
                end)
            end
            
            -- Hook the container
            bar:HookScript("OnEnter", FadeIn)
            bar:HookScript("OnLeave", FadeOut)
            
            -- Hook all specific buttons
            for _, btn in ipairs(buttons) do
                btn:HookScript("OnEnter", FadeIn)
                btn:HookScript("OnLeave", FadeOut)
            end
        end
    else
        bar:SetAlpha(1)
    end
end

-- Initialize general settings
function General:Initialize()
    -- Delay to ensure UI elements exist
    C_Timer.After(0.5, function()
        self:UpdateStanceBar()
        self:UpdateMinimapBorder()
        self:UpdateMicroMenuMouseover()
    end)
end

-- Refresh all general settings
function General:Refresh()
    self:UpdateStanceBar()
    self:UpdateMinimapBorder()
    self:UpdateMicroMenuMouseover()
end
