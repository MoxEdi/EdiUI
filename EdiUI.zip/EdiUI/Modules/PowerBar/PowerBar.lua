-- EdiUI Power Bar
-- Tracks player resource (mana, rage, energy, etc.) and anchors above Essentials bar
local EdiUI = EdiUI
local PowerBar = EdiUI:NewModule("PowerBar", "AceEvent-3.0", "AceHook-3.0")

local ELEGANT_POWER_GRADIENTS = {
    MANA = { start = { r = 0.55, g = 0.82, b = 1.0 }, ["end"] = { r = 0.25, g = 0.6, b = 0.95 } },
    ENERGY = { start = { r = 1.0, g = 0.9, b = 0.5 }, ["end"] = { r = 0.85, g = 0.65, b = 0.25 } },
    FOCUS = { start = { r = 0.95, g = 0.78, b = 0.45 }, ["end"] = { r = 0.75, g = 0.55, b = 0.2 } },
    RAGE = { start = { r = 0.95, g = 0.35, b = 0.35 }, ["end"] = { r = 0.6, g = 0.12, b = 0.12 } },
    RUNIC_POWER = { start = { r = 0.6, g = 0.95, b = 0.95 }, ["end"] = { r = 0.2, g = 0.65, b = 0.7 } },
    INSANITY = { start = { r = 0.65, g = 0.35, b = 1.0 }, ["end"] = { r = 0.35, g = 0.15, b = 0.65 } },
    FURY = { start = { r = 0.95, g = 0.45, b = 0.95 }, ["end"] = { r = 0.6, g = 0.2, b = 0.65 } },
    PAIN = { start = { r = 0.95, g = 0.45, b = 0.35 }, ["end"] = { r = 0.65, g = 0.2, b = 0.2 } },
    MAELSTROM = { start = { r = 0.45, g = 0.8, b = 1.0 }, ["end"] = { r = 0.2, g = 0.6, b = 0.9 } },
    LUNAR_POWER = { start = { r = 0.8, g = 0.7, b = 1.0 }, ["end"] = { r = 0.5, g = 0.45, b = 0.8 } },
    HOLY_POWER = { start = { r = 1.0, g = 0.88, b = 0.5 }, ["end"] = { r = 0.85, g = 0.65, b = 0.25 } },
}

local function ApplyGradient(bar, startColor, endColor)
    if not bar or not startColor or not endColor then
        return
    end
    local texture = bar.GetStatusBarTexture and bar:GetStatusBarTexture()
    if not texture then
        return
    end

    -- Use Compat layer for 12.0+ compatibility
    local Compat = EdiUI and EdiUI.Compat
    if Compat and Compat.SetTextureGradient then
        Compat.SetTextureGradient(texture, "HORIZONTAL", startColor, endColor)
    else
        -- Fallback to direct API
        if texture.SetGradient then
            texture:SetGradient(
                "HORIZONTAL",
                CreateColor(startColor.r, startColor.g, startColor.b, startColor.a or 1),
                CreateColor(endColor.r, endColor.g, endColor.b, endColor.a or 1)
            )
        end
    end
end

local function GetGradientForPower(powerToken, baseColor)
    if powerToken and ELEGANT_POWER_GRADIENTS[powerToken] then
        return ELEGANT_POWER_GRADIENTS[powerToken]
    end

    if baseColor then
        local Colors = EdiUI and EdiUI.Colors
        if Colors and Colors.BlendWithWhite and Colors.BlendWithBlack then
            return {
                start = Colors:BlendWithWhite(baseColor, 0.18),
                ["end"] = Colors:BlendWithBlack(baseColor, 0.18),
            }
        else
            -- Fallback blend calculation
            local function Clamp01(v)
                if v < 0 then return 0 end
                if v > 1 then return 1 end
                return v
            end
            return {
                start = {
                    r = Clamp01(baseColor.r + (1 - baseColor.r) * 0.18),
                    g = Clamp01(baseColor.g + (1 - baseColor.g) * 0.18),
                    b = Clamp01(baseColor.b + (1 - baseColor.b) * 0.18),
                },
                ["end"] = {
                    r = Clamp01(baseColor.r * 0.82),
                    g = Clamp01(baseColor.g * 0.82),
                    b = Clamp01(baseColor.b * 0.82),
                }
            }
        end
    end
    return nil
end

local function GetElvUILSM()
    local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
    if E and E.Libs and E.Libs.LSM then
        return E.Libs.LSM
    end
    return nil
end

local function BuildFontStyle(outline, shadow)
    local style = outline or ""
    if style == "NONE" then
        style = ""
    end
    if shadow then
        if style == "" then
            style = "SHADOW"
        else
            style = "SHADOW" .. style
        end
    end
    return style
end

local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.powerBar
end

function PowerBar:CreateBar()
    if self.bar then
        return
    end

    local bar = CreateFrame("StatusBar", "EdiUIPowerBar", UIParent, "BackdropTemplate")
    bar:SetFrameStrata("HIGH")
    bar:SetFrameLevel(50)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")

    bar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    bar:SetBackdropColor(0.05, 0.05, 0.07, 1)
    bar:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)

    local border = CreateFrame("Frame", nil, bar, "BackdropTemplate")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    border:SetBackdropBorderColor(0, 0, 0, 1)
    border:SetFrameLevel(bar:GetFrameLevel() - 2)
    bar.border = border

    local text = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("CENTER")
    text:SetDrawLayer("OVERLAY", 7)
    text:SetSpacing(6)
    bar.text = text

    self.bar = bar
end

function PowerBar:UpdateFont()
    local db = GetDb()
    if not db or not self.bar or not self.bar.text then
        return
    end

    local fontPath = STANDARD_TEXT_FONT
    local lsm = GetElvUILSM()
    if lsm and db.font and db.font ~= "" then
        fontPath = lsm:Fetch("font", db.font)
    end

    local flags = BuildFontStyle(db.fontOutline, db.fontShadow)
    local shadow = string.sub(flags, 1, 6) == "SHADOW"
    local style = shadow and string.sub(flags, 7) or flags
    if style == "NONE" then
        style = ""
    end

    self.bar.text:SetFont(fontPath or STANDARD_TEXT_FONT, db.fontSize or 12, style)
    self.bar.text:SetShadowColor(0, 0, 0, (shadow and (style == "" and 1 or 0.6)) or 0)
    self.bar.text:SetShadowOffset((shadow and 1) or 0, (shadow and -1) or 0)
    self.bar.text:SetTextColor(1, 1, 1, 1)
    self.bar.text:ClearAllPoints()
    self.bar.text:SetPoint("CENTER", self.bar, "CENTER", db.textOffsetX or 0, db.textOffsetY or 0)
end

function PowerBar:UpdateAnchor()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    self.bar:ClearAllPoints()

    local anchor = _G.EssentialCooldownViewer
    if anchor then
        self.bar:SetPoint("BOTTOM", anchor, "TOP", db.offsetX or 0, db.offsetY or 6)
    else
        self.bar:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end

    local width = db.width or 280
    if db.matchEssentials and anchor and anchor.GetWidth then
        local anchorWidth = anchor:GetWidth()
        if anchorWidth and anchorWidth > 0 then
            width = anchorWidth
        end
    end
    self.bar:SetWidth(width)
    self.bar:SetHeight(db.height or 14)
end

function PowerBar:UpdateTexture()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local lsm = GetElvUILSM()
    if lsm and db.texture and db.texture ~= "" then
        local tex = lsm:Fetch("statusbar", db.texture)
        if tex then
            self.bar:SetStatusBarTexture(tex)
        end
    else
        self.bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
    end
end

function PowerBar:CheckVisibility()
    local db = GetDb()
    if not db then return true end

    -- Hide when mounted
    if db.hideWhenMounted and IsMounted() then
        return false
    end

    -- Hide in vehicle
    if db.hideInVehicle and UnitInVehicle("player") then
        return false
    end

    -- Hide in pet battle
    if db.hideInPetBattle and C_PetBattles and C_PetBattles.IsInBattle() then
        return false
    end

    return true
end

function PowerBar:UpdateDisplay(_, unit)
    if unit and unit ~= "player" then
        return
    end
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local function SafeNumber(value)
        if type(value) ~= "number" then
            return nil
        end
        return value
    end

    local powerType = UnitPowerType("player")
    local power = 0
    local maxPower = 1
    do
        local ok, value = pcall(UnitPower, "player", powerType)
        local num = SafeNumber(value)
        if ok and num then
            power = num
        end
    end
    do
        local ok, value = pcall(UnitPowerMax, "player", powerType)
        local num = SafeNumber(value)
        if ok and num then
            maxPower = num
        end
    end

    self.bar:SetMinMaxValues(0, maxPower)
    self.bar:SetValue(power or 0)

    local _, powerToken = UnitPowerType("player")
    local baseColor
    if db.usePowerColor then
        local color = PowerBarColor and (PowerBarColor[powerToken] or PowerBarColor[powerType])
        if color then
            baseColor = { r = color.r, g = color.g, b = color.b }
        else
            baseColor = { r = 0.2, g = 0.62, b = 0.9 }
        end
    else
        local c = db.color or { r = 0.2, g = 0.62, b = 0.9 }
        baseColor = { r = c.r or 0.2, g = c.g or 0.62, b = c.b or 0.9 }
    end

    if baseColor then
        local gradient = GetGradientForPower(powerToken, baseColor)
        if gradient and gradient.start and gradient["end"] then
            self.bar:SetStatusBarColor(gradient.start.r, gradient.start.g, gradient.start.b)
            ApplyGradient(self.bar, gradient.start, gradient["end"])
        else
            self.bar:SetStatusBarColor(baseColor.r, baseColor.g, baseColor.b)
        end
    end

    if db.showText then
        local pctText = "0"
        if UnitPowerPercent then
            local ok, result = pcall(UnitPowerPercent, "player", powerType, false, (CurveConstants and CurveConstants.ScaleTo100) or nil)
            if ok then
                local okText = pcall(function()
                    self.bar.text:SetFormattedText("%.0f", result)
                end)
                if okText then
                    return
                end
            end
        end
        self.bar.text:SetText(pctText)
    else
        self.bar.text:SetText("")
    end
end

function PowerBar:UpdateAll()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    if db.enabled and self:CheckVisibility() then
        self.bar:Show()
    else
        self.bar:Hide()
        return
    end

    self:UpdateAnchor()
    self:UpdateTexture()
    self:UpdateFont()
    self:UpdateDisplay()

    if not self.anchorPending then
        self.anchorPending = true
        C_Timer.After(0.2, function()
            self.anchorPending = false
            if self.bar then
                self:UpdateAnchor()
            end
        end)
    end
end

function PowerBar:HookRefreshLayout()
    if self.layoutHooked then
        return
    end
    if _G.CooldownViewerSettings and _G.CooldownViewerSettings.RefreshLayout then
        self:SecureHook(_G.CooldownViewerSettings, "RefreshLayout", function()
            self:UpdateAnchor()
        end)
        self.layoutHooked = true
    end
end

function PowerBar:OnEnable()
    self:CreateBar()
    self:HookRefreshLayout()

    self:RegisterEvent("PLAYER_ENTERING_WORLD", "UpdateAll")
    self:RegisterEvent("UNIT_POWER_UPDATE", "UpdateDisplay")
    self:RegisterEvent("UNIT_POWER_FREQUENT", "UpdateDisplay")
    self:RegisterEvent("UNIT_DISPLAYPOWER", "UpdateAll")
    self:RegisterEvent("UNIT_MAXPOWER", "UpdateAll")
    self:RegisterEvent("PLAYER_SPECIALIZATION_CHANGED", "UpdateAll")

    -- Visibility events
    self:RegisterEvent("UNIT_ENTERED_VEHICLE", "UpdateAll")
    self:RegisterEvent("UNIT_EXITED_VEHICLE", "UpdateAll")
    self:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED", "UpdateAll")
    self:RegisterEvent("PET_BATTLE_OPENING_START", "UpdateAll")
    self:RegisterEvent("PET_BATTLE_CLOSE", "UpdateAll")

    self:UpdateAll()
end
