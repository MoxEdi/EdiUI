-- EdiUI Cast Bar
-- Shows player castbar above class bar or power bar
local EdiUI = EdiUI
local CastBar = EdiUI:NewModule("CastBar", "AceEvent-3.0", "AceHook-3.0")

local CASTBAR_GRADIENT_START = { r = 0.6, g = 0.86, b = 1.0 }
local CASTBAR_GRADIENT_END = { r = 0.82, g = 0.95, b = 1.0 }

local function ApplyGradient(bar, startColor, endColor)
    if not bar or not startColor or not endColor then
        return
    end
    local texture = bar.GetStatusBarTexture and bar:GetStatusBarTexture()
    if not texture then
        return
    end

    -- Use Compat layer for 12.0+ compatibility
    local Compat = EdiUI and EdiUI.Compat
    if Compat and Compat.SetTextureGradient then
        Compat.SetTextureGradient(texture, "HORIZONTAL", startColor, endColor)
    else
        -- Fallback to direct API
        if texture.SetGradient then
            texture:SetGradient(
                "HORIZONTAL",
                CreateColor(startColor.r, startColor.g, startColor.b, 1),
                CreateColor(endColor.r, endColor.g, endColor.b, 1)
            )
        end
    end
end

local function GetElvUILSM()
    local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
    if E and E.Libs and E.Libs.LSM then
        return E.Libs.LSM
    end
    return nil
end

local function BuildFontStyle(outline, shadow)
    local style = outline or ""
    if style == "NONE" then
        style = ""
    end
    if shadow then
        if style == "" then
            style = "SHADOW"
        else
            style = "SHADOW" .. style
        end
    end
    return style
end

local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.castBar
end

function CastBar:CreateBar()
    if self.bar then
        return
    end

    local bar = CreateFrame("StatusBar", "EdiUICastBar", UIParent, "BackdropTemplate")
    bar:SetFrameStrata("HIGH")
    bar:SetFrameLevel(45)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")

    bar:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    bar:SetBackdropColor(0.05, 0.05, 0.07, 1)
    bar:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)

    local border = CreateFrame("Frame", nil, bar, "BackdropTemplate")
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)
    border:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    border:SetBackdropBorderColor(0, 0, 0, 1)
    border:SetFrameLevel(bar:GetFrameLevel() - 2)
    bar.border = border

    local text = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    text:SetPoint("CENTER")
    text:SetDrawLayer("OVERLAY", 7)
    bar.text = text

    local timeText = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    timeText:SetPoint("RIGHT", bar, "RIGHT", -4, 0)
    timeText:SetDrawLayer("OVERLAY", 7)
    bar.timeText = timeText

    local icon = bar:CreateTexture(nil, "ARTWORK")
    icon:SetSize(14, 14)
    icon:SetPoint("RIGHT", bar, "LEFT", -6, 0)
    bar.icon = icon

    self.bar = bar
end

function CastBar:UpdateAnchor()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    self.bar:ClearAllPoints()

    local anchor = _G.EdiUIClassBar
    if anchor and anchor.IsShown and anchor:IsShown() then
        self.bar:SetPoint("BOTTOM", anchor, "TOP", db.offsetX or 0, db.offsetY or 6)
    else
        local powerBar = _G.EdiUIPowerBar
        if powerBar then
            self.bar:SetPoint("BOTTOM", powerBar, "TOP", db.offsetX or 0, db.offsetY or 6)
        else
            local essentials = _G.EssentialCooldownViewer
            if essentials then
                self.bar:SetPoint("BOTTOM", essentials, "TOP", db.offsetX or 0, (db.offsetY or 6) + 12)
            else
                self.bar:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
            end
        end
    end

    local width = db.width or 260
    if db.matchEssentials then
        -- Match Essentials Cooldown Viewer width directly
        local essentials = _G.EssentialCooldownViewer
        if essentials and essentials.GetWidth then
            local essWidth = essentials:GetWidth()
            if essWidth and essWidth > 0 then
                width = essWidth
            end
        end
    end
    self.bar:SetWidth(width)
    self.bar:SetHeight(db.height or 12)
end

function CastBar:UpdateTexture()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local lsm = GetElvUILSM()
    if lsm and db.texture and db.texture ~= "" then
        local tex = lsm:Fetch("statusbar", db.texture)
        if tex then
            self.bar:SetStatusBarTexture(tex)
        end
    else
        self.bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
    end
end

function CastBar:UpdateFont()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local fontPath = STANDARD_TEXT_FONT
    local lsm = GetElvUILSM()
    if lsm and db.font and db.font ~= "" then
        fontPath = lsm:Fetch("font", db.font)
    end

    local flags = BuildFontStyle(db.fontOutline, db.fontShadow)
    local shadow = string.sub(flags, 1, 6) == "SHADOW"
    local style = shadow and string.sub(flags, 7) or flags
    if style == "NONE" then
        style = ""
    end

    self.bar.text:SetFont(fontPath or STANDARD_TEXT_FONT, db.fontSize or 12, style)
    self.bar.timeText:SetFont(fontPath or STANDARD_TEXT_FONT, db.fontSize or 12, style)
    self.bar.text:SetShadowColor(0, 0, 0, (shadow and (style == "" and 1 or 0.6)) or 0)
    self.bar.text:SetShadowOffset((shadow and 1) or 0, (shadow and -1) or 0)
    self.bar.timeText:SetShadowColor(0, 0, 0, (shadow and (style == "" and 1 or 0.6)) or 0)
    self.bar.timeText:SetShadowOffset((shadow and 1) or 0, (shadow and -1) or 0)
    self.bar.text:SetTextColor(1, 1, 1, 1)
    self.bar.timeText:SetTextColor(1, 1, 1, 1)
end

function CastBar:UpdateIcon()
    local db = GetDb()
    if not db or not self.bar or not self.bar.icon then
        return
    end

    local iconSize = db.iconSize or 14
    self.bar.icon:SetSize(iconSize, iconSize)

    if db.showIcon then
        self.bar.icon:Show()
    else
        self.bar.icon:Hide()
    end
end

function CastBar:StartCast(isChannel)
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    local name, text, texture, startTime, endTime = nil, nil, nil, nil, nil
    if isChannel then
        name, text, texture, startTime, endTime = UnitChannelInfo("player")
    else
        name, text, texture, startTime, endTime = UnitCastingInfo("player")
    end

    if not name then
        self.bar:Hide()
        self.casting = nil
        return
    end

    self.casting = {
        isChannel = isChannel,
        startTime = (startTime or 0) / 1000,
        endTime = (endTime or 0) / 1000,
        name = name,
        texture = texture,
    }

    self.bar.icon:SetTexture(texture)
    self.bar.text:SetText(text or name or "")
    self.bar:Show()
    self.bar:SetScript("OnUpdate", function()
        self:OnUpdate()
    end)
end

function CastBar:StopCast()
    if not self.bar then
        return
    end
    self.casting = nil
    self.bar:Hide()
    self.bar:SetScript("OnUpdate", nil)
end

function CastBar:RefreshCast()
    if UnitChannelInfo("player") then
        self:StartCast(true)
        return
    end
    if UnitCastingInfo("player") then
        self:StartCast(false)
        return
    end
    self:StopCast()
end

function CastBar:OnUpdate()
    if not self.casting or not self.bar then
        return
    end

    local now = GetTime()
    local startTime = self.casting.startTime
    local endTime = self.casting.endTime
    if endTime <= startTime then
        self:StopCast()
        return
    end

    local duration = endTime - startTime
    local remaining = 0
    local progress = 0

    if self.casting.isChannel then
        remaining = endTime - now
        progress = remaining / duration
    else
        remaining = endTime - now
        progress = (now - startTime) / duration
    end

    if remaining <= 0 then
        self:StopCast()
        return
    end

    progress = math.max(0, math.min(1, progress))
    self.bar:SetMinMaxValues(0, 1)
    self.bar:SetValue(progress)
    self.bar.timeText:SetFormattedText("%.1f", remaining)
end

function CastBar:UpdateAll()
    local db = GetDb()
    if not db or not self.bar then
        return
    end

    if not db.enabled then
        self.bar:Hide()
        self.bar:SetScript("OnUpdate", nil)
        return
    end

    self:UpdateAnchor()
    self:UpdateTexture()
    self:UpdateFont()
    self:UpdateIcon()
    ApplyGradient(self.bar, CASTBAR_GRADIENT_START, CASTBAR_GRADIENT_END)

    if not self.casting then
        self.bar:Hide()
        self.bar:SetScript("OnUpdate", nil)
    end

    if not self.anchorPending then
        self.anchorPending = true
        C_Timer.After(0.1, function()
            self.anchorPending = false
            if self.bar then
                self:UpdateAnchor()
            end
        end)
    end

    if not self.anchorPendingSpec then
        self.anchorPendingSpec = true
        C_Timer.After(0.2, function()
            self.anchorPendingSpec = false
            if self.bar then
                self:UpdateAnchor()
            end
        end)
    end
end

function CastBar:HookRefreshLayout()
    if self.layoutHooked then
        return
    end
    if _G.CooldownViewerSettings and _G.CooldownViewerSettings.RefreshLayout then
        self:SecureHook(_G.CooldownViewerSettings, "RefreshLayout", function()
            self:UpdateAnchor()
        end)
        self.layoutHooked = true
    end
end

function CastBar:OnEnable()
    self:CreateBar()
    self:HookRefreshLayout()
    self:UpdateAll()
    self.bar:SetScript("OnUpdate", nil)

    self:RegisterEvent("PLAYER_ENTERING_WORLD", "UpdateAll")
    self:RegisterEvent("UNIT_SPELLCAST_START", function(_, unit)
        if unit == "player" then self:StartCast(false) end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_STOP", function(_, unit)
        if unit == "player" then self:RefreshCast() end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED", function(_, unit)
        if unit == "player" then self:RefreshCast() end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_FAILED", function(_, unit)
        if unit == "player" then self:RefreshCast() end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_DELAYED", function(_, unit)
        if unit == "player" then self:StartCast(false) end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START", function(_, unit)
        if unit == "player" then self:StartCast(true) end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP", function(_, unit)
        if unit == "player" then self:RefreshCast() end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE", function(_, unit)
        if unit == "player" then self:StartCast(true) end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_EMPOWER_START", function(_, unit)
        if unit == "player" then self:StartCast(false) end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_EMPOWER_STOP", function(_, unit)
        if unit == "player" then self:RefreshCast() end
    end)
    self:RegisterEvent("UNIT_SPELLCAST_EMPOWER_UPDATE", function(_, unit)
        if unit == "player" then self:StartCast(false) end
    end)
end
