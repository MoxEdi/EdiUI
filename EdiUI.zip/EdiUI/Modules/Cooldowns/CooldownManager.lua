-- EdiUI Cooldown Manager (Blizzard Cooldown Viewer)
-- Controls icon sizing, spacing, zoom, and bar fonts for Blizzard's Cooldown Manager.
local EdiUI = EdiUI
local CooldownManager = EdiUI:NewModule("CooldownManager", "AceHook-3.0", "AceEvent-3.0")

local function GetElvUILSM()
    local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI) or nil
    if E and E.Libs and E.Libs.LSM then
        return E.Libs.LSM
    end
    return nil
end

local function BuildFontStyle(outline, shadow)
    local style = outline or ""
    if style == "NONE" then
        style = ""
    end
    if shadow then
        if style == "" then
            style = "SHADOW"
        else
            style = "SHADOW" .. style
        end
    end
    return style
end

local function ResolveTextConfig(db, section, isCount)
    if not db then
        return {}
    end
    local text = db.text or {}
    local cfg = text[section] or {}
    local out = {}

    if isCount then
        out.font = cfg.countFont or db.font
        out.fontSize = cfg.countSize or db.fontSize
        out.fontOutline = cfg.countOutline or db.fontOutline
        if cfg.countShadow ~= nil then
            out.fontShadow = cfg.countShadow
        else
            out.fontShadow = db.fontShadow
        end
        out.xOffset = cfg.countX or 0
        out.yOffset = cfg.countY or 0
    else
        out.font = cfg.font or db.font
        out.fontSize = cfg.fontSize or db.fontSize
        out.fontOutline = cfg.fontOutline or db.fontOutline
        if cfg.fontShadow ~= nil then
            out.fontShadow = cfg.fontShadow
        else
            out.fontShadow = db.fontShadow
        end
        out.xOffset = cfg.xOffset or 0
        out.yOffset = cfg.yOffset or 0
    end

    return out
end

local function GetSectionKey(kind)
    if kind == "essential" then
        return "essentials"
    end
    if kind == "bufficon" then
        return "tracked"
    end
    return kind
end

local function GetSectionZoom(db, kind)
    local fallback = db.iconZoom or 0
    if kind == "essential" then
        return db.essentialZoom or fallback
    end
    if kind == "utility" then
        return db.utilityZoom or fallback
    end
    if kind == "bufficon" then
        return db.trackedZoom or fallback
    end
    return fallback
end

-- Calculate texture coordinates that crop (not stretch) to maintain aspect ratio
-- Set EDIUI_DISABLE_ICON_CROP = true to disable cropping for debugging
local function GetCroppedTexCoords(width, height, zoom)
    local z = zoom or 0

    -- Default square coords with zoom
    local left, right, top, bottom = z, 1 - z, z, 1 - z

    -- Skip cropping if disabled or invalid dimensions
    if _G.EDIUI_DISABLE_ICON_CROP then
        return left, right, top, bottom
    end

    if not width or not height or width <= 0 or height <= 0 then
        return left, right, top, bottom
    end

    -- Calculate aspect ratio and crop accordingly
    -- Texture is 1:1, so we crop to match frame's aspect ratio
    if width > height then
        -- Frame is wider than tall - crop top/bottom of texture
        local ratio = height / width
        local cropAmount = (1 - ratio) / 2 * (1 - 2 * z)
        top = z + cropAmount
        bottom = 1 - z - cropAmount
    elseif height > width then
        -- Frame is taller than wide - crop left/right of texture
        local ratio = width / height
        local cropAmount = (1 - ratio) / 2 * (1 - 2 * z)
        left = z + cropAmount
        right = 1 - z - cropAmount
    end

    return left, right, top, bottom
end

local function ApplyCooldownFont(cooldown, config, fallback)
    if not cooldown then
        return
    end

    local fontPath = fallback or STANDARD_TEXT_FONT
    local lsm = GetElvUILSM()
    if lsm and config.font and config.font ~= "" then
        fontPath = lsm:Fetch("font", config.font)
    end

    local flags = BuildFontStyle(config.fontOutline, config.fontShadow)
    local shadow = string.sub(flags, 1, 6) == "SHADOW"
    local style = flags
    if shadow then
        style = string.sub(flags, 7)
    end
    if style == "NONE" then
        style = ""
    end

    if cooldown.SetCountdownFont then
        pcall(cooldown.SetCountdownFont, cooldown, fontPath, config.fontSize, style)
    end

    if cooldown.GetCountdownFontString then
        local fs = cooldown:GetCountdownFontString()
        if fs then
            pcall(function()
                fs:SetShadowColor(0, 0, 0, (shadow and (style == "" and 1 or 0.6)) or 0)
                fs:SetShadowOffset((shadow and 1) or 0, (shadow and -1) or 0)
                fs:SetFont(fontPath or STANDARD_TEXT_FONT, config.fontSize, style)
                if config.xOffset or config.yOffset then
                    fs:ClearAllPoints()
                    fs:SetPoint("CENTER", cooldown, "CENTER", config.xOffset or 0, config.yOffset or 0)
                end
            end)
        end
    end
end

local function ApplyTextFont(fontString, config, fallback, anchorFrame, anchorPoint)
    if not fontString or not config then
        return
    end

    local fontPath = fallback or STANDARD_TEXT_FONT
    local lsm = GetElvUILSM()
    if lsm and config.font and config.font ~= "" then
        fontPath = lsm:Fetch("font", config.font)
    end

    local flags = BuildFontStyle(config.fontOutline, config.fontShadow)
    local shadow = string.sub(flags, 1, 6) == "SHADOW"
    local style = shadow and string.sub(flags, 7) or flags
    if style == "NONE" then
        style = ""
    end

    pcall(function()
        fontString:SetShadowColor(0, 0, 0, (shadow and (style == "" and 1 or 0.6)) or 0)
        fontString:SetShadowOffset((shadow and 1) or 0, (shadow and -1) or 0)
        fontString:SetFont(fontPath or STANDARD_TEXT_FONT, config.fontSize, style)
        if anchorFrame then
            fontString:ClearAllPoints()
            fontString:SetPoint(anchorPoint or "BOTTOMRIGHT", anchorFrame, anchorPoint or "BOTTOMRIGHT", config.xOffset or 0, config.yOffset or 0)
        end
    end)
end

local function CollectFontStrings(frame, out)
    if not frame or not frame.GetRegions then
        return
    end

    for _, region in ipairs({ frame:GetRegions() }) do
        if region and region.IsObjectType and region:IsObjectType("FontString") then
            table.insert(out, region)
        end
    end

    if frame.GetChildren then
        for _, child in ipairs({ frame:GetChildren() }) do
            CollectFontStrings(child, out)
        end
    end
end

local function IsCountCandidate(fontString)
    if not fontString or not fontString.GetName then
        return false
    end

    local name = fontString:GetName()
    if not name then
        return false
    end

    local lower = string.lower(name)
    if string.find(lower, "count", 1, true) then
        return true
    end
    if string.find(lower, "stack", 1, true) then
        return true
    end
    if string.find(lower, "charge", 1, true) then
        return true
    end

    return false
end

local function ApplyCountFont(frame, config)
    if not frame or not config then
        return
    end

    local cooldownFontString = nil
    if frame.Cooldown and frame.Cooldown.GetCountdownFontString then
        cooldownFontString = frame.Cooldown:GetCountdownFontString()
    end

    local fontStrings = {}
    CollectFontStrings(frame, fontStrings)

    local matched = false
    for _, fs in ipairs(fontStrings) do
        if fs ~= cooldownFontString and IsCountCandidate(fs) then
            ApplyTextFont(fs, config, STANDARD_TEXT_FONT, fs:GetParent() or frame, "BOTTOMRIGHT")
            matched = true
        end
    end

    if matched then
        return
    end

    for _, fs in ipairs(fontStrings) do
        if fs ~= cooldownFontString then
            ApplyTextFont(fs, config, STANDARD_TEXT_FONT, fs:GetParent() or frame, "BOTTOMRIGHT")
        end
    end
end

local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.cooldownManager
end

local function ApplyFont(fontString, db, fallback)
    if not fontString then
        return
    end

    local fontPath = fallback or STANDARD_TEXT_FONT
    local lsm = GetElvUILSM()
    if lsm and db.font and db.font ~= "" then
        fontPath = lsm:Fetch("font", db.font)
    end

    local flags = BuildFontStyle(db.fontOutline, db.fontShadow)
    local shadow = string.sub(flags, 1, 6) == "SHADOW"
    local style = flags
    if shadow then
        style = string.sub(flags, 7)
    end
    if style == "NONE" then
        style = ""
    end

    pcall(function()
        fontString:SetShadowColor(0, 0, 0, (shadow and (style == "" and 1 or 0.6)) or 0)
        fontString:SetShadowOffset((shadow and 1) or 0, (shadow and -1) or 0)
        fontString:SetFont(fontPath or STANDARD_TEXT_FONT, db.fontSize, style)
    end)
end

local function ApplyFontToFrame(frame, db, fallback)
    if not frame or not frame.GetRegions then
        return
    end

    for _, region in ipairs({ frame:GetRegions() }) do
        if region and region.IsObjectType and region:IsObjectType("FontString") then
            ApplyFont(region, db, fallback)
        end
    end

    if frame.GetChildren then
        for _, child in ipairs({ frame:GetChildren() }) do
            ApplyFontToFrame(child, db, fallback)
        end
    end
end

local function ApplyIcon(frame, width, height, zoom, textConfig, countConfig)
    if not frame then
        return
    end

    if not frame.__ediBaseW or not frame.__ediBaseH then
        local fw, fh = frame:GetSize()
        if fw and fh and fw > 0 and fh > 0 then
            frame.__ediBaseW = fw
            frame.__ediBaseH = fh
        end
    end

    if frame.Cooldown then
        ApplyCooldownFont(frame.Cooldown, textConfig, STANDARD_TEXT_FONT)
    end

    ApplyCountFont(frame, countConfig)

    local icon = frame.Icon

    -- Determine final dimensions first (needed for aspect ratio cropping)
    local targetW = width
    local targetH = height
    if targetW and targetW > 0 then
        if not targetH or targetH <= 0 then
            targetH = frame.__ediBaseH
            if not targetH or targetH <= 0 then
                if icon and icon.__ediBaseH and icon.__ediBaseH > 0 then
                    targetH = icon.__ediBaseH
                else
                    targetH = targetW
                end
            end
        end
    else
        targetW = frame.__ediBaseW or (icon and icon.__ediBaseW) or 0
        targetH = frame.__ediBaseH or (icon and icon.__ediBaseH) or 0
    end

    -- Calculate cropped texture coordinates to maintain aspect ratio
    local left, right, top, bottom = GetCroppedTexCoords(targetW, targetH, zoom)

    if icon then
        if not icon.__ediBaseW or not icon.__ediBaseH then
            local iw, ih = icon:GetSize()
            if iw and ih and iw > 0 and ih > 0 then
                icon.__ediBaseW = iw
                icon.__ediBaseH = ih
            end
        end
        if icon.SetTexCoord then
            icon:SetTexCoord(left, right, top, bottom)
        end
        if icon.Icon and icon.Icon.SetTexCoord then
            icon.Icon:SetTexCoord(left, right, top, bottom)
        end
        if icon.IconTexture and icon.IconTexture.SetTexCoord then
            icon.IconTexture:SetTexCoord(left, right, top, bottom)
        end
        if icon.texture and icon.texture.SetTexCoord then
            icon.texture:SetTexCoord(left, right, top, bottom)
        end
    end

    if width and width > 0 then
        frame:SetSize(targetW, targetH)
        if icon and icon.SetSize then
            icon:SetSize(targetW, targetH)
        end
    end
end

local function ApplyBar(frame, db, textConfig, countConfig)
    if not frame or not frame.Bar then
        return
    end

    local bar = frame.Bar
    if db.barWidth and db.barWidth > 0 then
        bar:SetWidth(db.barWidth)
    end

    ApplyFontToFrame(bar, db, STANDARD_TEXT_FONT)
    ApplyFontToFrame(frame, db, STANDARD_TEXT_FONT)

    if frame.Icon then
        local icon = frame.Icon
        local iconW, iconH = icon:GetSize()
        local left, right, top, bottom = GetCroppedTexCoords(iconW, iconH, db.iconZoom)
        if icon.SetTexCoord then
            icon:SetTexCoord(left, right, top, bottom)
        end
        if icon.Icon and icon.Icon.SetTexCoord then
            icon.Icon:SetTexCoord(left, right, top, bottom)
        end
        if icon.IconTexture and icon.IconTexture.SetTexCoord then
            icon.IconTexture:SetTexCoord(left, right, top, bottom)
        end
        if icon.texture and icon.texture.SetTexCoord then
            icon.texture:SetTexCoord(left, right, top, bottom)
        end
    end

    if frame.Cooldown then
        ApplyCooldownFont(frame.Cooldown, textConfig, STANDARD_TEXT_FONT)
    end
end

local function ApplyViewer(viewer, kind, db)
    if not viewer then
        return
    end

    local section = GetSectionKey(kind)
    local textConfig = ResolveTextConfig(db, section, false)
    local countConfig = ResolveTextConfig(db, section, true)

    if viewer.itemFramePool then
        for frame in viewer.itemFramePool:EnumerateActive() do
            if frame.Bar then
                ApplyBar(frame, db, textConfig, countConfig)
            else
                if kind == "essential" then
                    ApplyIcon(frame, db.essentialWidth, db.essentialHeight, GetSectionZoom(db, "essential"), textConfig, countConfig)
                elseif kind == "utility" then
                    ApplyIcon(frame, db.utilityWidth, db.utilityHeight, GetSectionZoom(db, "utility"), textConfig, countConfig)
                elseif kind == "bufficon" then
                    ApplyIcon(frame, db.buffIconWidth, db.buffIconHeight, GetSectionZoom(db, "bufficon"), textConfig, countConfig)
                end
            end
        end
    end
end

local hooksApplied = false
local layoutRefreshing = false
local editModeRegistered = false

local function CenterUtilityIcons()
    local db = GetDb()
    if not db or not db.centerUtilityIcons then
        return
    end

    local viewer = _G.UtilityCooldownViewer
    if not viewer or not viewer.itemFramePool then
        return
    end

    -- Collect all active utility frames with their original positions
    local frames = {}
    for frame in viewer.itemFramePool:EnumerateActive() do
        if frame and frame:IsShown() then
            local _, _, _, x, y = frame:GetPoint(1)
            if x and y then
                table.insert(frames, {
                    frame = frame,
                    x = x,
                    y = y,
                    width = frame:GetWidth() or db.utilityWidth or 41
                })
            end
        end
    end

    if #frames == 0 then
        return
    end

    -- Get viewer width
    local viewerWidth = viewer:GetWidth()
    if not viewerWidth or viewerWidth <= 0 then
        return
    end

    -- Group frames by row (based on Y coordinate)
    -- Frames with similar Y coordinates are in the same row
    local rows = {}
    local yTolerance = 5 -- Tolerance for Y coordinate matching

    for _, frameData in ipairs(frames) do
        local foundRow = false
        for _, row in ipairs(rows) do
            if math.abs(row.y - frameData.y) < yTolerance then
                table.insert(row.frames, frameData)
                foundRow = true
                break
            end
        end
        if not foundRow then
            table.insert(rows, {
                y = frameData.y,
                frames = { frameData }
            })
        end
    end

    -- Sort frames within each row by X coordinate
    for _, row in ipairs(rows) do
        table.sort(row.frames, function(a, b) return a.x < b.x end)
    end

    -- Center each row independently
    local spacing = 2 -- Spacing between icons
    for _, row in ipairs(rows) do
        -- Calculate total width of this row
        local rowWidth = 0
        for i, frameData in ipairs(row.frames) do
            rowWidth = rowWidth + frameData.width
            if i < #row.frames then
                rowWidth = rowWidth + spacing
            end
        end

        -- Calculate starting X position to center this row
        local startX = (viewerWidth - rowWidth) / 2

        -- Reposition frames in this row
        for i, frameData in ipairs(row.frames) do
            frameData.frame:ClearAllPoints()
            frameData.frame:SetPoint("BOTTOMLEFT", viewer, "BOTTOMLEFT", startX, frameData.y)
            startX = startX + frameData.width + spacing
        end
    end
end

local function RefreshLayout()
    if layoutRefreshing then
        return
    end
    layoutRefreshing = true

    if _G.CooldownViewerSettings and _G.CooldownViewerSettings.RefreshLayout then
        pcall(function()
            _G.CooldownViewerSettings:RefreshLayout()
        end)
    end

    -- Apply utility icon centering after layout refresh
    C_Timer.After(0.05, function()
        CenterUtilityIcons()
    end)

    local cluster = EdiUI and EdiUI:GetModule("ClusterPositioning", true)
    if cluster and cluster.Recalculate then
        cluster:Recalculate()
    end

    layoutRefreshing = false
end

function CooldownManager:ApplySettings()
    local db = GetDb()
    if not db then
        return
    end

    ApplyViewer(_G.EssentialCooldownViewer, "essential", db)
    ApplyViewer(_G.UtilityCooldownViewer, "utility", db)
    ApplyViewer(_G.BuffIconCooldownViewer, "bufficon", db)
    ApplyViewer(_G.BuffBarCooldownViewer, "buffbar", db)

    -- Center utility icons if enabled
    C_Timer.After(0.05, function()
        CenterUtilityIcons()
    end)
end

function CooldownManager:HandleViewer(viewer, kind)
    if not viewer or viewer.ediHooked then
        return
    end

    if viewer.OnAcquireItemFrame then
        self:SecureHook(viewer, "OnAcquireItemFrame", function(_, frame)
            local db = GetDb()
            if not db then
                return
            end
            if frame and frame.Bar then
                local section = GetSectionKey(kind)
                local textConfig = ResolveTextConfig(db, section, false)
                local countConfig = ResolveTextConfig(db, section, true)
                ApplyBar(frame, db, textConfig, countConfig)
            else
                local section = GetSectionKey(kind)
                local textConfig = ResolveTextConfig(db, section, false)
                local countConfig = ResolveTextConfig(db, section, true)
                if kind == "essential" then
                    ApplyIcon(frame, db.essentialWidth, db.essentialHeight, GetSectionZoom(db, "essential"), textConfig, countConfig)
                elseif kind == "utility" then
                    ApplyIcon(frame, db.utilityWidth, db.utilityHeight, GetSectionZoom(db, "utility"), textConfig, countConfig)
                elseif kind == "bufficon" then
                    ApplyIcon(frame, db.buffIconWidth, db.buffIconHeight, GetSectionZoom(db, "bufficon"), textConfig, countConfig)
                end
            end

            -- Recenter utility icons when a new frame is acquired
            if kind == "utility" then
                C_Timer.After(0.05, function()
                    CenterUtilityIcons()
                end)
            end
        end)
    end

    -- Hook Layout method if it exists (for utility viewer centering)
    if kind == "utility" and viewer.Layout then
        self:SecureHook(viewer, "Layout", function()
            C_Timer.After(0.05, function()
                CenterUtilityIcons()
            end)
        end)
    end

    viewer.ediHooked = true
end

function CooldownManager:ApplyHooks()
    if hooksApplied then
        return
    end

    if _G.CooldownViewerSettings then
        self:SecureHook(_G.CooldownViewerSettings, "RefreshLayout", function()
            self:ApplySettings()
        end)
    end

    self:HandleViewer(_G.EssentialCooldownViewer, "essential")
    self:HandleViewer(_G.UtilityCooldownViewer, "utility")
    self:HandleViewer(_G.BuffIconCooldownViewer, "bufficon")
    self:HandleViewer(_G.BuffBarCooldownViewer, "buffbar")

    hooksApplied = true
end

-- Register EditMode callbacks using modern EventRegistry (12.0+)
function CooldownManager:RegisterEditModeCallbacks()
    if editModeRegistered then
        return
    end

    local Compat = EdiUI and EdiUI.Compat
    if not Compat or not Compat.RegisterEditModeCallback then
        editModeRegistered = true
        return
    end

    -- Use EventRegistry for EditMode events (12.0+ approach)
    Compat.RegisterEditModeCallback("EditMode.Enter", function()
        self:ApplySettings()
    end)

    Compat.RegisterEditModeCallback("EditMode.Exit", function()
        RefreshLayout()
    end)

    editModeRegistered = true
end

function CooldownManager:OnAddonLoaded(_, name)
    if name == "Blizzard_EditMode" then
        self:RegisterEditModeCallbacks()
    end
end

function CooldownManager:OnPlayerEnteringWorld()
    self:RegisterEditModeCallbacks()
end

function CooldownManager:Update()
    self:ApplyHooks()
    self:ApplySettings()
    RefreshLayout()
end

function CooldownManager:OnEnable()
    local db = GetDb()
    if not db then
        return
    end

    local Compat = EdiUI and EdiUI.Compat

    -- Register events for EditMode
    self:RegisterEvent("ADDON_LOADED", "OnAddonLoaded")
    self:RegisterEvent("PLAYER_ENTERING_WORLD", "OnPlayerEnteringWorld")

    -- Load Blizzard Cooldown Viewer if available
    if Compat then
        if not Compat.IsAddOnLoaded("Blizzard_CooldownViewer") then
            local name, title, notes, loadable = Compat.GetAddOnInfo("Blizzard_CooldownViewer")
            if loadable then
                pcall(Compat.LoadAddOn, "Blizzard_CooldownViewer")
            end
        end
    else
        -- Fallback to direct API
        if not C_AddOns.IsAddOnLoaded("Blizzard_CooldownViewer") then
            local name, title, notes, loadable = C_AddOns.GetAddOnInfo("Blizzard_CooldownViewer")
            if loadable then
                pcall(C_AddOns.LoadAddOn, "Blizzard_CooldownViewer")
            end
        end
    end

    -- Register EditMode callbacks immediately if EditMode is already loaded
    self:RegisterEditModeCallbacks()

    self:Update()

    C_Timer.After(1.0, function()
        if GetDb() then
            self:Update()
        end
    end)

    C_Timer.After(2.0, function()
        RefreshLayout()
    end)
end
