-- EdiUI Installer
-- Guided profile installer similar to ElvUI's flow.
local EdiUI = EdiUI

local Installer = {}
EdiUI.Installer = Installer

local InstallerFrame

-- Helper functions to get modules (lazy loading)
local function GetColors()
    return EdiUI.Colors
end

local function GetCompat()
    -- Return EdiUI.Compat if available, otherwise create a fallback
    if EdiUI.Compat then
        return EdiUI.Compat
    end

    -- Fallback Compat for 12.0+
    return {
        IsAddOnLoaded = C_AddOns.IsAddOnLoaded,
    }
end

-- Color constants
local COLOR_BLUE, COLOR_GOLD

local function InitColors()
    if COLOR_BLUE then return end
    local Colors = GetColors()
    if Colors then
        COLOR_BLUE = Colors.BLUE
        COLOR_GOLD = Colors.GOLD
    else
        -- Fallback colors
        COLOR_BLUE = { r = 0.906, g = 0.298, b = 0.235 }
        COLOR_GOLD = { r = 1.0, g = 0.78, b = 0.29 }
    end
end

local function ApplyFont(fs, desiredSize)
    if not fs then return end
    local font, currentSize, flags = fs:GetFont()
    if font then
        fs:SetFont(font, desiredSize or currentSize or 12, "OUTLINE")
    else
        -- Fallback to standard font if GetFont returns nil
        fs:SetFont(STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", desiredSize or 12, "OUTLINE")
    end
end

local function GetState()
    if not EdiUI.db or not EdiUI.db.profile then
        return nil
    end
    return EdiUI.db.profile.installer
end

local function GetGlobalState()
    if not EdiUI.db or not EdiUI.db.global then
        return nil
    end
    if not EdiUI.db.global.installedProfiles then
        EdiUI.db.global.installedProfiles = {}
    end
    return EdiUI.db.global.installedProfiles
end

local function EnsureState()
    local state = GetState()
    if not state then
        return nil
    end
    if not state.stage or state.stage < 1 then
        state.stage = 1
    end
    if state.completed == nil then
        state.completed = false
    end
    if state.neverAutoOpen == nil then
        state.neverAutoOpen = false
    end
    if state.skipNextElvUIAutoOpen == nil then
        state.skipNextElvUIAutoOpen = false
    end
    return state
end

-- Step definitions
local STEPS = {
    { name = "Welcome", key = "welcome" },
    { name = "ElvUI", key = "elvui" },
    { name = "EditMode", key = "editmode" },
    { name = "Details", key = "details" },
    { name = "Plater", key = "plater" },
    { name = "WarpDeplete", key = "warpdeplete" },
    { name = "BigWigs", key = "bigwigs" },
    { name = "Complete", key = "complete" },
}
local MAX_STAGE = #STEPS

-- Progress bar color interpolation (red -> yellow -> green)
local function GetProgressColor(progress)
    -- progress is 0 to 1
    local r, g, b
    if progress < 0.5 then
        -- Red to Yellow (0 to 0.5)
        local t = progress * 2
        r = 1
        g = t
        b = 0
    else
        -- Yellow to Green (0.5 to 1)
        local t = (progress - 0.5) * 2
        r = 1 - t
        g = 1
        b = 0
    end
    return r, g, b
end

local function BuildFrame()
    InitColors()
    local useSkin = EdiUI.Skin and EdiUI.Skin:IsEnabled()
    local frame = CreateFrame("Frame", "EdiUI_InstallerFrame", UIParent, "BackdropTemplate")
    frame:SetSize(820, 540)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(100)
    frame:SetToplevel(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    if not useSkin then
        frame:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            tile = false,
            edgeSize = 1,
            insets = { left = 0, right = 0, top = 0, bottom = 0 }
        })
        frame:SetBackdropColor(0.08, 0.08, 0.1, 0.98)
        frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    end

    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(35)
    titleBar:SetPoint("TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", 0, 0)
    if not useSkin then
        titleBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
        titleBar:SetBackdropColor(0.12, 0.12, 0.15, 1)
    end

    local title = titleBar:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("CENTER")
    title:SetText("|cffe74c3cEdi|r|cffffc84aUI Installation|r")
    title:SetShadowColor(0, 0, 0, 0.8)
    title:SetShadowOffset(1, -1)
    ApplyFont(title, 24)

    -- Steps sidebar on the right
    local stepsPanel = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    stepsPanel:SetWidth(140)
    stepsPanel:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 0, -35)
    stepsPanel:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", 0, 0)
    if not useSkin then
        stepsPanel:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        stepsPanel:SetBackdropColor(0.06, 0.06, 0.08, 1)
        stepsPanel:SetBackdropBorderColor(0.2, 0.2, 0.25, 1)
    end

    -- Steps header
    local stepsHeader = stepsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    stepsHeader:SetPoint("TOP", stepsPanel, "TOP", 0, -15)
    stepsHeader:SetText("|cffffc84aSteps|r")
    stepsHeader:SetShadowColor(0, 0, 0, 0.8)
    stepsHeader:SetShadowOffset(1, -1)
    ApplyFont(stepsHeader, 18)

    -- Create step labels
    frame.stepLabels = {}
    for i, step in ipairs(STEPS) do
        local label = stepsPanel:CreateFontString(nil, "ARTWORK", "GameFontNormal")
        label:SetPoint("TOP", stepsHeader, "BOTTOM", 0, -15 - (i - 1) * 25)
        label:SetText(step.name)
        label:SetTextColor(0.5, 0.5, 0.5) -- Dimmed by default
        label:SetShadowColor(0, 0, 0, 0.8)
        label:SetShadowOffset(1, -1)
        ApplyFont(label, 14)
        frame.stepLabels[i] = label
    end

    frame.stepsPanel = stepsPanel

    -- Main content area (adjusted for sidebar)
    local contentArea = CreateFrame("Frame", nil, frame)
    contentArea:SetPoint("TOPLEFT", frame, "TOPLEFT", 0, -35)
    contentArea:SetPoint("BOTTOMRIGHT", stepsPanel, "BOTTOMLEFT", 0, 0)
    frame.contentArea = contentArea

    -- Logo with glitch effect
    local logoFrame = CreateFrame("Frame", nil, contentArea)
    logoFrame:SetSize(160, 160)
    logoFrame:SetPoint("TOP", contentArea, "TOP", 0, -20)

    local logo = logoFrame:CreateTexture(nil, "ARTWORK")
    logo:SetTexture("Interface\\AddOns\\EdiUI\\Media\\Logo\\logo.tga")
    logo:SetAllPoints()
    logoFrame.texture = logo
    frame.logo = logoFrame

    -- Apply glitch effect (cyberpunk preset)
    if EdiUI.GlitchEffect then
        EdiUI.GlitchEffect:Apply(logoFrame, EdiUI.GlitchEffect.Presets.cyberpunk)
    end

    local close = CreateFrame("Button", nil, titleBar)
    close:SetSize(25, 25)
    close:SetPoint("RIGHT", -5, 0)
    close:SetNormalFontObject("GameFontNormalLarge")
    close:SetText("X")
    close:GetFontString():SetTextColor(0.7, 0.7, 0.7)
    close:SetScript("OnClick", function() frame:Hide() end)
    close:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(1, 0.3, 0.3) end)
    close:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(0.7, 0.7, 0.7) end)

    local stepTitle = contentArea:CreateFontString(nil, "ARTWORK", "GameFontNormalHuge")
    stepTitle:SetPoint("TOP", logoFrame, "BOTTOM", 0, -8)
    stepTitle:SetWidth(600)
    stepTitle:SetJustifyH("CENTER")
    stepTitle:SetText("Step")
    stepTitle:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    stepTitle:SetShadowColor(0, 0, 0, 0.8)
    stepTitle:SetShadowOffset(1, -1)
    ApplyFont(stepTitle, 24)

    -- Progress bar with gradient color
    local progressBar = CreateFrame("StatusBar", nil, contentArea, "BackdropTemplate")
    progressBar:SetSize(380, 14)
    progressBar:SetPoint("BOTTOM", contentArea, "BOTTOM", 0, 56)
    progressBar:SetStatusBarTexture("Interface\\Buttons\\WHITE8x8")
    progressBar:SetMinMaxValues(1, MAX_STAGE)
    progressBar:SetValue(1)
    -- Initial color (red)
    progressBar:SetStatusBarColor(1, 0, 0, 1)
    if not useSkin then
        progressBar:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        progressBar:SetBackdropColor(0.15, 0.15, 0.18, 1)
        progressBar:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    end

    local progressBorder = CreateFrame("Frame", nil, progressBar, "BackdropTemplate")
    progressBorder:SetPoint("TOPLEFT", -1, 1)
    progressBorder:SetPoint("BOTTOMRIGHT", 1, -1)
    progressBorder:SetBackdrop({
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    progressBorder:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)

    -- Progress text (X / Y format)
    local progressText = progressBar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    progressText:SetPoint("CENTER")
    progressText:SetText("1 / " .. MAX_STAGE)
    progressText:SetTextColor(1, 1, 1)
    progressText:SetShadowColor(0, 0, 0, 1)
    progressText:SetShadowOffset(1, -1)
    ApplyFont(progressText, 12)
    frame.progressText = progressText

    local prevBtn = CreateFrame("Button", nil, contentArea, "BackdropTemplate")
    prevBtn:SetSize(70, 24)
    prevBtn:SetPoint("RIGHT", progressBar, "LEFT", -8, 0)
    if not useSkin then
        prevBtn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        prevBtn:SetBackdropColor(0.15, 0.15, 0.18, 1)
        prevBtn:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    else
        EdiUI.Skin:ApplyButton(prevBtn)
    end
    local prevText = prevBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    prevText:SetPoint("CENTER")
    prevText:SetText("Previous")
    prevText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    prevText:SetShadowColor(0, 0, 0, 0.8)
    prevText:SetShadowOffset(1, -1)
    ApplyFont(prevText, 12)

    local nextBtn = CreateFrame("Button", nil, contentArea, "BackdropTemplate")
    nextBtn:SetSize(70, 24)
    nextBtn:SetPoint("LEFT", progressBar, "RIGHT", 8, 0)
    if not useSkin then
        nextBtn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        nextBtn:SetBackdropColor(0.15, 0.15, 0.18, 1)
        nextBtn:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)
    else
        EdiUI.Skin:ApplyButton(nextBtn)
    end
    local nextText = nextBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    nextText:SetPoint("CENTER")
    nextText:SetText("Continue")
    nextText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    nextText:SetShadowColor(0, 0, 0, 0.8)
    nextText:SetShadowOffset(1, -1)
    ApplyFont(nextText, 12)

    local stepDesc = contentArea:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    stepDesc:SetPoint("TOP", stepTitle, "BOTTOM", 0, -24)
    stepDesc:SetWidth(600)
    stepDesc:SetHeight(50)
    stepDesc:SetJustifyH("CENTER")
    stepDesc:SetJustifyV("MIDDLE")
    stepDesc:SetText("")
    stepDesc:SetTextColor(0.8, 0.8, 0.8)
    stepDesc:SetShadowColor(0, 0, 0, 0.8)
    stepDesc:SetShadowOffset(1, -1)
    ApplyFont(stepDesc, 16)

    local statusText = contentArea:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    statusText:SetPoint("TOP", stepDesc, "BOTTOM", 0, -12)
    statusText:SetWidth(600)
    statusText:SetJustifyH("CENTER")
    statusText:SetJustifyV("TOP")
    statusText:SetText("")
    statusText:SetTextColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b)
    statusText:SetShadowColor(0, 0, 0, 0.8)
    statusText:SetShadowOffset(1, -1)
    ApplyFont(statusText, 16)

    local hintText = contentArea:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    hintText:SetPoint("TOP", statusText, "BOTTOM", 0, -8)
    hintText:SetWidth(600)
    hintText:SetJustifyH("CENTER")
    hintText:SetJustifyV("TOP")
    hintText:SetText("")
    hintText:SetTextColor(0.6, 0.6, 0.6)
    hintText:SetShadowColor(0, 0, 0, 0.8)
    hintText:SetShadowOffset(1, -1)
    ApplyFont(hintText, 14)

    local actionBtn = CreateFrame("Button", nil, contentArea, "BackdropTemplate")
    actionBtn:SetSize(180, 32)
    actionBtn:SetPoint("BOTTOM", progressBar, "TOP", -95, 10)
    if not useSkin then
        actionBtn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        actionBtn:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        actionBtn:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
    else
        EdiUI.Skin:ApplyButton(actionBtn)
    end

    local btnText = actionBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    btnText:SetPoint("CENTER")
    btnText:SetText("Apply")
    btnText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    btnText:SetShadowColor(0, 0, 0, 0.8)
    btnText:SetShadowOffset(1, -1)
    ApplyFont(btnText, 16)

    -- Second action button (for ElvUI Dark Mode or Load Profiles)
    local darkBtn = CreateFrame("Button", nil, contentArea, "BackdropTemplate")
    darkBtn:SetSize(180, 32)
    darkBtn:SetPoint("LEFT", actionBtn, "RIGHT", 10, 0)
    if not useSkin then
        darkBtn:SetBackdrop({
            bgFile = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 1,
        })
        darkBtn:SetBackdropColor(0.15, 0.15, 0.18, 1)
        darkBtn:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)
    else
        EdiUI.Skin:ApplyButton(darkBtn)
    end

    local darkText = darkBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    darkText:SetPoint("CENTER")
    darkText:SetText("ElvUI Dark Mode")
    darkText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    darkText:SetShadowColor(0, 0, 0, 0.8)
    darkText:SetShadowOffset(1, -1)
    ApplyFont(darkText, 16)
    darkBtn:Hide()
    frame.darkBtn = darkBtn
    frame.darkBtn.text = darkText

    local resetBtn = CreateFrame("Button", nil, frame)
    resetBtn:SetPoint("BOTTOMLEFT", 14, 10)
    resetBtn:SetText("Reset Installer")
    resetBtn:SetNormalFontObject("GameFontNormalSmall")
    resetBtn:GetFontString():SetTextColor(0.5, 0.5, 0.5)
    resetBtn:GetFontString():SetShadowColor(0, 0, 0, 0.8)
    resetBtn:GetFontString():SetShadowOffset(1, -1)
    resetBtn:SetScript("OnEnter", function(self)
        self:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    end)
    resetBtn:SetScript("OnLeave", function(self)
        self:GetFontString():SetTextColor(0.5, 0.5, 0.5)
    end)

    if not useSkin then
        actionBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.4, 0.7, 1, 1)
        end)
        actionBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
        end)

        darkBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.2, 0.2, 0.25, 1)
        end)
        darkBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0.15, 0.15, 0.18, 1)
        end)

        prevBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.2, 0.2, 0.25, 1)
        end)
        prevBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0.15, 0.15, 0.18, 1)
        end)

        nextBtn:SetScript("OnEnter", function(self)
            self:SetBackdropColor(0.2, 0.2, 0.25, 1)
        end)
        nextBtn:SetScript("OnLeave", function(self)
            self:SetBackdropColor(0.15, 0.15, 0.18, 1)
        end)
    end

    if useSkin then
        EdiUI.Skin:ApplyFrame(frame, 'Transparent')
        EdiUI.Skin:ApplyFrame(titleBar, 'Transparent')
        EdiUI.Skin:ApplyFrame(stepsPanel, 'Transparent')
        EdiUI.Skin:ApplyCloseButton(close)
        -- Hide the text "X" since ElvUI's skin provides its own styled close icon
        close:SetText("")
        EdiUI.Skin:ApplyStatusBar(progressBar)
        progressBorder:Hide()
    end

    frame.stepTitle = stepTitle
    frame.progressBar = progressBar
    frame.prevBtn = prevBtn
    frame.nextBtn = nextBtn
    frame.stepDesc = stepDesc
    frame.statusText = statusText
    frame.hintText = hintText
    frame.actionBtn = actionBtn
    frame.actionBtn.text = btnText
    frame.resetBtn = resetBtn

    tinsert(UISpecialFrames, "EdiUI_InstallerFrame")
    return frame
end

local function SetStatus(frame, text, ok)
    if not text then
        frame.statusText:SetText("")
        return
    end
    if ok then
        frame.statusText:SetText("|cff00ff00" .. text .. "|r")
    else
        frame.statusText:SetText("|cffffc84a" .. text .. "|r")
    end
end

local function UpdateStepLabels(frame, currentStage)
    for i, label in ipairs(frame.stepLabels) do
        if i == currentStage then
            -- Current step - highlighted in gold
            label:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
        elseif i < currentStage then
            -- Completed steps - green
            label:SetTextColor(0, 0.8, 0)
        else
            -- Future steps - dimmed
            label:SetTextColor(0.5, 0.5, 0.5)
        end
    end
end

local function UpdateProgressBar(frame, stage)
    frame.progressBar:SetValue(stage)
    frame.progressText:SetText(stage .. " / " .. MAX_STAGE)

    -- Calculate progress (0 to 1)
    local progress = (stage - 1) / (MAX_STAGE - 1)
    local r, g, b = GetProgressColor(progress)
    frame.progressBar:SetStatusBarColor(r, g, b, 1)
end

-- Check if any profiles have been installed
local function HasInstalledProfiles()
    local profiles = GetGlobalState()
    if not profiles then return false end

    for addon, installed in pairs(profiles) do
        if installed then return true end
    end
    return false
end

-- Load all installed profiles at once
local function LoadAllProfiles()
    local Profiles = EdiUI.Profiles
    local Compat = GetCompat()
    if not Profiles then return false, "Profiles module not loaded." end

    local profiles = GetGlobalState()
    if not profiles then return false, "No profiles found." end

    local loaded = 0
    local errors = {}

    -- Load ElvUI if installed
    if profiles.elvui and Compat.IsAddOnLoaded("ElvUI") then
        local ok, err = Profiles:ImportElvUIProfile()
        if ok then
            Profiles:ImportElvUIGlobal()
            Profiles:ImportElvUIPrivate()
            Profiles:ImportElvUIAuras()
            loaded = loaded + 1
        else
            table.insert(errors, "ElvUI: " .. (err or "failed"))
        end
    elseif profiles.elvuiDark and Compat.IsAddOnLoaded("ElvUI") then
        local ok, err = Profiles:ImportElvUIDarkProfile()
        if ok then
            Profiles:ImportElvUIGlobal()
            Profiles:ImportElvUIPrivate()
            Profiles:ImportElvUIAuras()
            loaded = loaded + 1
        else
            table.insert(errors, "ElvUI Dark: " .. (err or "failed"))
        end
    end

    -- Load Blizzard EditMode if installed
    if profiles.editmode then
        local ok, err = Profiles:ImportEditModeProfile()
        if ok then
            loaded = loaded + 1
        else
            table.insert(errors, "EditMode: " .. (err or "failed"))
        end
    end

    -- Load Details if installed
    if profiles.details and Compat.IsAddOnLoaded("Details") then
        local ok, err = Profiles:ImportDetailsProfile()
        if ok then
            loaded = loaded + 1
        else
            table.insert(errors, "Details: " .. (err or "failed"))
        end
    end

    -- Load Plater if installed
    if profiles.plater and Compat.IsAddOnLoaded("Plater") then
        local ok, err = Profiles:ImportPlaterProfile()
        if ok then
            loaded = loaded + 1
        else
            table.insert(errors, "Plater: " .. (err or "failed"))
        end
    end

    -- Load WarpDeplete if installed
    if profiles.warpdeplete and Compat.IsAddOnLoaded("WarpDeplete") then
        local ok, err = Profiles:ImportWarpDepleteProfile()
        if ok then
            loaded = loaded + 1
        else
            table.insert(errors, "WarpDeplete: " .. (err or "failed"))
        end
    end

    if loaded > 0 then
        return true, "Loaded " .. loaded .. " profile(s)."
    else
        if #errors > 0 then
            return false, table.concat(errors, ", ")
        end
        return false, "No profiles to load."
    end
end

local function OpenEditModeAndResume(frame)
    local Compat = GetCompat()
    if Installer.editModeExitHandler and Compat and Compat.UnregisterEditModeCallback then
        Compat.UnregisterEditModeCallback("EditMode.Exit", Installer.editModeExitHandler)
        Compat.UnregisterEditModeCallback("EditMode.Edit", Installer.editModeExitHandler)
        Installer.editModeExitHandler = nil
    end
    if Installer.editModeEnterHandler and Compat and Compat.UnregisterEditModeCallback then
        Compat.UnregisterEditModeCallback("EditMode.Enter", Installer.editModeEnterHandler)
        Installer.editModeEnterHandler = nil
    end

    local function onExit()
        if Compat and Compat.UnregisterEditModeCallback then
            Compat.UnregisterEditModeCallback("EditMode.Exit", onExit)
            Compat.UnregisterEditModeCallback("EditMode.Edit", onExit)
        end
        Installer.editModeExitHandler = nil
        if InstallerFrame then
            InstallerFrame:Show()
            Installer:UpdateStage()
        end
    end

    local function onEnter()
        if Compat and Compat.UnregisterEditModeCallback then
            Compat.UnregisterEditModeCallback("EditMode.Enter", onEnter)
        end
        Installer.editModeEnterHandler = nil
        if InstallerFrame then
            InstallerFrame:Hide()
        end
    end

    Installer.editModeExitHandler = onExit
    if Compat and Compat.RegisterEditModeCallback then
        Compat.RegisterEditModeCallback("EditMode.Exit", onExit)
        Compat.RegisterEditModeCallback("EditMode.Edit", onExit)
    end
    Installer.editModeEnterHandler = onEnter
    if Compat and Compat.RegisterEditModeCallback then
        Compat.RegisterEditModeCallback("EditMode.Enter", onEnter)
    end
end

function Installer:UpdateStage()
    local state = EnsureState()
    if not state then
        return
    end

    local stage = state.stage
    local frame = InstallerFrame
    if not frame then
        return
    end

    local Compat = GetCompat()
    SetStatus(frame, nil)
    frame.hintText:SetText("")

    local displayStage = stage
    if displayStage < 1 then
        displayStage = 1
    elseif displayStage > MAX_STAGE then
        displayStage = MAX_STAGE
    end

    -- Update progress bar with gradient color
    UpdateProgressBar(frame, displayStage)

    -- Update step labels in sidebar
    UpdateStepLabels(frame, displayStage)

    frame.prevBtn:SetShown(stage > 1)
    frame.nextBtn:SetShown(stage < MAX_STAGE)
    frame.prevBtn:SetScript("OnClick", function()
        state.stage = math.max(1, (state.stage or 1) - 1)
        Installer:UpdateStage()
    end)
    frame.nextBtn:SetScript("OnClick", function()
        state.stage = math.min(MAX_STAGE, (state.stage or 1) + 1)
        Installer:UpdateStage()
    end)

    frame.resetBtn:SetScript("OnClick", function()
        state.stage = 1
        state.completed = false
        Installer:UpdateStage()
    end)

    -- Step 1: Welcome
    if stage == 1 then
        frame.stepTitle:SetText("Welcome to |cffe74c3cEdi|r|cffffc84aUI|r")

        local hasProfiles = HasInstalledProfiles()

        if hasProfiles then
            frame.stepDesc:SetText("To load your installed profiles onto this character,\nclick 'Load Profiles'.")
            frame.hintText:SetText("To start the installation process again, click 'Continue'.")
            frame.actionBtn.text:SetText("Load Profiles")
            frame.actionBtn:Show()
            frame.darkBtn:Hide()
            frame.actionBtn:ClearAllPoints()
            frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)

            frame.actionBtn:SetScript("OnClick", function()
                local ok, msg = LoadAllProfiles()
                if ok then
                    SetStatus(frame, msg, true)
                    state.completed = false
                    state.stage = MAX_STAGE
                    Installer:UpdateStage()
                else
                    SetStatus(frame, msg, false)
                end
            end)
        else
            frame.stepDesc:SetText("To start the installation process, click 'Continue'.")
            frame.hintText:SetText("This will guide you through setting up ElvUI, Edit Mode, Details, Plater, WarpDeplete, and BigWigs.")
            frame.actionBtn:Hide()
            frame.darkBtn:Hide()
        end

    -- Step 2: ElvUI (Profile + Global + Private + Auras combined)
    elseif stage == 2 then
        frame.stepTitle:SetText("ElvUI Profile")
        frame.stepDesc:SetText("Click to import the complete ElvUI profile\n(includes Global, Private, and Auras).")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("ElvUI")
        if not Compat.IsAddOnLoaded("ElvUI") then
            frame.actionBtn:Hide()
            frame.darkBtn:Hide()
            SetStatus(frame, "ElvUI not detected. Enable it to apply.", false)
            return
        end
        frame.actionBtn:Show()
        frame.darkBtn:Show()
        -- Position for two buttons side by side
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", -95, 10)
        frame.darkBtn.text:SetText("ElvUI Dark Mode")

        -- Regular ElvUI Profile button
        frame.actionBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end

            local ok, err = Profiles:ImportElvUIProfile()
            if not ok then
                SetStatus(frame, err or "ElvUI Profile import failed.", false)
                return
            end

            ok, err = Profiles:ImportElvUIGlobal()
            if not ok then
                SetStatus(frame, err or "ElvUI Global import failed.", false)
                return
            end

            ok, err = Profiles:ImportElvUIPrivate()
            if not ok then
                SetStatus(frame, err or "ElvUI Private import failed.", false)
                return
            end

            ok, err = Profiles:ImportElvUIAuras()
            if not ok then
                SetStatus(frame, err or "ElvUI Auras import failed.", false)
                return
            end

            -- Track installed profile
            local profiles = GetGlobalState()
            if profiles then
                profiles.elvui = true
                profiles.elvuiDark = false
            end

            state.stage = 3
            SetStatus(frame, "ElvUI profile imported successfully!", true)
            Installer:UpdateStage()
        end)

        -- ElvUI Dark Mode button
        frame.darkBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end

            local ok, err = Profiles:ImportElvUIDarkProfile()
            if not ok then
                SetStatus(frame, err or "ElvUI Dark Profile import failed.", false)
                return
            end

            ok, err = Profiles:ImportElvUIGlobal()
            if not ok then
                SetStatus(frame, err or "ElvUI Global import failed.", false)
                return
            end

            ok, err = Profiles:ImportElvUIPrivate()
            if not ok then
                SetStatus(frame, err or "ElvUI Private import failed.", false)
                return
            end

            ok, err = Profiles:ImportElvUIAuras()
            if not ok then
                SetStatus(frame, err or "ElvUI Auras import failed.", false)
                return
            end

            -- Track installed profile
            local profiles = GetGlobalState()
            if profiles then
                profiles.elvui = false
                profiles.elvuiDark = true
            end

            state.stage = 3
            SetStatus(frame, "ElvUI Dark Mode profile imported successfully!", true)
            Installer:UpdateStage()
        end)

    -- Step 3: Blizzard EditMode
    elseif stage == 3 then
        frame.stepTitle:SetText("Blizzard Edit Mode")
        frame.stepDesc:SetText("Click to import the Blizzard Edit Mode layout.")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("Apply Edit Mode")
        frame.actionBtn:Show()
        frame.darkBtn:Hide()
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)
        frame.actionBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end
            local ok, err = Profiles:ImportEditModeProfile()
            if ok then
                -- Track installed profile
                local profiles = GetGlobalState()
                if profiles then
                    profiles.editmode = true
                end

                state.stage = 4
                SetStatus(frame, "Edit Mode layout imported.", true)
                Installer:UpdateStage()
            else
                if err and err:find("Layout imported but could not activate") then
                    local profiles = GetGlobalState()
                    if profiles then
                        profiles.editmode = true
                    end

                    state.stage = 4
                    SetStatus(frame, "Open Edit Mode (Esc → Edit Mode), select EdiUI, then exit to continue.", false)
                    frame.hintText:SetText("Installer will reopen after you exit Edit Mode.")
                    OpenEditModeAndResume(frame)
                    return
                end

                SetStatus(frame, err or "Edit Mode import failed.", false)
            end
        end)

    -- Step 4: Details!
    elseif stage == 4 then
        frame.stepTitle:SetText("Details! Profile")
        frame.stepDesc:SetText("Click to import the Details! profile.")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("Apply Details!")
        if not Compat.IsAddOnLoaded("Details") then
            frame.actionBtn:Hide()
            frame.darkBtn:Hide()
            SetStatus(frame, "Details! not detected. Enable it to apply.", false)
            return
        end
        frame.actionBtn:Show()
        frame.darkBtn:Hide()
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)
        frame.actionBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end
            local ok, err = Profiles:ImportDetailsProfile()
            if ok then
                -- Track installed profile
                local profiles = GetGlobalState()
                if profiles then
                    profiles.details = true
                end

                state.stage = 5
                SetStatus(frame, "Details! profile imported.", true)
                Installer:UpdateStage()
            else
                SetStatus(frame, err or "Details! import failed.", false)
            end
        end)

    -- Step 5: Plater
    elseif stage == 5 then
        frame.stepTitle:SetText("Plater Profile")
        frame.stepDesc:SetText("Click to import the Plater profile.")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("Apply Plater")
        if not Compat.IsAddOnLoaded("Plater") then
            frame.actionBtn:Hide()
            frame.darkBtn:Hide()
            SetStatus(frame, "Plater not detected. Enable it to apply.", false)
            return
        end
        frame.actionBtn:Show()
        frame.darkBtn:Hide()
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)
        frame.actionBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end
            local ok, err = Profiles:ImportPlaterProfile()
            if ok then
                -- Track installed profile
                local profiles = GetGlobalState()
                if profiles then
                    profiles.plater = true
                end

                state.stage = 6
                SetStatus(frame, "Plater profile imported.", true)
                Installer:UpdateStage()
            else
                SetStatus(frame, err or "Plater import failed.", false)
            end
        end)

    -- Step 6: WarpDeplete
    elseif stage == 6 then
        frame.stepTitle:SetText("WarpDeplete Profile")
        frame.stepDesc:SetText("Click to import the WarpDeplete profile.\n(M+ timer addon)")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("Apply WarpDeplete")
        if not Compat.IsAddOnLoaded("WarpDeplete") then
            frame.actionBtn:Hide()
            frame.darkBtn:Hide()
            SetStatus(frame, "WarpDeplete not detected. Enable it to apply.", false)
            return
        end
        frame.actionBtn:Show()
        frame.darkBtn:Hide()
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)
        frame.actionBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end
            local ok, msg = Profiles:ImportWarpDepleteProfile()
            if ok then
                -- Track installed profile
                local profiles = GetGlobalState()
                if profiles then
                    profiles.warpdeplete = true
                end

                state.stage = 7
                SetStatus(frame, msg or "WarpDeplete profile imported. /reload for fonts.", true)
                Installer:UpdateStage()
            else
                SetStatus(frame, msg or "WarpDeplete import failed.", false)
            end
        end)

    -- Step 7: BigWigs
    elseif stage == 7 then
        frame.stepTitle:SetText("BigWigs Profile")
        frame.stepDesc:SetText("Click to import the BigWigs profile.\n(Boss mod addon)")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("Apply BigWigs")
        -- BigWigs is a Load-on-Demand addon - check if it's ENABLED (not loaded)
        -- GetAddOnEnableState returns: 0 = disabled for all, 1 = enabled for some, 2 = enabled for all
        local bigwigsEnabled = false
        if C_AddOns then
            -- Check if BigWigs addon exists and is enabled (doesn't need to be loaded)
            local name = C_AddOns.GetAddOnInfo("BigWigs")
            if name then
                local enableState = C_AddOns.GetAddOnEnableState("BigWigs")
                bigwigsEnabled = (enableState == 2) or (enableState == 1)
            end
        end
        -- Also check if it's already loaded (globals exist)
        bigwigsEnabled = bigwigsEnabled or _G.BigWigs or _G.BigWigsLoader or _G.BigWigs3DB
        if not bigwigsEnabled then
            frame.actionBtn:Hide()
            frame.darkBtn:Hide()
            SetStatus(frame, "BigWigs not detected. Enable it to apply.", false)
            return
        end
        frame.actionBtn:Show()
        frame.darkBtn:Hide()
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)
        frame.actionBtn:SetScript("OnClick", function()
            local Profiles = EdiUI.Profiles
            if not Profiles then
                SetStatus(frame, "Profiles module not loaded.", false)
                return
            end
            local ok, err = Profiles:ImportBigWigsProfile()
            if ok then
                -- Track installed profile
                local profiles = GetGlobalState()
                if profiles then
                    profiles.bigwigs = true
                end

                state.stage = 8
                SetStatus(frame, "BigWigs profile imported.", true)
                Installer:UpdateStage()
            else
                SetStatus(frame, err or "BigWigs import failed.", false)
            end
        end)

    -- Step 8: Complete
    else
        frame.stepTitle:SetText("Installation Complete!")
        frame.stepDesc:SetText("All profiles have been imported successfully.\nClick the button below to reload and apply all changes.")
        frame.hintText:SetText("")
        frame.actionBtn.text:SetText("Finish & Reload UI")
        frame.actionBtn:Show()
        frame.darkBtn:Hide()
        frame.actionBtn:ClearAllPoints()
        frame.actionBtn:SetPoint("BOTTOM", frame.progressBar, "TOP", 0, 10)
        frame.actionBtn:SetScript("OnClick", function()
            state.completed = true
            state.neverAutoOpen = true
            state.skipNextElvUIAutoOpen = true
            state.stage = MAX_STAGE
            local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI)
            if E and E.private and E.private.install_complete then
                state.lastElvUIInstall = E.private.install_complete
            end
            ReloadUI()
        end)
    end
end

function Installer:Reset()
    local state = EnsureState()
    if not state then
        return
    end
    state.stage = 1
    state.completed = false
    state.neverAutoOpen = false
    state.skipNextElvUIAutoOpen = false
    self:Show()
end

function Installer:Show()
    if not EdiUI.db or not EdiUI.db.profile then
        return
    end

    if not EdiUI.db.profile.installer then
        EdiUI.db.profile.installer = {
            stage = 1,
            completed = false,
            lastElvUIInstall = 0,
            neverAutoOpen = false,
            skipNextElvUIAutoOpen = false,
        }
    end

    local state = EnsureState()
    if not state then
        return
    end

    if not InstallerFrame then
        InstallerFrame = BuildFrame()
    end

    InstallerFrame:Show()
    self:UpdateStage()
end

function Installer:MaybeAutoOpen()
    if not EdiUI.db or not EdiUI.db.profile then
        return
    end

    if not EdiUI.db.profile.installer then
        EdiUI.db.profile.installer = {
            stage = 1,
            completed = false,
            lastElvUIInstall = 0,
            neverAutoOpen = false,
            skipNextElvUIAutoOpen = false,
        }
    end

    local state = EnsureState()
    if not state then
        return
    end

    local E = _G.ElvUI and (_G.ElvUI[1] or _G.ElvUI)
    if E and E.private and E.private.install_complete then
        local elvuiInstallVersion = E.private.install_complete
        local lastSeenVersion = state.lastElvUIInstall or 0

        if elvuiInstallVersion ~= lastSeenVersion then
            if state.skipNextElvUIAutoOpen then
                state.lastElvUIInstall = elvuiInstallVersion
                state.skipNextElvUIAutoOpen = false
                return
            end
            state.lastElvUIInstall = elvuiInstallVersion
            state.stage = 1
            state.completed = false
            state.neverAutoOpen = false
            self:Show()
            return
        end
    end

    if state.neverAutoOpen then
        return
    end

    if state.stage < MAX_STAGE and state.completed then
        state.completed = false
    end

    if state.completed then
        return
    end

    self:Show()
end
