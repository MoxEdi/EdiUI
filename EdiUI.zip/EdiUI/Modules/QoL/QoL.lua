-- EdiUI Quality of Life Module
-- Automation, Social, and System features
local EdiUI = EdiUI

local QoL = EdiUI:NewModule("QoL", "AceEvent-3.0", "AceHook-3.0")

-- Local references
local pairs, ipairs, type, tostring = pairs, ipairs, type, tostring
local GetNumFriends, C_FriendList = GetNumFriends, C_FriendList
local IsInGuild, GetGuildInfo, GetNumGuildMembers, GetGuildRosterInfo = IsInGuild, GetGuildInfo, GetNumGuildMembers, GetGuildRosterInfo
local UnitInBattleground, GetBattlefieldStatus = UnitInBattleground, GetBattlefieldStatus
local StaticPopup_Hide = StaticPopup_Hide
local RepairAllItems, CanMerchantRepair, CanGuildBankRepair = RepairAllItems, CanMerchantRepair, CanGuildBankRepair
local GetRepairAllCost, GetMoney = GetRepairAllCost, GetMoney
local GetContainerNumSlots, GetContainerItemInfo = C_Container.GetContainerNumSlots, C_Container.GetContainerItemInfo
local UseContainerItem = C_Container.UseContainerItem

-- State tracking
local lootDelay = 0
local isLooting = false

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================

local function GetDB()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.qol
end

-- Check if player is a friend (BattleTag, RealID, or character friend)
local function IsFriend(name)
    if not name then return false end

    -- Check character friends
    local numFriends = C_FriendList.GetNumFriends()
    for i = 1, numFriends do
        local info = C_FriendList.GetFriendInfoByIndex(i)
        if info and info.name and info.name:lower() == name:lower() then
            return true
        end
    end

    -- Check BattleTag friends
    local numBNetFriends = BNGetNumFriends()
    for i = 1, numBNetFriends do
        local accountInfo = C_BattleNet.GetFriendAccountInfo(i)
        if accountInfo then
            local gameAccountInfo = accountInfo.gameAccountInfo
            if gameAccountInfo and gameAccountInfo.characterName then
                if gameAccountInfo.characterName:lower() == name:lower() then
                    return true
                end
            end
        end
    end

    return false
end

-- Check if player is in guild
local function IsGuildMember(name)
    if not name or not IsInGuild() then return false end

    local numMembers = GetNumGuildMembers()
    for i = 1, numMembers do
        local guildName = GetGuildRosterInfo(i)
        if guildName then
            -- Remove realm from name if present
            local shortName = guildName:match("([^%-]+)")
            if shortName and shortName:lower() == name:lower() then
                return true
            end
        end
    end

    return false
end

-- Check if player is in a community
local function IsCommunityMember(name)
    if not name then return false end

    local clubs = C_Club.GetSubscribedClubs()
    if not clubs then return false end

    for _, club in ipairs(clubs) do
        if club.clubType == Enum.ClubType.Character then
            local members = C_Club.GetClubMembers(club.clubId)
            if members then
                for _, memberId in ipairs(members) do
                    local memberInfo = C_Club.GetMemberInfo(club.clubId, memberId)
                    if memberInfo and memberInfo.name then
                        local shortName = memberInfo.name:match("([^%-]+)")
                        if shortName and shortName:lower() == name:lower() then
                            return true
                        end
                    end
                end
            end
        end
    end

    return false
end

-- Check if player should be treated as a friend
local function IsTreatedAsFriend(name)
    local db = GetDB()
    if not db then return false end

    if IsFriend(name) then return true end
    if db.social.friendlyGuild and IsGuildMember(name) then return true end
    if db.social.friendlyCommunities and IsCommunityMember(name) then return true end

    return false
end

-- Get override key function
local function IsOverrideKeyDown(keyIndex)
    if keyIndex == 1 then return IsShiftKeyDown()
    elseif keyIndex == 2 then return IsAltKeyDown()
    elseif keyIndex == 3 then return IsControlKeyDown()
    end
    return false
end

-- ============================================================
-- AUTOMATION FEATURES
-- ============================================================

-- Quest Automation
function QoL:SetupQuestAutomation()
    local db = GetDB()
    if not db then return end

    -- Create quest automation frame if it doesn't exist
    if not self.questFrame then
        self.questFrame = CreateFrame("Frame")
        self.questFrame:SetScript("OnEvent", function(frame, event, arg1)
            local currentDb = GetDB()
            if not currentDb or not currentDb.automation.automateQuests then return end

            -- Clear progress items when quest interaction has ceased
            if event == "QUEST_FINISHED" then
                for i = 1, 6 do
                    local progItem = _G["QuestProgressItem" .. i]
                    if progItem and progItem:IsShown() then
                        progItem:Hide()
                    end
                end
                return
            end

            -- Check override key behavior
            local override = IsOverrideKeyDown(currentDb.automation.autoQuestKeyMenu)
            if currentDb.automation.autoQuestShift then
                if not override then return end
            else
                if override then return end
            end

            -- QUEST_DETAIL: Accept quests
            if event == "QUEST_DETAIL" then
                local isDaily = QuestIsDaily and QuestIsDaily()
                local isWeekly = QuestIsWeekly and QuestIsWeekly()
                local isRegular = not isDaily and not isWeekly

                if isRegular and not currentDb.automation.autoQuestRegular then return end
                if isDaily and not currentDb.automation.autoQuestDaily then return end
                if isWeekly and not currentDb.automation.autoQuestWeekly then return end

                if QuestGetAutoAccept and QuestGetAutoAccept() then
                    CloseQuest()
                else
                    AcceptQuest()
                end

            -- QUEST_ACCEPT_CONFIRM: Confirm escort quests etc
            elseif event == "QUEST_ACCEPT_CONFIRM" then
                if currentDb.automation.autoQuestRegular then
                    ConfirmAcceptQuest()
                    StaticPopup_Hide("QUEST_ACCEPT")
                end

            -- QUEST_PROGRESS: Continue to turn-in
            elseif event == "QUEST_PROGRESS" then
                if currentDb.automation.autoQuestCompleted and IsQuestCompletable() then
                    if QuestRequiresCurrency and QuestRequiresCurrency() then return end
                    if QuestRequiresGold and QuestRequiresGold() then return end
                    CompleteQuest()
                end

            -- QUEST_COMPLETE: Turn in quest
            elseif event == "QUEST_COMPLETE" then
                if currentDb.automation.autoQuestCompleted then
                    if QuestRequiresCurrency and QuestRequiresCurrency() then return end
                    if QuestRequiresGold and QuestRequiresGold() then return end
                    local numChoices = GetNumQuestChoices() or 0
                    if numChoices <= 1 then
                        GetQuestReward(numChoices)
                    end
                end

            -- QUEST_GREETING: Select quest from NPC with multiple quests
            elseif event == "QUEST_GREETING" then
                -- Select completed quests first
                if currentDb.automation.autoQuestCompleted then
                    for i = 1, GetNumActiveQuests() do
                        local title, isComplete = GetActiveTitle(i)
                        if title and isComplete then
                            SelectActiveQuest(i)
                            return
                        end
                    end
                end
                -- Then select available quests
                if currentDb.automation.autoQuestRegular or currentDb.automation.autoQuestDaily or currentDb.automation.autoQuestWeekly then
                    for i = 1, GetNumAvailableQuests() do
                        SelectAvailableQuest(i)
                        return
                    end
                end

            -- QUEST_AUTOCOMPLETE: Handle objective tracker auto-complete
            elseif event == "QUEST_AUTOCOMPLETE" then
                if currentDb.automation.autoQuestCompleted and arg1 and C_QuestLog then
                    local index = C_QuestLog.GetLogIndexForQuestID(arg1)
                    if index then
                        local info = C_QuestLog.GetInfo(index)
                        if info and info.isAutoComplete then
                            C_QuestLog.SetSelectedQuest(arg1)
                            if ShowQuestComplete then
                                ShowQuestComplete(C_QuestLog.GetSelectedQuest())
                            end
                        end
                    end
                end

            -- GOSSIP_SHOW: Select quest from gossip frame
            elseif event == "GOSSIP_SHOW" then
                if UnitExists("npc") then
                    -- Select completed quests
                    if currentDb.automation.autoQuestCompleted then
                        local quests = C_GossipInfo.GetActiveQuests()
                        for _, quest in ipairs(quests) do
                            if quest.isComplete then
                                C_GossipInfo.SelectActiveQuest(quest.questID)
                                return
                            end
                        end
                    end
                    -- Select available quests
                    if currentDb.automation.autoQuestRegular or currentDb.automation.autoQuestDaily or currentDb.automation.autoQuestWeekly then
                        local quests = C_GossipInfo.GetAvailableQuests()
                        for _, quest in ipairs(quests) do
                            local isDaily = quest.frequency == Enum.QuestFrequency.Daily
                            local isWeekly = quest.frequency == Enum.QuestFrequency.Weekly
                            local isRegular = not isDaily and not isWeekly
                            if (isRegular and currentDb.automation.autoQuestRegular) or
                               (isDaily and currentDb.automation.autoQuestDaily) or
                               (isWeekly and currentDb.automation.autoQuestWeekly) then
                                C_GossipInfo.SelectAvailableQuest(quest.questID)
                                return
                            end
                        end
                    end
                end
            end
        end)
    end

    -- Register/unregister events based on setting
    if db.automation.automateQuests then
        self.questFrame:RegisterEvent("QUEST_DETAIL")
        self.questFrame:RegisterEvent("QUEST_ACCEPT_CONFIRM")
        self.questFrame:RegisterEvent("QUEST_PROGRESS")
        self.questFrame:RegisterEvent("QUEST_COMPLETE")
        self.questFrame:RegisterEvent("QUEST_GREETING")
        self.questFrame:RegisterEvent("QUEST_AUTOCOMPLETE")
        self.questFrame:RegisterEvent("GOSSIP_SHOW")
        self.questFrame:RegisterEvent("QUEST_FINISHED")
    else
        self.questFrame:UnregisterAllEvents()
    end
end

-- Gossip Automation
function QoL:SetupGossipAutomation()
    self:RegisterEvent("GOSSIP_SHOW", "OnGossipShow")
end

function QoL:OnGossipShow()
    local db = GetDB()
    if not db or not db.automation.automateGossip then return end

    if not IsAltKeyDown() then return end

    local options = C_GossipInfo.GetOptions()
    if options and #options == 1 then
        C_GossipInfo.SelectOption(options[1].gossipOptionID)
    end
end

-- Summon Automation
function QoL:SetupSummonAutomation()
    self:RegisterEvent("CONFIRM_SUMMON", "OnConfirmSummon")
end

function QoL:OnConfirmSummon()
    local db = GetDB()
    if not db or not db.automation.autoAcceptSummon then return end

    if not InCombatLockdown() then
        C_SummonInfo.ConfirmSummon()
        StaticPopup_Hide("CONFIRM_SUMMON")
    end
end

-- Resurrection Automation
function QoL:SetupResAutomation()
    self:RegisterEvent("RESURRECT_REQUEST", "OnResurrectRequest")
end

function QoL:OnResurrectRequest(event, name)
    local db = GetDB()
    if not db or not db.automation.autoAcceptRes then return end

    -- Check combat exclusion
    if db.automation.autoResNoCombat then
        -- Can't easily check if the resurrecting player is in combat, so skip if we are
        if InCombatLockdown() then return end
    end

    AcceptResurrect()
    StaticPopup_Hide("RESURRECT_NO_TIMER")
    StaticPopup_Hide("RESURRECT_NO_SICKNESS")
    StaticPopup_Hide("RESURRECT")
end

-- PvP Release Automation
function QoL:SetupPvPRelease()
    self:RegisterEvent("PLAYER_DEAD", "OnPlayerDead")
end

function QoL:OnPlayerDead()
    local db = GetDB()
    if not db or not db.automation.autoReleasePvP then return end

    -- Check if in battleground or PvP zone
    local _, instanceType = GetInstanceInfo()
    if instanceType ~= "pvp" and instanceType ~= "arena" then
        -- Check for world PvP zones (Wintergrasp, Tol Barad, Ashran)
        local mapID = C_Map.GetBestMapForUnit("player")
        if not mapID then return end

        local mapInfo = C_Map.GetMapInfo(mapID)
        if not mapInfo then return end

        local mapName = mapInfo.name
        if mapName == "Wintergrasp" and db.automation.autoReleaseNoWintergrasp then return end
        if mapName == "Tol Barad" and db.automation.autoReleaseNoTolBarad then return end
        if mapName == "Ashran" and db.automation.autoReleaseNoAshran then return end

        -- Not in a valid PvP zone
        if mapName ~= "Wintergrasp" and mapName ~= "Tol Barad" and mapName ~= "Ashran" then
            return
        end
    end

    -- Check for Alterac Valley exclusion
    if instanceType == "pvp" then
        local _, _, _, _, _, _, _, mapId = GetInstanceInfo()
        if (mapId == 30 or mapId == 628) and db.automation.autoReleaseNoAlterac then
            return
        end
    end

    -- Check for self-res abilities
    if HasSoulstone() then return end

    -- Delay release
    local delay = db.automation.autoReleaseDelay / 1000
    C_Timer.After(delay, function()
        if UnitIsDead("player") and not IsShiftKeyDown() then
            RepopMe()
        end
    end)
end

-- Vendor Automation (Sell Junk & Repair)
function QoL:SetupVendorAutomation()
    self:RegisterEvent("MERCHANT_SHOW", "OnMerchantShow")
end

function QoL:OnMerchantShow()
    local db = GetDB()
    if not db then return end

    -- Skip if shift is held
    if IsShiftKeyDown() then return end

    -- Auto sell junk
    if db.automation.autoSellJunk then
        self:SellJunk()
    end

    -- Auto repair
    if db.automation.autoRepairGear then
        self:RepairGear()
    end
end

function QoL:SellJunk()
    local db = GetDB()
    if not db then return end

    local totalPrice = 0
    local itemsSold = 0

    -- Build exclusion list
    local excludeList = {}
    if db.automation.autoSellExcludeList and db.automation.autoSellExcludeList ~= "" then
        for id in db.automation.autoSellExcludeList:gmatch("(%d+)") do
            excludeList[tonumber(id)] = true
        end
    end

    for bag = 0, 4 do
        local numSlots = C_Container.GetContainerNumSlots(bag)
        for slot = 1, numSlots do
            local itemInfo = C_Container.GetContainerItemInfo(bag, slot)
            if itemInfo and itemInfo.quality == Enum.ItemQuality.Poor then
                local itemID = itemInfo.itemID
                if not excludeList[itemID] then
                    local _, _, _, _, _, _, _, _, _, _, itemPrice = GetItemInfo(itemID)
                    if itemPrice and itemPrice > 0 then
                        totalPrice = totalPrice + (itemPrice * itemInfo.stackCount)
                        itemsSold = itemsSold + 1
                        C_Container.UseContainerItem(bag, slot)
                    end
                end
            end
        end
    end

    if db.automation.autoSellShowSummary and itemsSold > 0 then
        print("|cff00ff00EdiUI:|r Sold " .. itemsSold .. " junk items for " .. GetCoinTextureString(totalPrice))
    end
end

function QoL:RepairGear()
    local db = GetDB()
    if not db then return end

    if not CanMerchantRepair() then return end

    local repairCost, canRepair = GetRepairAllCost()
    if not canRepair or repairCost == 0 then return end

    local guildRepair = false
    if db.automation.autoRepairGuildFunds and CanGuildBankRepair() then
        RepairAllItems(true)
        guildRepair = true
    else
        if GetMoney() >= repairCost then
            RepairAllItems(false)
        else
            print("|cffff0000EdiUI:|r Not enough gold to repair!")
            return
        end
    end

    if db.automation.autoRepairShowSummary then
        local source = guildRepair and " (Guild Funds)" or ""
        print("|cff00ff00EdiUI:|r Repaired all items for " .. GetCoinTextureString(repairCost) .. source)
    end
end

-- ============================================================
-- SOCIAL FEATURES
-- ============================================================

function QoL:SetupSocialFeatures()
    -- Block duels
    self:RegisterEvent("DUEL_REQUESTED", "OnDuelRequested")
    self:RegisterEvent("PET_BATTLE_PVP_DUEL_REQUESTED", "OnPetDuelRequested")

    -- Block party invites
    self:RegisterEvent("PARTY_INVITE_REQUEST", "OnPartyInviteRequest")

    -- Block friend requests
    self:RegisterEvent("BN_FRIEND_INVITE_ADDED", "OnFriendInviteAdded")

    -- Block shared quests
    self:RegisterEvent("QUEST_DETAIL", "OnQuestShared")

    -- Invite from whisper
    self:RegisterEvent("CHAT_MSG_WHISPER", "OnWhisperReceived")
    self:RegisterEvent("CHAT_MSG_BN_WHISPER", "OnBNWhisperReceived")
end

function QoL:OnDuelRequested(event, name)
    local db = GetDB()
    if not db or not db.social.noDuelRequests then return end

    if not IsTreatedAsFriend(name) then
        CancelDuel()
        StaticPopup_Hide("DUEL_REQUESTED")
    end
end

function QoL:OnPetDuelRequested(event, name)
    local db = GetDB()
    if not db or not db.social.noPetDuels then return end

    if not IsTreatedAsFriend(name) then
        C_PetBattles.CancelPVPDuel()
    end
end

function QoL:OnPartyInviteRequest(event, name)
    local db = GetDB()
    if not db then return end

    -- Block party invites from non-friends
    if db.social.noPartyInvites and not IsTreatedAsFriend(name) then
        DeclineGroup()
        StaticPopup_Hide("PARTY_INVITE")
        return
    end

    -- Auto-accept from friends
    if db.social.acceptPartyFriends and IsTreatedAsFriend(name) then
        AcceptGroup()
        StaticPopup_Hide("PARTY_INVITE")
    end
end

function QoL:OnFriendInviteAdded()
    local db = GetDB()
    if not db or not db.social.noFriendRequests then return end

    -- Decline all pending friend requests
    local numInvites = BNGetNumFriendInvites()
    for i = numInvites, 1, -1 do
        local inviteID = BNGetFriendInviteInfo(i)
        if inviteID then
            BNDeclineFriendInvite(inviteID)
        end
    end
end

function QoL:OnQuestShared()
    local db = GetDB()
    if not db or not db.social.noSharedQuests then return end

    -- Check if this is a shared quest
    local questStartItemID = GetQuestStartItemID()
    if questStartItemID then return end -- Not a shared quest

    local sharer = GetQuestSourceInfo()
    if sharer and not IsTreatedAsFriend(sharer) then
        DeclineQuest()
    end
end

function QoL:OnWhisperReceived(event, message, sender)
    local db = GetDB()
    if not db or not db.social.inviteFromWhisper then return end

    local keyword = db.social.inviteKeyword or "inv"
    if message:lower():match("^" .. keyword:lower() .. "$") then
        -- Check restrictions
        if db.social.inviteFriendsOnly and not IsTreatedAsFriend(sender) then
            return
        end

        -- Check if we can invite
        if IsInGroup() and not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then
            return
        end

        -- Send invite
        C_PartyInfo.InviteUnit(sender)
    end
end

function QoL:OnBNWhisperReceived(event, message, sender, _, _, _, _, _, _, _, _, _, _, presenceID)
    local db = GetDB()
    if not db or not db.social.inviteFromWhisper then return end

    local keyword = db.social.inviteKeyword or "inv"
    if message:lower():match("^" .. keyword:lower() .. "$") then
        -- Get character name from BNet
        local accountInfo = C_BattleNet.GetAccountInfoByID(presenceID)
        if accountInfo and accountInfo.gameAccountInfo and accountInfo.gameAccountInfo.characterName then
            local charName = accountInfo.gameAccountInfo.characterName
            local realmName = accountInfo.gameAccountInfo.realmName

            -- Check restrictions
            if db.social.inviteFriendsOnly and not IsTreatedAsFriend(charName) then
                return
            end

            -- Check if we can invite
            if IsInGroup() and not UnitIsGroupLeader("player") and not UnitIsGroupAssistant("player") then
                return
            end

            -- Send invite
            if realmName then
                C_PartyInfo.InviteUnit(charName .. "-" .. realmName)
            else
                C_PartyInfo.InviteUnit(charName)
            end
        end
    end
end

-- ============================================================
-- SYSTEM FEATURES
-- ============================================================

function QoL:SetupSystemFeatures()
    local db = GetDB()
    if not db then return end

    -- Screen effects
    self:ApplyScreenEffects()

    -- Camera zoom
    self:ApplyCameraZoom()

    -- Faster looting
    self:SetupFasterLooting()

    -- Combat plates
    self:SetupCombatPlates()

    -- Movie skip
    self:SetupMovieSkip()

    -- Bag automation
    self:SetupBagAutomation()

    -- Loot warnings
    self:SetupLootWarnings()

    -- Easy item destroy
    self:SetupEasyDestroy()
end

function QoL:ApplyScreenEffects()
    local db = GetDB()
    if not db then return end

    -- Screen glow
    if db.system.noScreenGlow then
        SetCVar("ffxGlow", "0")
    end

    -- Screen effects (death effect)
    if db.system.noScreenEffects then
        SetCVar("ffxDeath", "0")
    end

    -- Weather density
    if db.system.setWeatherDensity then
        SetCVar("weatherDensity", tostring(db.system.weatherLevel))
    end
end

function QoL:ApplyCameraZoom()
    local db = GetDB()
    if not db then return end

    if db.system.maxCameraZoom then
        SetCVar("cameraDistanceMaxZoomFactor", "2.6")
    else
        SetCVar("cameraDistanceMaxZoomFactor", "1.9")
    end
end

function QoL:SetupFasterLooting()
    local db = GetDB()
    if not db or not db.system.fasterLooting then return end

    -- Faster looting with delay tracking
    if not self.fasterLootFrame then
        local tDelay = 0
        self.fasterLootFrame = CreateFrame("Frame")
        self.fasterLootFrame:RegisterEvent("LOOT_READY")
        self.fasterLootFrame:SetScript("OnEvent", function()
            local currentDb = GetDB()
            if not currentDb or not currentDb.system.fasterLooting then return end

            local delay = currentDb.system.fasterLootDelay or 0.3
            if GetTime() - tDelay >= delay then
                tDelay = GetTime()
                if GetCVarBool("autoLootDefault") ~= IsModifiedClick("AUTOLOOTTOGGLE") then
                    for i = GetNumLootItems(), 1, -1 do
                        LootSlot(i)
                    end
                    tDelay = GetTime()
                end
            end
        end)
    end
end

function QoL:OnLootReady()
    -- Deprecated: now handled by fasterLootFrame
end

function QoL:SetupCombatPlates()
    local db = GetDB()
    if not db or not db.system.combatPlates then return end

    self:RegisterEvent("PLAYER_REGEN_DISABLED", "OnCombatStart")
    self:RegisterEvent("PLAYER_REGEN_ENABLED", "OnCombatEnd")
end

function QoL:OnCombatStart()
    local db = GetDB()
    if not db or not db.system.combatPlates then return end

    SetCVar("nameplateShowEnemies", "1")
end

function QoL:OnCombatEnd()
    local db = GetDB()
    if not db or not db.system.combatPlates then return end

    SetCVar("nameplateShowEnemies", "0")
end

function QoL:SetupMovieSkip()
    local db = GetDB()
    if not db or not db.system.fasterMovieSkip then return end

    if self.movieSkipHooked then return end

    -- Click confirm buttons on key release
    if CinematicFrame then
        -- Hide close dialog on escape press
        CinematicFrame:HookScript("OnKeyDown", function(self, key)
            local currentDb = GetDB()
            if not currentDb or not currentDb.system.fasterMovieSkip then return end
            if key == "ESCAPE" then
                if CinematicFrame:IsShown() and CinematicFrame.closeDialog and CinematicFrameCloseDialogConfirmButton then
                    CinematicFrameCloseDialog:Hide()
                end
            end
        end)
        -- Skip cinematic on key release
        CinematicFrame:HookScript("OnKeyUp", function(self, key)
            local currentDb = GetDB()
            if not currentDb or not currentDb.system.fasterMovieSkip then return end
            if key == "SPACE" or key == "ESCAPE" or key == "ENTER" then
                if CinematicFrame:IsShown() and CinematicFrame.closeDialog and CinematicFrameCloseDialogConfirmButton then
                    CinematicFrameCloseDialogConfirmButton:Click()
                end
            end
        end)
    end

    if MovieFrame then
        -- Skip movie on key release
        MovieFrame:HookScript("OnKeyUp", function(self, key)
            local currentDb = GetDB()
            if not currentDb or not currentDb.system.fasterMovieSkip then return end
            if key == "SPACE" or key == "ESCAPE" or key == "ENTER" then
                if MovieFrame:IsShown() and MovieFrame.CloseDialog and MovieFrame.CloseDialog.ConfirmButton then
                    MovieFrame.CloseDialog.ConfirmButton:Click()
                end
            end
        end)
    end

    self.movieSkipHooked = true
end

function QoL:SetupBagAutomation()
    local db = GetDB()
    if not db or not db.system.noBagAutomation then return end

    -- Hook OpenAllBags to close them immediately
    if not self.bagAutomationHooked then
        hooksecurefunc("OpenAllBags", CloseAllBags)
        self.bagAutomationHooked = true
    end
end

function QoL:SetupLootWarnings()
    local db = GetDB()
    if not db or not db.system.noConfirmLoot then return end

    -- Hook loot roll confirmation
    self:RegisterEvent("CONFIRM_LOOT_ROLL", "OnConfirmLootRoll")
    self:RegisterEvent("CONFIRM_DISENCHANT_ROLL", "OnConfirmLootRoll")
end

function QoL:OnConfirmLootRoll(event, rollID, rollType)
    local db = GetDB()
    if not db or not db.system.noConfirmLoot then return end

    ConfirmLootRoll(rollID, rollType)
    StaticPopup_Hide("CONFIRM_LOOT_ROLL")
end

function QoL:SetupEasyDestroy()
    local db = GetDB()
    if not db or not db.system.easyItemDestroy then return end

    -- Listen for DELETE_ITEM_CONFIRM event
    if not self.easyDestroyFrame then
        self.easyDestroyFrame = CreateFrame("Frame")
        self.easyDestroyFrame:RegisterEvent("DELETE_ITEM_CONFIRM")
        self.easyDestroyFrame:SetScript("OnEvent", function()
            local currentDb = GetDB()
            if not currentDb or not currentDb.system.easyItemDestroy then return end

            -- Find the visible edit box and hide it, enable the button
            local editBox = StaticPopup1EditBox
            if editBox and editBox:IsShown() then
                editBox:Hide()
                StaticPopup1Button1:Enable()

                -- Show item link in the text
                local link = select(3, GetCursorInfo())
                if link then
                    StaticPopup1Text:SetText(CONFIRM_DESTROY_ITEM_POPUP:format(link))
                end
            end
        end)
    end
end

-- ============================================================
-- MODULE LIFECYCLE
-- ============================================================

function QoL:OnInitialize()
    -- Module initialization
end

function QoL:OnEnable()
    -- Wait for DB to be ready
    C_Timer.After(0.5, function()
        self:ApplySettings()
    end)
end

function QoL:OnDisable()
    self:UnregisterAllEvents()
end

function QoL:ApplySettings()
    local db = GetDB()
    if not db then return end

    -- Unregister all events first to reset
    self:UnregisterAllEvents()

    -- Setup automation features
    self:SetupQuestAutomation()
    self:SetupGossipAutomation()
    self:SetupSummonAutomation()
    self:SetupResAutomation()
    self:SetupPvPRelease()
    self:SetupVendorAutomation()

    -- Setup social features
    self:SetupSocialFeatures()

    -- Setup system features
    self:SetupSystemFeatures()
end
