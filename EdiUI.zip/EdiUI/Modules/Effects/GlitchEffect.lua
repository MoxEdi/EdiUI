-- EdiUI Glitch Effect
-- Cyberpunk-style glitch/distortion effect for textures
local EdiUI = EdiUI

local GlitchEffect = {}
EdiUI.GlitchEffect = GlitchEffect

-- Create glitch effect on a logo frame
function GlitchEffect:Apply(logoFrame, settings)
    if not logoFrame or not logoFrame.texture then return end

    settings = settings or {}
    local intensity = settings.intensity or 0.7
    local frequency = settings.frequency or 0.35

    local mainTexture = logoFrame.texture
    local texturePath = mainTexture:GetTexture() or "Interface\\AddOns\\EdiUI\\Media\\Logo\\logo.tga"

    -- Store original position
    logoFrame.glitchOrigX = 0
    logoFrame.glitchOrigY = 0

    -- Create RGB split textures - anchor to main texture so they match exactly
    -- Red channel (offset left) - behind main texture
    local redLayer = logoFrame:CreateTexture(nil, "ARTWORK", nil, 1)
    redLayer:SetTexture(texturePath)
    redLayer:SetAllPoints(mainTexture)
    redLayer:SetVertexColor(1, 0, 0)
    redLayer:SetAlpha(0)
    redLayer:SetBlendMode("ADD")
    logoFrame.glitchRed = redLayer

    -- Blue/Cyan channel (offset right) - behind main texture
    local blueLayer = logoFrame:CreateTexture(nil, "ARTWORK", nil, 2)
    blueLayer:SetTexture(texturePath)
    blueLayer:SetAllPoints(mainTexture)
    blueLayer:SetVertexColor(0, 0.7, 1)
    blueLayer:SetAlpha(0)
    blueLayer:SetBlendMode("ADD")
    logoFrame.glitchBlue = blueLayer

    -- Green channel for extra distortion
    local greenLayer = logoFrame:CreateTexture(nil, "ARTWORK", nil, 0)
    greenLayer:SetTexture(texturePath)
    greenLayer:SetAllPoints(mainTexture)
    greenLayer:SetVertexColor(0, 1, 0.3)
    greenLayer:SetAlpha(0)
    greenLayer:SetBlendMode("ADD")
    logoFrame.glitchGreen = greenLayer

    -- Ensure main texture is on top
    mainTexture:SetDrawLayer("ARTWORK", 3)

    -- Store the frame size for offset calculations
    local frameWidth = logoFrame:GetWidth()
    local frameHeight = logoFrame:GetHeight()

    -- Glitch state
    logoFrame.glitchIntensity = intensity
    logoFrame.glitchFrequency = frequency
    logoFrame.glitchActive = false
    logoFrame.glitchTimer = 0
    logoFrame.glitchDuration = 0
    logoFrame.nextGlitch = math.random() * 1 + 0.2
    logoFrame.microGlitchTimer = 0
    logoFrame.glitchType = 1

    -- Main update function
    logoFrame:SetScript("OnUpdate", function(self, elapsed)
        self.glitchTimer = self.glitchTimer + elapsed
        self.microGlitchTimer = self.microGlitchTimer + elapsed

        -- Check if we should start a glitch
        if not self.glitchActive and self.glitchTimer >= self.nextGlitch then
            self.glitchActive = true
            self.glitchDuration = math.random() * 0.15 + 0.05  -- 0.05-0.20 seconds
            self.glitchTimer = 0
            self.glitchType = math.random(1, 4)  -- Random glitch type
        end

        -- Process active glitch
        if self.glitchActive then
            local i = self.glitchIntensity

            -- Different glitch types for variety
            if self.glitchType == 1 then
                -- Heavy RGB chromatic aberration
                local offsetX = (math.random() - 0.5) * 12 * i
                local offsetY = (math.random() - 0.5) * 4 * i

                self.glitchRed:ClearAllPoints()
                self.glitchRed:SetPoint("TOPLEFT", self.texture, "TOPLEFT", -offsetX * 1.2, offsetY)
                self.glitchRed:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", -offsetX * 1.2, offsetY)
                self.glitchRed:SetAlpha(0.6 * i)

                self.glitchBlue:ClearAllPoints()
                self.glitchBlue:SetPoint("TOPLEFT", self.texture, "TOPLEFT", offsetX, -offsetY * 1.5)
                self.glitchBlue:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", offsetX, -offsetY * 1.5)
                self.glitchBlue:SetAlpha(0.6 * i)

                self.glitchGreen:ClearAllPoints()
                self.glitchGreen:SetPoint("TOPLEFT", self.texture, "TOPLEFT", offsetY, offsetX * 0.5)
                self.glitchGreen:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", offsetY, offsetX * 0.5)
                self.glitchGreen:SetAlpha(0.3 * i)

            elseif self.glitchType == 2 then
                -- Horizontal slice displacement
                local sliceOffset = (math.random() - 0.5) * 20 * i
                self.texture:ClearAllPoints()
                self.texture:SetPoint("TOPLEFT", self, "TOPLEFT", sliceOffset, 0)
                self.texture:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", sliceOffset, 0)

                -- Strong red/blue split
                self.glitchRed:ClearAllPoints()
                self.glitchRed:SetPoint("TOPLEFT", self.texture, "TOPLEFT", -8 * i, 2 * i)
                self.glitchRed:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", -8 * i, 2 * i)
                self.glitchRed:SetAlpha(0.7 * i)

                self.glitchBlue:ClearAllPoints()
                self.glitchBlue:SetPoint("TOPLEFT", self.texture, "TOPLEFT", 8 * i, -2 * i)
                self.glitchBlue:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", 8 * i, -2 * i)
                self.glitchBlue:SetAlpha(0.7 * i)

                self.glitchGreen:SetAlpha(0)

            elseif self.glitchType == 3 then
                -- Rapid shake/jitter
                local shakeX = (math.random() - 0.5) * 8 * i
                local shakeY = (math.random() - 0.5) * 6 * i
                self.texture:ClearAllPoints()
                self.texture:SetPoint("TOPLEFT", self, "TOPLEFT", shakeX, shakeY)
                self.texture:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", shakeX, shakeY)

                -- Flicker alpha rapidly
                self.texture:SetAlpha(0.4 + math.random() * 0.6)

                -- Subtle RGB
                self.glitchRed:ClearAllPoints()
                self.glitchRed:SetPoint("TOPLEFT", self.texture, "TOPLEFT", -3 * i, 0)
                self.glitchRed:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", -3 * i, 0)
                self.glitchRed:SetAlpha(0.4 * i)

                self.glitchBlue:ClearAllPoints()
                self.glitchBlue:SetPoint("TOPLEFT", self.texture, "TOPLEFT", 3 * i, 0)
                self.glitchBlue:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", 3 * i, 0)
                self.glitchBlue:SetAlpha(0.4 * i)

                self.glitchGreen:SetAlpha(0)

            else
                -- Full distortion - all channels wild
                local rx = (math.random() - 0.5) * 15 * i
                local ry = (math.random() - 0.5) * 8 * i
                local bx = (math.random() - 0.5) * 15 * i
                local by = (math.random() - 0.5) * 8 * i
                local gx = (math.random() - 0.5) * 10 * i
                local gy = (math.random() - 0.5) * 5 * i

                self.glitchRed:ClearAllPoints()
                self.glitchRed:SetPoint("TOPLEFT", self.texture, "TOPLEFT", rx, ry)
                self.glitchRed:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", rx, ry)
                self.glitchRed:SetAlpha(0.8 * i)

                self.glitchBlue:ClearAllPoints()
                self.glitchBlue:SetPoint("TOPLEFT", self.texture, "TOPLEFT", bx, by)
                self.glitchBlue:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", bx, by)
                self.glitchBlue:SetAlpha(0.8 * i)

                self.glitchGreen:ClearAllPoints()
                self.glitchGreen:SetPoint("TOPLEFT", self.texture, "TOPLEFT", gx, gy)
                self.glitchGreen:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", gx, gy)
                self.glitchGreen:SetAlpha(0.5 * i)

                -- Position shake
                local shakeX = (math.random() - 0.5) * 6 * i
                local shakeY = (math.random() - 0.5) * 4 * i
                self.texture:ClearAllPoints()
                self.texture:SetPoint("TOPLEFT", self, "TOPLEFT", shakeX, shakeY)
                self.texture:SetPoint("BOTTOMRIGHT", self, "BOTTOMRIGHT", shakeX, shakeY)

                -- Aggressive alpha flicker
                if math.random() > 0.4 then
                    self.texture:SetAlpha(0.5 + math.random() * 0.5)
                end
            end

            -- Check if glitch should end
            if self.glitchTimer >= self.glitchDuration then
                self.glitchActive = false
                self.glitchTimer = 0
                -- Shorter intervals between glitches for more frequency
                self.nextGlitch = (1 - self.glitchFrequency) * 1.5 + math.random() * 1

                -- Reset positions
                self.texture:ClearAllPoints()
                self.texture:SetAllPoints(self)
                self.texture:SetAlpha(1)

                self.glitchRed:ClearAllPoints()
                self.glitchRed:SetAllPoints(self.texture)
                self.glitchRed:SetAlpha(0)

                self.glitchBlue:ClearAllPoints()
                self.glitchBlue:SetAllPoints(self.texture)
                self.glitchBlue:SetAlpha(0)

                self.glitchGreen:ClearAllPoints()
                self.glitchGreen:SetAllPoints(self.texture)
                self.glitchGreen:SetAlpha(0)
            end
        else
            -- More frequent idle micro-glitches
            if self.microGlitchTimer > 0.06 then
                self.microGlitchTimer = 0

                -- 15% chance of micro glitch (was 8%)
                if math.random() > 0.85 then
                    -- Quick micro RGB split with more intensity
                    local microOffset = 2 + math.random() * 2

                    self.glitchRed:ClearAllPoints()
                    self.glitchRed:SetPoint("TOPLEFT", self.texture, "TOPLEFT", -microOffset, math.random() - 0.5)
                    self.glitchRed:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", -microOffset, math.random() - 0.5)
                    self.glitchRed:SetAlpha(0.35)

                    self.glitchBlue:ClearAllPoints()
                    self.glitchBlue:SetPoint("TOPLEFT", self.texture, "TOPLEFT", microOffset, math.random() - 0.5)
                    self.glitchBlue:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", microOffset, math.random() - 0.5)
                    self.glitchBlue:SetAlpha(0.35)

                    -- Occasional green micro-glitch
                    if math.random() > 0.7 then
                        self.glitchGreen:ClearAllPoints()
                        self.glitchGreen:SetPoint("TOPLEFT", self.texture, "TOPLEFT", 0, microOffset * 0.5)
                        self.glitchGreen:SetPoint("BOTTOMRIGHT", self.texture, "BOTTOMRIGHT", 0, microOffset * 0.5)
                        self.glitchGreen:SetAlpha(0.2)
                    end

                    -- Reset after brief moment
                    C_Timer.After(0.04, function()
                        if self.glitchRed and not self.glitchActive then
                            self.glitchRed:ClearAllPoints()
                            self.glitchRed:SetAllPoints(self.texture)
                            self.glitchRed:SetAlpha(0)

                            self.glitchBlue:ClearAllPoints()
                            self.glitchBlue:SetAllPoints(self.texture)
                            self.glitchBlue:SetAlpha(0)

                            self.glitchGreen:ClearAllPoints()
                            self.glitchGreen:SetAllPoints(self.texture)
                            self.glitchGreen:SetAlpha(0)
                        end
                    end)
                end

                -- Additional: random subtle flicker (5% chance)
                if math.random() > 0.95 then
                    self.texture:SetAlpha(0.85)
                    C_Timer.After(0.03, function()
                        if self.texture and not self.glitchActive then
                            self.texture:SetAlpha(1)
                        end
                    end)
                end
            end
        end
    end)

    -- Stop function
    function logoFrame:StopGlitch()
        self:SetScript("OnUpdate", nil)
        self.texture:ClearAllPoints()
        self.texture:SetAllPoints(self)
        self.texture:SetAlpha(1)
        if self.glitchRed then
            self.glitchRed:ClearAllPoints()
            self.glitchRed:SetAllPoints(self.texture)
            self.glitchRed:SetAlpha(0)
        end
        if self.glitchBlue then
            self.glitchBlue:ClearAllPoints()
            self.glitchBlue:SetAllPoints(self.texture)
            self.glitchBlue:SetAlpha(0)
        end
        if self.glitchGreen then
            self.glitchGreen:ClearAllPoints()
            self.glitchGreen:SetAllPoints(self.texture)
            self.glitchGreen:SetAlpha(0)
        end
    end

    return logoFrame
end

-- Preset configurations
GlitchEffect.Presets = {
    subtle = {
        intensity = 0.4,
        frequency = 0.15,
    },
    medium = {
        intensity = 0.6,
        frequency = 0.25,
    },
    intense = {
        intensity = 0.9,
        frequency = 0.4,
    },
    cyberpunk = {
        intensity = 0.75,
        frequency = 0.35,
    },
    heavy = {
        intensity = 1.0,
        frequency = 0.5,
    },
}
