-- EdiUI Dungeon Portal Data
-- Ported from M+ Dungeon Teleports by peepoStudy
local EdiUI = EdiUI

EdiUI.DungeonPortalData = {}
local Data = EdiUI.DungeonPortalData

-- Faction-specific spell IDs
local factionGroup = UnitFactionGroup("player")
local siegeID = factionGroup == "Horde" and 464256 or 445418
local motherID = factionGroup == "Horde" and 467555 or 467553

-- Expansion definitions with dungeon data
Data.Expansions = {
    {
        key = "MID",
        title = "Midnight",
        dungeons = {
            {icon = "Interface\\Icons\\inv_achievement_dungeon_proveyourworth", spellID = 11, name = "DON", fullname = "Den of Nalorakk"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_magistersterrace", spellID = 1254572, name = "MT", fullname = "Magisters' Terrace"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_maisarahills", spellID = 1254559, name = "MC", fullname = "Maisara Caverns"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_murderrow", spellID = 4, name = "MR", fullname = "Murder Row"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_nexuspointxenas", spellID = 1254563, name = "NPX", fullname = "Nexus-Point Xenas"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_lightbloom", spellID = 3, name = "BV", fullname = "The Blinding Vale"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_voidscararena", spellID = 1, name = "VA", fullname = "Voidscar Arena"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_windrunnerspire", spellID = 1254400, name = "WS", fullname = "Windrunner Spire"},
        }
    },
    {
        key = "TWW",
        title = "The War Within",
        dungeons = {
            {icon = "Interface\\Icons\\inv_achievement_dungeon_arak-ara", spellID = 445417, name = "ARAK", fullname = "Ara-Kara, City of Echoes"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_cinderbrewmeadery", spellID = 445440, name = "BREW", fullname = "Cinderbrew Meadery"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_cityofthreads", spellID = 445416, name = "COT", fullname = "City of Threads"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_darkflamecleft", spellID = 445441, name = "DFC", fullname = "Darkflame Cleft"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_dawnbreaker", spellID = 445414, name = "DAWN", fullname = "The Dawnbreaker"},
            {icon = "Interface\\Icons\\inv_112_achievement_dungeon_ecodome", spellID = 1237215, name = "EDA", fullname = "Eco-Dome Aldani"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_waterworks", spellID = 1216786, name = "FLOOD", fullname = "Operation: Floodgate"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_prioryofthesacredflame", spellID = 445444, name = "PSF", fullname = "Priory of the Sacred Flame"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_rookery", spellID = 445443, name = "ROOK", fullname = "The Rookery"},
            {icon = "Interface\\Icons\\inv_achievement_dungeon_stonevault", spellID = 445269, name = "SV", fullname = "The Stonevault"},
        }
    },
    {
        key = "DF",
        title = "Dragonflight",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_dragonacademy", spellID = 393273, name = "AA", fullname = "Algeth'ar Academy"},
            {icon = "Interface\\Icons\\achievement_dungeon_arcanevaults", spellID = 393279, name = "AV", fullname = "The Azure Vault"},
            {icon = "Interface\\Icons\\achievement_dungeon_brackenhidehollow", spellID = 393267, name = "BH", fullname = "Brackenhide Hollow"},
            {icon = "Interface\\Icons\\achievement_dungeon_dawnoftheinfinite", spellID = 424197, name = "DOTI", fullname = "Dawn of the Infinite"},
            {icon = "Interface\\Icons\\achievement_dungeon_hallsofinfusion", spellID = 393283, name = "HOI", fullname = "Halls of Infusion"},
            {icon = "Interface\\Icons\\achievement_dungeon_neltharus", spellID = 393276, name = "NELTH", fullname = "Neltharus"},
            {icon = "Interface\\Icons\\achievement_dungeon_centaurplains", spellID = 393262, name = "NO", fullname = "The Nokud Offensive"},
            {icon = "Interface\\Icons\\achievement_dungeon_lifepools", spellID = 393256, name = "RLP", fullname = "Ruby Life Pools"},
            {icon = "Interface\\Icons\\achievement_dungeon_uldaman", spellID = 393222, name = "ULD", fullname = "Uldaman: Legacy of Tyr"},
        }
    },
    {
        key = "SL",
        title = "Shadowlands",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_theotherside", spellID = 354468, name = "DOS", fullname = "De Other Side"},
            {icon = "Interface\\Icons\\achievement_dungeon_hallsofattonement", spellID = 354465, name = "HOA", fullname = "Halls of Atonement"},
            {icon = "Interface\\Icons\\achievement_dungeon_mistsoftirnascithe", spellID = 354464, name = "MISTS", fullname = "Mists of Tirna Scithe"},
            {icon = "Interface\\Icons\\achievement_dungeon_theneroticwake", spellID = 354462, name = "NW", fullname = "The Necrotic Wake"},
            {icon = "Interface\\Icons\\achievement_dungeon_plaguefall", spellID = 354463, name = "PF", fullname = "Plaguefall"},
            {icon = "Interface\\Icons\\achievement_dungeon_sanguinedepths", spellID = 354469, name = "SD", fullname = "Sanguine Depths"},
            {icon = "Interface\\Icons\\achievement_dungeon_spireofascension", spellID = 354466, name = "SOA", fullname = "Spires of Ascension"},
            {icon = "Interface\\Icons\\achievement_dungeon_brokerdungeon", spellID = 367416, name = "TAZ", fullname = "Tazavesh"},
            {icon = "Interface\\Icons\\achievement_dungeon_theatreofpain", spellID = 354467, name = "TOP", fullname = "Theatre of Pain"},
        }
    },
    {
        key = "BFA",
        title = "Battle for Azeroth",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_ataldazar", spellID = 424187, name = "AD", fullname = "Atal'Dazar"},
            {icon = "Interface\\Icons\\achievement_dungeon_freehold", spellID = 410071, name = "FH", fullname = "Freehold"},
            {icon = "Interface\\Icons\\achievement_boss_mechagon", spellID = 373274, name = "MECHA", fullname = "Operation: Mechagon"},
            {icon = "Interface\\Icons\\achievement_dungeon_kezan", spellID = motherID, name = "ML", fullname = "The MOTHERLODE!!"},
            {icon = "Interface\\Icons\\achievement_dungeon_siegeofboralus", spellID = siegeID, name = "SIEGE", fullname = "Siege of Boralus"},
            {icon = "Interface\\Icons\\achievement_dungeon_underrot", spellID = 410074, name = "UNDR", fullname = "The Underrot"},
            {icon = "Interface\\Icons\\achievement_dungeon_waycrestmannor", spellID = 424167, name = "WM", fullname = "Waycrest Manor"},
        }
    },
    {
        key = "Legion",
        title = "Legion",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_blackrookhold", spellID = 424153, name = "BRH", fullname = "Black Rook Hold"},
            {icon = "Interface\\Icons\\achievement_dungeon_courtofstars", spellID = 393766, name = "COS", fullname = "Court of Stars"},
            {icon = "Interface\\Icons\\achievement_dungeon_darkheartthicket", spellID = 424163, name = "DT", fullname = "Darkheart Thicket"},
            {icon = "Interface\\Icons\\achievement_dungeon_hallsofvalor", spellID = 393764, name = "HOV", fullname = "Halls of Valor"},
            {icon = "Interface\\Icons\\achievement_raid_karazhan", spellID = 373262, name = "KARA", fullname = "Karazhan"},
            {icon = "Interface\\Icons\\achievement_dungeon_neltharionslair", spellID = 410078, name = "NL", fullname = "Neltharion's Lair"},
            {icon = "Interface\\Icons\\achievement_dungeon_argusdungeon", spellID = 1254551, name = "SOTT", fullname = "Seat of the Triumvirate"},
        }
    },
    {
        key = "WOD",
        title = "Warlords of Draenor",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_auchindoun", spellID = 159897, name = "AUCH", fullname = "Auchindoun"},
            {icon = "Interface\\Icons\\achievement_dungeon_ogreslagmines", spellID = 159895, name = "BSM", fullname = "Bloodmaul Slag Mines"},
            {icon = "Interface\\Icons\\achievement_dungeon_everbloom", spellID = 159901, name = "EB", fullname = "The Everbloom"},
            {icon = "Interface\\Icons\\achievement_dungeon_blackrockdepot", spellID = 159900, name = "GD", fullname = "Grimrail Depot"},
            {icon = "Interface\\Icons\\achievement_dungeon_blackrockdocks", spellID = 159896, name = "ID", fullname = "Iron Docks"},
            {icon = "Interface\\Icons\\achievement_dungeon_shadowmoonhideout", spellID = 159899, name = "SBG", fullname = "Shadowmoon Burial Grounds"},
            {icon = "Interface\\Icons\\achievement_dungeon_arakkoaspires", spellID = 159898, name = "SR", fullname = "Skyreach"},
            {icon = "Interface\\Icons\\achievement_dungeon_upperblackrockspire", spellID = 159902, name = "UBRS", fullname = "Upper Blackrock Spire"},
        }
    },
    {
        key = "MOP",
        title = "Mists of Pandaria",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_greatwall", spellID = 131225, name = "GOTSS", fullname = "Gate of the Setting Sun"},
            {icon = "Interface\\Icons\\achievement_dungeon_mogupalace", spellID = 131222, name = "MSP", fullname = "Mogu'shan Palace"},
            {icon = "Interface\\Icons\\spell_holy_senseundead", spellID = 131232, name = "SCHOLO", fullname = "Scholomance"},
            {icon = "Interface\\Icons\\inv_helmet_52", spellID = 131231, name = "SH", fullname = "Scarlet Halls"},
            {icon = "Interface\\Icons\\spell_holy_resurrection", spellID = 131229, name = "SM", fullname = "Scarlet Monastery"},
            {icon = "Interface\\Icons\\achievement_dungeon_siegeofniuzaotemple", spellID = 131228, name = "SNT", fullname = "Siege of Niuzao Temple"},
            {icon = "Interface\\Icons\\achievement_shadowpan_hideout", spellID = 131206, name = "SPM", fullname = "Shado-Pan Monastery"},
            {icon = "Interface\\Icons\\achievement_brewery", spellID = 131205, name = "SSB", fullname = "Stormstout Brewery"},
            {icon = "Interface\\Icons\\achievement_jadeserpent", spellID = 131204, name = "TJS", fullname = "Temple of the Jade Serpent"},
        }
    },
    {
        key = "CATA",
        title = "Cataclysm",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_grimbatol", spellID = 445424, name = "GB", fullname = "Grim Batol"},
            {icon = "Interface\\Icons\\achievement_dungeon_throne of the tides", spellID = 424142, name = "TOTT", fullname = "Throne of the Tides"},
            {icon = "Interface\\Icons\\achievement_dungeon_skywall", spellID = 410080, name = "VP", fullname = "The Vortex Pinnacle"},
        }
    },
    {
        key = "WRATH",
        title = "Wrath of the Lich King",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_dungeon_icecrown_pitofsaron", spellID = 1254555, name = "POS", fullname = "Pit of Saron"},
        }
    },
}

-- Raid portals
Data.Raids = {
    {
        key = "TWW_RAIDS",
        title = "The War Within Raids",
        dungeons = {
            {icon = "Interface\\Icons\\inv_achievement_zone_undermine", spellID = 1226482, name = "LOU", fullname = "Liberation of Undermine"},
            {icon = "Interface\\Icons\\inv_112_achievement_raid_manaforgeomega", spellID = 1239155, name = "MFO", fullname = "Manaforge Omega"},
        }
    },
    {
        key = "DF_RAIDS",
        title = "Dragonflight Raids",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_raidprimalist_raid", spellID = 432254, name = "VOTI", fullname = "Vault of the Incarnates"},
            {icon = "Interface\\Icons\\inv_achievement_raiddragon_raid", spellID = 432257, name = "ATSC", fullname = "Aberrus, the Shadowed Crucible"},
            {icon = "Interface\\Icons\\inv_achievement_raidemeralddream_raid", spellID = 432258, name = "ATDH", fullname = "Amirdrassil, The Dream's Hope"},
        }
    },
    {
        key = "SL_RAIDS",
        title = "Shadowlands Raids",
        dungeons = {
            {icon = "Interface\\Icons\\achievement_raid_revendrethraid_castlenathria", spellID = 373190, name = "CN", fullname = "Castle Nathria"},
            {icon = "Interface\\Icons\\achievement_raid_torghastraid", spellID = 373191, name = "SOD", fullname = "Sanctum of Domination"},
            {icon = "Interface\\Icons\\inv_achievement_raid_progenitorraid", spellID = 373192, name = "STFO", fullname = "Sepulcher of the First Ones"},
        }
    },
}
