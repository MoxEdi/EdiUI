-- EdiUI Dungeon Teleports Module
-- Ported from M+ Dungeon Teleports by peepoStudy
local EdiUI = EdiUI
local DungeonTeleports = EdiUI:NewModule("DungeonTeleports", "AceHook-3.0", "AceEvent-3.0")

local Data = EdiUI.DungeonPortalData

-- Local references
local PortalLibrary = nil
local expansionFrames = {}
local allButtons = {}

-- Constants
local BUTTON_SIZE = 32
local BUTTON_SPACING = 5
local TITLE_TOP_MARGIN = 26
local EXPANSION_SPACING = 64
local BORDER_THICKNESS = 2

-- Helper: Get database
local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.dungeonTeleports
end

-- Helper: Format cooldown time
local function FormatCooldownTime(seconds)
    if seconds >= 3600 then
        return string.format("%dh", math.floor(seconds / 3600))
    elseif seconds >= 60 then
        return string.format("%dm", math.floor(seconds / 60))
    else
        return string.format("%ds", math.floor(seconds))
    end
end

-- Update cooldown text on a button
local function UpdateCooldownText(button, spellID)
    if InCombatLockdown() then return end

    local cooldownFrame = button.cooldownText
    local cooldownOverlay = button.cooldownOverlay
    local spellCooldownInfo = C_Spell.GetSpellCooldown(spellID)

    if spellCooldownInfo then
        local startTime = spellCooldownInfo.startTime
        local duration = spellCooldownInfo.duration
        local isEnabled = spellCooldownInfo.isEnabled

        if not issecretvalue(startTime) and not issecretvalue(duration) then
            if startTime > 0 and duration > 0 and isEnabled then
                local remaining = math.max(0, (startTime + duration) - GetTime())
                if remaining > 5 then
                    cooldownFrame:SetText(FormatCooldownTime(remaining))
                    cooldownOverlay:Show()
                    return
                end
            end
        end
    end

    cooldownFrame:SetText("")
    cooldownOverlay:Hide()
end

-- Create a spell button
local function CreateSpellButton(parent, data, expansionKey)
    local db = GetDb()
    local button = CreateFrame("Button", nil, parent, "SecureActionButtonTemplate")
    button:SetSize(BUTTON_SIZE, BUTTON_SIZE)

    button.data = data
    button.expansionKey = expansionKey

    -- Icon texture
    local buttonTexture = button:CreateTexture(nil, "BACKGROUND")
    buttonTexture:SetAllPoints(button)
    buttonTexture:SetTexture(data.icon)
    buttonTexture:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    button.buttonTexture = buttonTexture

    -- Cooldown overlay
    local cooldownOverlay = button:CreateTexture(nil, "ARTWORK")
    cooldownOverlay:SetAllPoints(button)
    cooldownOverlay:SetTexture("Interface\\Tooltips\\UI-Tooltip-Background")
    cooldownOverlay:SetVertexColor(0, 0, 0, 0.6)
    cooldownOverlay:Hide()
    button.cooldownOverlay = cooldownOverlay

    -- Hover overlay
    local hoverOverlay = button:CreateTexture(nil, "ARTWORK")
    hoverOverlay:SetAllPoints(button)
    hoverOverlay:SetColorTexture(0, 0, 0, 0.6)
    hoverOverlay:SetDrawLayer("ARTWORK", 1)
    hoverOverlay:Hide()
    button.hoverOverlay = hoverOverlay

    -- Button borders
    local bbc = db and db.buttonBorderColor or {r = 0.05, g = 0.05, b = 0.05, a = 0.8}

    local borderTop = button:CreateTexture(nil, "OVERLAY")
    borderTop:SetColorTexture(bbc.r, bbc.g, bbc.b, 1)
    borderTop:SetPoint("TOPLEFT", button, "TOPLEFT", BORDER_THICKNESS, 0)
    borderTop:SetPoint("TOPRIGHT", button, "TOPRIGHT", -BORDER_THICKNESS, 0)
    borderTop:SetHeight(BORDER_THICKNESS)
    button.borderTop = borderTop

    local borderBottom = button:CreateTexture(nil, "OVERLAY")
    borderBottom:SetColorTexture(bbc.r, bbc.g, bbc.b, 1)
    borderBottom:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", BORDER_THICKNESS, 0)
    borderBottom:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", -BORDER_THICKNESS, 0)
    borderBottom:SetHeight(BORDER_THICKNESS)
    button.borderBottom = borderBottom

    local borderLeft = button:CreateTexture(nil, "OVERLAY")
    borderLeft:SetColorTexture(bbc.r, bbc.g, bbc.b, 1)
    borderLeft:SetPoint("TOPLEFT", button, "TOPLEFT", 0, 0)
    borderLeft:SetPoint("BOTTOMLEFT", button, "BOTTOMLEFT", 0, 0)
    borderLeft:SetWidth(BORDER_THICKNESS)
    button.borderLeft = borderLeft

    local borderRight = button:CreateTexture(nil, "OVERLAY")
    borderRight:SetColorTexture(bbc.r, bbc.g, bbc.b, 1)
    borderRight:SetPoint("TOPRIGHT", button, "TOPRIGHT", 0, 0)
    borderRight:SetPoint("BOTTOMRIGHT", button, "BOTTOMRIGHT", 0, 0)
    borderRight:SetWidth(BORDER_THICKNESS)
    button.borderRight = borderRight

    -- Button text (dungeon name)
    local buttonText = button:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    buttonText:SetPoint("TOP", button, "BOTTOM", 1, 6)
    buttonText:SetFont(STANDARD_TEXT_FONT, db and db.buttonFontSize or 11, "OUTLINE")
    buttonText:SetTextColor(1, 1, 1)
    buttonText:SetText(data.name)
    button.buttonText = buttonText

    -- Cooldown text
    local cooldownText = button:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    cooldownText:SetPoint("CENTER", button, "CENTER", 1, 0)
    cooldownText:SetTextColor(1, 1, 1)
    cooldownText:SetFont(STANDARD_TEXT_FONT, 14, "OUTLINE")
    button.cooldownText = cooldownText

    -- Set up secure action
    button:SetAttribute("type", "spell")
    button:SetAttribute("spell", data.spellID)

    -- Update button texture based on spell knowledge
    local function UpdateButtonTexture()
        if C_SpellBook.IsSpellInSpellBook(data.spellID) then
            buttonTexture:SetTexture(data.icon)
            buttonTexture:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            buttonTexture:SetDesaturated(false)
            if db and db.darkenText then
                buttonText:SetTextColor(1, 1, 1)
            end
        else
            buttonTexture:SetTexture(data.icon)
            buttonTexture:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            buttonTexture:SetDesaturated(true)
            if db and db.darkenText then
                buttonText:SetTextColor(0.5, 0.5, 0.5)
            end
        end
    end
    button.UpdateButtonTexture = UpdateButtonTexture
    UpdateButtonTexture()

    -- Event handling
    local function OnEvent(self, event)
        if event == "SPELLS_CHANGED" or event == "PLAYER_ENTERING_WORLD" then
            UpdateButtonTexture()
            UpdateCooldownText(self, data.spellID)
        elseif event == "CHALLENGE_MODE_COMPLETED" then
            C_Timer.After(2, function()
                UpdateButtonTexture()
                UpdateCooldownText(self, data.spellID)
            end)
        end
    end

    -- Tooltip
    button:SetScript("OnEnter", function(self)
        local db = GetDb()
        if db and db.showTooltips then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetSpellByID(data.spellID)
            GameTooltip:Show()
        end
        hoverOverlay:Show()
    end)

    button:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
        hoverOverlay:Hide()
    end)

    button:RegisterEvent("CHALLENGE_MODE_COMPLETED")
    button:RegisterEvent("PLAYER_ENTERING_WORLD")
    button:RegisterEvent("SPELLS_CHANGED")
    button:RegisterForClicks("AnyUp", "AnyDown")
    button:SetScript("OnEvent", OnEvent)

    return button
end

-- Update layout
function DungeonTeleports:UpdateLayout()
    local db = GetDb()
    if not db or not PortalLibrary then return end

    local currentYOffset = -TITLE_TOP_MARGIN

    for _, expansion in ipairs(Data.Expansions) do
        local expFrame = expansionFrames[expansion.key]
        if expFrame then
            local isVisible = db.expansionVisibility and db.expansionVisibility[expansion.key]
            if isVisible == nil then isVisible = true end

            if isVisible then
                -- Position title
                expFrame.title:ClearAllPoints()
                expFrame.title:SetPoint("TOP", PortalLibrary, "TOP", 0, currentYOffset)
                expFrame.title:Show()

                -- Position buttons
                local buttonYOffset = currentYOffset - 18
                for i, button in ipairs(expFrame.buttons) do
                    local xOffset = (i - 1) * (BUTTON_SIZE + BUTTON_SPACING) + 10
                    button:ClearAllPoints()
                    button:SetPoint("TOPLEFT", PortalLibrary, "TOPLEFT", xOffset, buttonYOffset)
                    button:Show()
                end

                currentYOffset = currentYOffset - EXPANSION_SPACING
            else
                expFrame.title:Hide()
                for _, button in ipairs(expFrame.buttons) do
                    button:Hide()
                end
            end
        end
    end

    -- Calculate frame height
    local visibleCount = 0
    for _, expansion in ipairs(Data.Expansions) do
        local isVisible = db.expansionVisibility and db.expansionVisibility[expansion.key]
        if isVisible == nil then isVisible = true end
        if isVisible then
            visibleCount = visibleCount + 1
        end
    end

    local frameHeight = TITLE_TOP_MARGIN + 6 + (visibleCount * EXPANSION_SPACING)
    PortalLibrary:SetHeight(frameHeight)
end

-- Update colors
function DungeonTeleports:UpdateColors()
    local db = GetDb()
    if not db or not PortalLibrary then return end

    local bc = db.borderColor
    local bg = db.backgroundColor
    local bbc = db.buttonBorderColor

    if PortalLibrary.backdrop then
        PortalLibrary.backdrop:SetColorTexture(bg.r, bg.g, bg.b, bg.a)
    end

    if PortalLibrary.borderTop then PortalLibrary.borderTop:SetColorTexture(bc.r, bc.g, bc.b, bc.a) end
    if PortalLibrary.borderBottom then PortalLibrary.borderBottom:SetColorTexture(bc.r, bc.g, bc.b, bc.a) end
    if PortalLibrary.borderLeft then PortalLibrary.borderLeft:SetColorTexture(bc.r, bc.g, bc.b, bc.a) end
    if PortalLibrary.borderRight then PortalLibrary.borderRight:SetColorTexture(bc.r, bc.g, bc.b, bc.a) end

    for _, button in ipairs(allButtons) do
        if button.borderTop then button.borderTop:SetColorTexture(bbc.r, bbc.g, bbc.b, 1) end
        if button.borderBottom then button.borderBottom:SetColorTexture(bbc.r, bbc.g, bbc.b, 1) end
        if button.borderLeft then button.borderLeft:SetColorTexture(bbc.r, bbc.g, bbc.b, 1) end
        if button.borderRight then button.borderRight:SetColorTexture(bbc.r, bbc.g, bbc.b, 1) end
    end
end

-- Update fonts
function DungeonTeleports:UpdateFonts()
    local db = GetDb()
    if not db or not PortalLibrary then return end

    local expColor = db.expansionColor
    local titleColor = db.titleColor
    local buttonColor = db.buttonTextColor

    if PortalLibrary.titleText then
        PortalLibrary.titleText:SetFont(STANDARD_TEXT_FONT, db.titleFontSize or 12, "OUTLINE")
        PortalLibrary.titleText:SetTextColor(titleColor.r, titleColor.g, titleColor.b)
    end

    for _, expansion in ipairs(Data.Expansions) do
        local expFrame = expansionFrames[expansion.key]
        if expFrame and expFrame.title then
            expFrame.title:SetFont(STANDARD_TEXT_FONT, db.expansionFontSize or 12, "OUTLINE")
            expFrame.title:SetTextColor(expColor.r, expColor.g, expColor.b)
        end
    end

    for _, button in ipairs(allButtons) do
        if button.buttonText then
            button.buttonText:SetFont(STANDARD_TEXT_FONT, db.buttonFontSize or 11, "OUTLINE")
            local spellID = button.data and button.data.spellID
            if spellID and not C_SpellBook.IsSpellInSpellBook(spellID) and db.darkenText then
                button.buttonText:SetTextColor(0.5, 0.5, 0.5)
            else
                button.buttonText:SetTextColor(buttonColor.r, buttonColor.g, buttonColor.b)
            end
        end
    end
end

-- Update button textures
function DungeonTeleports:UpdateButtonTextures()
    for _, button in ipairs(allButtons) do
        if button.UpdateButtonTexture then
            button:UpdateButtonTexture()
        end
    end
end

-- Create the main portal library frame
function DungeonTeleports:CreatePortalLibrary()
    if PortalLibrary then return end
    if not PVEFrame then return end

    local db = GetDb()
    if not db then return end

    -- Main frame (anchored to PVEFrame)
    PortalLibrary = CreateFrame("Frame", "EdiUI_PortalLibrary", PVEFrame)
    PortalLibrary:SetSize(384, 630)
    PortalLibrary:SetPoint("TOPLEFT", PVEFrame, "TOPRIGHT", 5, 0)

    -- Backdrop
    local backdrop = PortalLibrary:CreateTexture(nil, "BACKGROUND")
    backdrop:SetAllPoints(PortalLibrary)
    backdrop:SetColorTexture(db.backgroundColor.r, db.backgroundColor.g, db.backgroundColor.b, db.backgroundColor.a)
    PortalLibrary.backdrop = backdrop

    -- Borders
    local bc = db.borderColor

    local borderTop = PortalLibrary:CreateTexture(nil, "OVERLAY")
    borderTop:SetColorTexture(bc.r, bc.g, bc.b, bc.a)
    borderTop:SetPoint("TOPLEFT", PortalLibrary, "TOPLEFT", BORDER_THICKNESS, 0)
    borderTop:SetPoint("TOPRIGHT", PortalLibrary, "TOPRIGHT", -BORDER_THICKNESS, 0)
    borderTop:SetHeight(BORDER_THICKNESS)
    PortalLibrary.borderTop = borderTop

    local borderBottom = PortalLibrary:CreateTexture(nil, "OVERLAY")
    borderBottom:SetColorTexture(bc.r, bc.g, bc.b, bc.a)
    borderBottom:SetPoint("BOTTOMLEFT", PortalLibrary, "BOTTOMLEFT", BORDER_THICKNESS, 0)
    borderBottom:SetPoint("BOTTOMRIGHT", PortalLibrary, "BOTTOMRIGHT", -BORDER_THICKNESS, 0)
    borderBottom:SetHeight(BORDER_THICKNESS)
    PortalLibrary.borderBottom = borderBottom

    local borderLeft = PortalLibrary:CreateTexture(nil, "OVERLAY")
    borderLeft:SetColorTexture(bc.r, bc.g, bc.b, bc.a)
    borderLeft:SetPoint("TOPLEFT", PortalLibrary, "TOPLEFT", 0, 0)
    borderLeft:SetPoint("BOTTOMLEFT", PortalLibrary, "BOTTOMLEFT", 0, 0)
    borderLeft:SetWidth(BORDER_THICKNESS)
    PortalLibrary.borderLeft = borderLeft

    local borderRight = PortalLibrary:CreateTexture(nil, "OVERLAY")
    borderRight:SetColorTexture(bc.r, bc.g, bc.b, bc.a)
    borderRight:SetPoint("TOPRIGHT", PortalLibrary, "TOPRIGHT", 0, 0)
    borderRight:SetPoint("BOTTOMRIGHT", PortalLibrary, "BOTTOMRIGHT", 0, 0)
    borderRight:SetWidth(BORDER_THICKNESS)
    PortalLibrary.borderRight = borderRight

    -- Title
    local titleText = PortalLibrary:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    titleText:SetPoint("TOP", PortalLibrary, "TOP", 0, -6)
    titleText:SetFont(STANDARD_TEXT_FONT, db.titleFontSize or 12, "OUTLINE")
    titleText:SetTextColor(db.titleColor.r, db.titleColor.g, db.titleColor.b)
    titleText:SetText("M+ Teleports")
    PortalLibrary.titleText = titleText

    -- Create expansion sections
    for _, expansion in ipairs(Data.Expansions) do
        local expFrame = {
            buttons = {}
        }

        -- Expansion title
        local expTitle = PortalLibrary:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        expTitle:SetFont(STANDARD_TEXT_FONT, db.expansionFontSize or 12, "OUTLINE")
        expTitle:SetTextColor(db.expansionColor.r, db.expansionColor.g, db.expansionColor.b)
        expTitle:SetText(expansion.title)
        expFrame.title = expTitle

        -- Create dungeon buttons
        for i, dungeon in ipairs(expansion.dungeons) do
            dungeon.index = i
            local button = CreateSpellButton(PortalLibrary, dungeon, expansion.key)
            table.insert(expFrame.buttons, button)
            table.insert(allButtons, button)
        end

        expansionFrames[expansion.key] = expFrame
    end

    -- Initial layout
    self:UpdateLayout()

    -- Update visibility based on PVEFrame
    PortalLibrary:SetShown(db.enabled and PVEFrame:IsShown())
end

-- Toggle expansion visibility
function DungeonTeleports:ToggleExpansion(key)
    local db = GetDb()
    if not db then return end

    if not db.expansionVisibility then
        db.expansionVisibility = {}
    end

    if db.expansionVisibility[key] == nil then
        db.expansionVisibility[key] = true
    end

    db.expansionVisibility[key] = not db.expansionVisibility[key]
    self:UpdateLayout()
end

-- Update visibility
function DungeonTeleports:UpdateVisibility()
    local db = GetDb()
    if not PortalLibrary then return end

    if db and db.enabled and PVEFrame and PVEFrame:IsShown() then
        PortalLibrary:Show()
    else
        PortalLibrary:Hide()
    end
end

-- Full update
function DungeonTeleports:Update()
    if not PortalLibrary then
        self:CreatePortalLibrary()
    end

    self:UpdateColors()
    self:UpdateFonts()
    self:UpdateLayout()
    self:UpdateButtonTextures()
    self:UpdateVisibility()
end

-- Setup hooks for PVEFrame
function DungeonTeleports:SetupPVEFrameHooks()
    if not PVEFrame or self.hooksApplied then return end

    self:SecureHookScript(PVEFrame, "OnShow", function()
        if not PortalLibrary then
            self:CreatePortalLibrary()
        end
        self:UpdateVisibility()
    end)

    self:SecureHookScript(PVEFrame, "OnHide", function()
        self:UpdateVisibility()
    end)

    self.hooksApplied = true

    -- If PVEFrame is already shown, create and show the library
    if PVEFrame:IsShown() then
        self:CreatePortalLibrary()
        self:Update()
    end
end

-- Module enable
function DungeonTeleports:OnEnable()
    local db = GetDb()
    if not db then return end

    self.hooksApplied = false

    -- PVEFrame is loaded on demand via Blizzard_PVUI
    -- We need to wait for it to be available
    self:RegisterEvent("ADDON_LOADED", function(_, addonName)
        if addonName == "Blizzard_PVUI" or addonName == "Blizzard_GroupFinder" then
            C_Timer.After(0.1, function()
                if PVEFrame and GetDb() and GetDb().enabled then
                    self:SetupPVEFrameHooks()
                end
            end)
        end
    end)

    -- Check if PVEFrame already exists (addon already loaded)
    if PVEFrame then
        self:SetupPVEFrameHooks()
    end

    -- Also check periodically in case we missed the addon load event
    C_Timer.After(1, function()
        if PVEFrame and GetDb() and GetDb().enabled and not self.hooksApplied then
            self:SetupPVEFrameHooks()
        end
    end)
end

-- Module disable
function DungeonTeleports:OnDisable()
    if PortalLibrary then
        PortalLibrary:Hide()
    end
end
