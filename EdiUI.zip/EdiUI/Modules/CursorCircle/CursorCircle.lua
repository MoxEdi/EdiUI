-- EdiUI Cursor Circle (Ported from UltimateMouseCursor)
-- Full cursor reticle with rings, GCD/Cast tracking, trails, and modifier actions
local EdiUI = EdiUI
local CursorCircle = EdiUI:NewModule("CursorCircle", "AceEvent-3.0")

local TrackerFrame = CreateFrame("Frame", "EdiUI_CursorTrackerFrame", UIParent)
local GCD_SPELL_ID = 61304

-- State variables
CursorCircle.GCDCooldownFrame = nil
CursorCircle.GCDBackgroundFrame = nil
CursorCircle.CastFrame = nil
CursorCircle.CastBackgroundFrame = nil
CursorCircle.HealthFrame = nil
CursorCircle.HealthBackgroundFrame = nil
CursorCircle.PowerFrame = nil
CursorCircle.HighContrastRings = {}

CursorCircle.currentGroupScale = 1.0
CursorCircle.lastGCDTime = 0
CursorCircle.isGCDAnimating = false
CursorCircle.isCasting = false
CursorCircle.lastHealthPercent = 1.0
CursorCircle.lastPowerPercent = 1.0

CursorCircle.trailElements = {}
CursorCircle.trailActive = {}
CursorCircle.trailTimer = 0
CursorCircle.trailLastX = 0
CursorCircle.trailLastY = 0

CursorCircle.lastShiftState = false
CursorCircle.lastCtrlState = false
CursorCircle.lastAltState = false

CursorCircle.pingTimer = 0
CursorCircle.isPingAnimating = false
CursorCircle.pingDuration = 0.5
CursorCircle.pingStartSize = 250
CursorCircle.pingEndSize = 70

CursorCircle.crosshairTimer = 0
CursorCircle.isCrosshairAnimating = false
CursorCircle.crosshairDuration = 1.5
CursorCircle.crosshairGap = 35

CursorCircle.enableGCD = false
CursorCircle.enableCast = false

-- Ring and reticle option lists
CursorCircle.ringOptions = {
    "None",
    "Main Ring",
    "Main Ring + GCD",
    "Main Ring + Cast",
    "Cast",
    "GCD",
    "Health and Power",
    "Health",
    "Power",
    "High Contrast Ring",
}

CursorCircle.modifierOptions = {
    "None",
    "Show Rings",
    "Ping with ring",
    "Ping with area",
    "Ping with crosshair",
    "Show Crosshair",
}

CursorCircle.reticleOptions = {
    "Dot",
    "Chevron",
    "Crosshair",
    "Diamond",
    "Flatline",
    "Star",
    "Ring",
    "Tech Arrow",
    "X",
    "No Reticle",
}

CursorCircle.reticleTextures = {
    ["Dot"] = { path = "Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Reticle_Dot", scale = 0.5 },
    ["Chevron"] = { path = "uitools-icon-chevron-down", scale = 1.0, isAtlas = true },
    ["Crosshair"] = { path = "uitools-icon-plus", scale = 1.0, isAtlas = true },
    ["Diamond"] = { path = "UF-SoulShard-FX-FrameGlow", scale = 1.0, isAtlas = true },
    ["Flatline"] = { path = "uitools-icon-minus", scale = 1.0, isAtlas = true },
    ["Star"] = { path = "AftLevelup-WhiteStarBurst", scale = 2.0, isAtlas = true },
    ["Ring"] = { path = "Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Reticle_Circle", scale = 1.0 },
    ["Tech Arrow"] = { path = "ProgLan-w-4", scale = 1.0, isAtlas = true },
    ["X"] = { path = "uitools-icon-close", scale = 1.0, isAtlas = true },
    ["No Reticle"] = { path = nil, scale = 1.0 },
}

local function GetDb()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.cursorCircle
end

function CursorCircle:GetClassColor(ringType)
    local db = GetDb()
    if not db then return 1, 1, 1 end

    local colorMode = "default"
    local customColor = nil

    if ringType == "main" then
        colorMode = db.mainRingColorMode or "default"
        customColor = db.mainRingCustomColor
    elseif ringType == "gcd" then
        colorMode = db.gcdColorMode or "default"
        customColor = db.gcdCustomColor
    elseif ringType == "cast" then
        colorMode = db.castColorMode or "default"
        customColor = db.castCustomColor
    elseif ringType == "reticle" then
        colorMode = db.reticleColorMode or "default"
        customColor = db.reticleCustomColor
    elseif ringType == "trail" then
        colorMode = db.trailColorMode or "default"
        customColor = db.trailCustomColor
    elseif ringType == "power" then
        colorMode = db.powerColorMode or "default"
        customColor = db.powerCustomColor
    elseif ringType == "health" then
        colorMode = db.healthColorMode or "default"
        customColor = db.healthCustomColor
    end

    if colorMode == "custom" and customColor then
        return customColor.r or 1.0, customColor.g or 1.0, customColor.b or 1.0
    end

    if colorMode == "power" and ringType == "power" then
        return nil, nil, nil
    end

    if colorMode == "class" then
        local _, class = UnitClass("player")
        local classColor = C_ClassColor.GetClassColor(class)
        if classColor then
            return classColor.r, classColor.g, classColor.b
        end
    end

    if ringType == "power" then
        return 0.0, 0.5, 1.0
    else
        return 1.0, 1.0, 1.0
    end
end

function CursorCircle:ClockToRadians(clockPosition)
    local position = (clockPosition == 12) and 0 or clockPosition
    return (position * math.pi / 6)
end

function CursorCircle:CreateCursorFrame()
    if self.CursorFrame then return end

    local frame = CreateFrame("Frame", "EdiUI_CursorFrame", UIParent)
    frame:SetSize(100, 100)
    frame:SetFrameStrata("HIGH")
    frame:SetToplevel(false)
    frame:EnableMouse(false)

    local mainRing = frame:CreateTexture(nil, "ARTWORK")
    mainRing:SetTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    mainRing:SetSize(70, 70)
    mainRing:SetPoint("CENTER", frame, "CENTER")
    mainRing:SetVertexColor(1, 1, 1, 1)
    frame.MainRing = mainRing

    local reticle = frame:CreateTexture(nil, "OVERLAY")
    reticle:SetSize(32, 32)
    reticle:SetPoint("CENTER", frame, "CENTER")
    frame.Reticle = reticle

    self.CursorFrame = frame
end

function CursorCircle:UpdateRingColors()
    local db = GetDb()
    if not db then return end

    local hasMainRingPlusGCD = false
    local hasMainRingPlusCast = false

    local slots = {
        {config = db.innerRing},
        {config = db.mainRing},
        {config = db.outerRing},
    }

    for _, slot in ipairs(slots) do
        if slot.config == "Main Ring + GCD" then
            hasMainRingPlusGCD = true
        end
        if slot.config == "Main Ring + Cast" then
            hasMainRingPlusCast = true
        end
    end

    if self.GCDCooldownFrame then
        local gcdMode = db.gcdColorMode or "default"
        if hasMainRingPlusGCD and gcdMode == "default" then
            self.GCDCooldownFrame:SetSwipeColor(0.4, 0.4, 0.4, 1.0)
        else
            local r, g, b = self:GetClassColor("gcd")
            self.GCDCooldownFrame:SetSwipeColor(r, g, b, 1.0)
        end
    end

    if self.CastFrame then
        local castMode = db.castColorMode or "default"
        if hasMainRingPlusCast and castMode == "default" then
            self.CastFrame:SetSwipeColor(0.4, 0.4, 0.4, 1.0)
        else
            local r, g, b = self:GetClassColor("cast")
            self.CastFrame:SetSwipeColor(r, g, b, 1.0)
        end
    end

    if self.CursorFrame and self.CursorFrame.MainRing then
        local r, g, b = self:GetClassColor("main")
        self.CursorFrame.MainRing:SetVertexColor(r, g, b, 1.0)
    end
end

function CursorCircle:UpdateReticle()
    if not self.CursorFrame or not self.CursorFrame.Reticle then return end

    local db = GetDb()
    if not db then return end

    local reticleName = db.reticle or "Dot"
    local reticleInfo = self.reticleTextures[reticleName]

    if not reticleInfo or not reticleInfo.path then
        self.CursorFrame.Reticle:Hide()
    else
        self.CursorFrame.Reticle:Show()

        if reticleInfo.isAtlas then
            self.CursorFrame.Reticle:SetAtlas(reticleInfo.path)
        else
            self.CursorFrame.Reticle:SetTexture(reticleInfo.path)
        end

        local globalScale = db.reticleScale or 1.0
        self.CursorFrame.Reticle:SetScale(reticleInfo.scale * globalScale)

        local r, g, b = self:GetClassColor("reticle")
        self.CursorFrame.Reticle:SetVertexColor(r, g, b, 1.0)
    end
end

function CursorCircle:SetGroupScale(scale)
    if type(scale) == "number" and scale > 0 then
        self.currentGroupScale = scale
        if self.CursorFrame then
            self.CursorFrame:SetScale(scale)
        end
    end
end

function CursorCircle:CreateHighContrastRing(size)
    if not self.HighContrastRings then
        self.HighContrastRings = {}
    end

    local ringKey = "ring_" .. size
    local ring = self.HighContrastRings[ringKey]
    local db = GetDb()
    if not db then return end

    if not ring then
        ring = {}

        local outerHalf = self.CursorFrame:CreateTexture(nil, "ARTWORK")
        outerHalf:SetTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
        outerHalf:SetPoint("CENTER", self.CursorFrame, "CENTER")
        outerHalf:SetDrawLayer("ARTWORK", 1)
        ring.outerHalf = outerHalf

        local innerHalf = self.CursorFrame:CreateTexture(nil, "ARTWORK")
        innerHalf:SetTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
        innerHalf:SetPoint("CENTER", self.CursorFrame, "CENTER")
        innerHalf:SetDrawLayer("ARTWORK", 2)
        ring.innerHalf = innerHalf

        self.HighContrastRings[ringKey] = ring
    end

    local function GetHighContrastColor(colorMode, customColor, defaultColor)
        if colorMode == "class" then
            local _, class = UnitClass("player")
            if class then
                local classColor = RAID_CLASS_COLORS[class]
                if classColor then
                    return classColor.r, classColor.g, classColor.b
                end
            end
        elseif colorMode == "custom" then
            return customColor.r, customColor.g, customColor.b
        end
        return defaultColor.r, defaultColor.g, defaultColor.b
    end

    local outerColorMode = db.highContrastOuterColorMode or "default"
    local outerCustomColor = db.highContrastOuterColor or {r = 0.0, g = 0.0, b = 0.0}
    local outerDefaultColor = {r = 0.0, g = 0.0, b = 0.0}
    local outerThickness = db.highContrastOuterThickness or 2

    local innerColorMode = db.highContrastInnerColorMode or "default"
    local innerCustomColor = db.highContrastInnerColor or {r = 1.0, g = 1.0, b = 1.0}
    local innerDefaultColor = {r = 1.0, g = 1.0, b = 1.0}
    local innerThickness = db.highContrastInnerThickness or -4

    local outerSize = size + (outerThickness * 2)
    local innerSize = size + (innerThickness * 2)

    ring.outerHalf:SetSize(outerSize, outerSize)
    ring.innerHalf:SetSize(innerSize, innerSize)

    local outerR, outerG, outerB = GetHighContrastColor(outerColorMode, outerCustomColor, outerDefaultColor)
    local innerR, innerG, innerB = GetHighContrastColor(innerColorMode, innerCustomColor, innerDefaultColor)

    ring.outerHalf:SetVertexColor(outerR, outerG, outerB, 1.0)
    ring.innerHalf:SetVertexColor(innerR, innerG, innerB, 1.0)

    ring.outerHalf:Show()
    ring.innerHalf:Show()

    for key, otherRing in pairs(self.HighContrastRings) do
        if key ~= ringKey then
            if otherRing.outerHalf then otherRing.outerHalf:Hide() end
            if otherRing.innerHalf then otherRing.innerHalf:Hide() end
        end
    end
end

function CursorCircle:InitializeTrail()
    for i = 1, 300 do
        local texture = UIParent:CreateTexture(nil, "ARTWORK")
        texture:SetTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Reticle_Dot")
        texture:SetBlendMode("ADD")
        texture:Hide()
        self.trailElements[i] = texture
    end
end

function CursorCircle:GetTrailColorForStyle(style)
    if style == "None" then
        return 1.0, 1.0, 1.0
    elseif style == "Candy Cane" then
        self.candyCaneToggle = not self.candyCaneToggle
        if self.candyCaneToggle then
            return 1.0, 0.0, 0.0
        else
            return 1.0, 1.0, 1.0
        end
    elseif style == "Christmas Lights" then
        self.lightsIndex = (self.lightsIndex or 0) + 1
        if self.lightsIndex > 5 then self.lightsIndex = 1 end

        if self.lightsIndex == 1 then
            return 1.0, 0.0, 0.0
        elseif self.lightsIndex == 2 then
            return 0.0, 1.0, 0.0
        elseif self.lightsIndex == 3 then
            return 1.0, 0.84, 0.0
        elseif self.lightsIndex == 4 then
            return 1.0, 1.0, 1.0
        else
            return 0.3, 0.7, 1.0
        end
    end

    return 1.0, 1.0, 1.0
end

function CursorCircle:UpdateTrail(elapsed)
    local db = GetDb()
    if not db then return end

    local shouldShowTrail = db.enableTrail and self.CursorFrame and self.CursorFrame:IsShown()

    if shouldShowTrail then
        local cursorX, cursorY = GetCursorPosition()
        local uiScale = UIParent:GetEffectiveScale()

        local x = cursorX - self.trailLastX
        local y = cursorY - self.trailLastY
        local movement = math.sqrt(x * x + y * y)

        local minMovement = db.trailMinMovement or 0.5
        local density = db.trailDensity or 0.008

        self.trailTimer = self.trailTimer + elapsed

        if self.trailTimer >= density and movement >= minMovement and #self.trailElements > 0 then
            self.trailTimer = 0

            local trailColorMode = db.trailColorMode or "default"

            if trailColorMode == "seasonal" then
                local style = db.seasonalEffectStyle or "Candy Cane"

                if style ~= "None" then
                    local element = table.remove(self.trailElements)
                    table.insert(self.trailActive, element)

                    element.duration = db.trailDuration or 0.4
                    element.x = cursorX / uiScale
                    element.y = cursorY / uiScale

                    local r, g, b = self:GetTrailColorForStyle(style)

                    element:SetVertexColor(r, g, b, 1.0)
                    local baseSize = 50 * (db.trailScale or 1.0)
                    element:SetSize(baseSize, baseSize)
                    element:SetPoint("CENTER", UIParent, "BOTTOMLEFT", element.x, element.y)
                    element:SetAlpha(0.5)
                    element:Show()
                end
            else
                local element = table.remove(self.trailElements)
                table.insert(self.trailActive, element)

                element.duration = db.trailDuration or 0.4
                element.x = cursorX / uiScale
                element.y = cursorY / uiScale

                local r, g, b = self:GetClassColor("trail")

                element:SetVertexColor(r, g, b, 1.0)
                local baseSize = 50 * (db.trailScale or 1.0)
                element:SetSize(baseSize, baseSize)
                element:SetPoint("CENTER", UIParent, "BOTTOMLEFT", element.x, element.y)
                element:SetAlpha(1.0)
                element:Show()
            end

            self.trailLastX = cursorX
            self.trailLastY = cursorY
        end
    else
        for i = #self.trailActive, 1, -1 do
            local element = self.trailActive[i]
            element:Hide()
            table.insert(self.trailElements, table.remove(self.trailActive, i))
        end
    end

    for i = #self.trailActive, 1, -1 do
        local element = self.trailActive[i]
        element.duration = element.duration - elapsed

        if element.duration <= 0 then
            element:Hide()
            table.insert(self.trailElements, table.remove(self.trailActive, i))
        else
            local db = GetDb()
            local progress = element.duration / (db and db.trailDuration or 0.4)
            progress = math.min(1.0, math.max(0.0, progress))
            local baseSize = 50 * (db and db.trailScale or 1.0)
            local size = math.max(5, baseSize * progress)
            element:SetSize(size, size)
            element:SetAlpha(progress)
            element:SetPoint("CENTER", UIParent, "BOTTOMLEFT", element.x, element.y)
        end
    end
end

function CursorCircle:OnUpdate(elapsed)
    local cursorX, cursorY = GetCursorPosition()
    local uiScale = UIParent:GetScale()
    local groupScale = self.currentGroupScale

    local correctedX = (cursorX / uiScale) / groupScale
    local correctedY = (cursorY / uiScale) / groupScale

    self.CursorFrame:ClearAllPoints()
    self.CursorFrame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", correctedX, correctedY)

    self:UpdateTrail(elapsed)

    local db = GetDb()
    if not db then return end

    local shiftDown = IsShiftKeyDown()
    local ctrlDown = IsControlKeyDown()
    local altDown = IsAltKeyDown()

    if shiftDown and not self.lastShiftState then
        if db.shiftAction == "Ping with ring" then self:PlayPingAnimation("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
        elseif db.shiftAction == "Ping with area" then self:PlayPingAnimation("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Reticle_Dot")
        elseif db.shiftAction == "Ping with crosshair" then self:PlayCrosshairAnimation()
        end
    end
    if ctrlDown and not self.lastCtrlState then
        if db.ctrlAction == "Ping with ring" then self:PlayPingAnimation("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
        elseif db.ctrlAction == "Ping with area" then self:PlayPingAnimation("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Reticle_Dot")
        elseif db.ctrlAction == "Ping with crosshair" then self:PlayCrosshairAnimation()
        end
    end
    if altDown and not self.lastAltState then
        if db.altAction == "Ping with ring" then self:PlayPingAnimation("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
        elseif db.altAction == "Ping with area" then self:PlayPingAnimation("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Reticle_Dot")
        elseif db.altAction == "Ping with crosshair" then self:PlayCrosshairAnimation()
        end
    end

    local showCrosshair = (shiftDown and db.shiftAction == "Show Crosshair") or
                          (ctrlDown and db.ctrlAction == "Show Crosshair") or
                          (altDown and db.altAction == "Show Crosshair")

    if showCrosshair then
        self.isCrosshairAnimating = false
        self.CrosshairFrame:Show()
        self.CrosshairFrame:SetAlpha(1.0)
        self:UpdateCrosshairPosition()
    elseif (not shiftDown and self.lastShiftState and db.shiftAction == "Show Crosshair") or
           (not ctrlDown and self.lastCtrlState and db.ctrlAction == "Show Crosshair") or
           (not altDown and self.lastAltState and db.altAction == "Show Crosshair") then
        self:PlayCrosshairAnimation()
    end

    local showRings = false
    if shiftDown and db.shiftAction == "Show Rings" then showRings = true end
    if ctrlDown and db.ctrlAction == "Show Rings" then showRings = true end
    if altDown and db.altAction == "Show Rings" then showRings = true end

    if showRings then
        self:UpdateVisibility(true)
    elseif (not shiftDown and self.lastShiftState and db.shiftAction == "Show Rings") or
           (not ctrlDown and self.lastCtrlState and db.ctrlAction == "Show Rings") or
           (not altDown and self.lastAltState and db.altAction == "Show Rings") then
        self:UpdateVisibility()
    end

    self.lastShiftState = shiftDown
    self.lastCtrlState = ctrlDown
    self.lastAltState = altDown

    if self.isPingAnimating then
        self.pingTimer = self.pingTimer + elapsed
        if self.pingTimer >= self.pingDuration then
            self.isPingAnimating = false
            self.PingFrame:Hide()
        else
            local progress = self.pingTimer / self.pingDuration
            local size = self.pingStartSize - ((self.pingStartSize - self.pingEndSize) * progress)
            local alpha = 1.0 - progress

            self.PingFrame:SetSize(size, size)
            self.PingFrame:SetAlpha(alpha)
            self.PingFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
        end
    end

    if self.isCrosshairAnimating then
        self.crosshairTimer = self.crosshairTimer + elapsed
        if self.crosshairTimer >= self.crosshairDuration then
            self.isCrosshairAnimating = false
            self.CrosshairFrame:Hide()
        else
            local progress = self.crosshairTimer / self.crosshairDuration
            local alpha = 1.0
            if progress > 0.7 then
                alpha = 1.0 - ((progress - 0.7) / 0.3)
            end

            self.CrosshairFrame:SetAlpha(alpha)
            self:UpdateCrosshairPosition()
        end
    end

end

function CursorCircle:UpdateCrosshairPosition()
    if not self.CrosshairFrame then return end

    local gap = self.crosshairGap * self.currentGroupScale
    local cx, cy = GetCursorPosition()
    local scale = UIParent:GetEffectiveScale()
    cx = cx / scale
    cy = cy / scale

    self.CrosshairFrame.Top:ClearAllPoints()
    self.CrosshairFrame.Top:SetPoint("TOP", UIParent, "TOPLEFT", cx, 0)
    self.CrosshairFrame.Top:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", cx, cy + gap)

    self.CrosshairFrame.Bottom:ClearAllPoints()
    self.CrosshairFrame.Bottom:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", cx, 0)
    self.CrosshairFrame.Bottom:SetPoint("TOP", UIParent, "BOTTOMLEFT", cx, cy - gap)

    self.CrosshairFrame.Left:ClearAllPoints()
    self.CrosshairFrame.Left:SetPoint("LEFT", UIParent, "BOTTOMLEFT", 0, cy)
    self.CrosshairFrame.Left:SetPoint("RIGHT", UIParent, "BOTTOMLEFT", cx - gap, cy)

    self.CrosshairFrame.Right:ClearAllPoints()
    self.CrosshairFrame.Right:SetPoint("RIGHT", UIParent, "BOTTOMRIGHT", 0, cy)
    self.CrosshairFrame.Right:SetPoint("LEFT", UIParent, "BOTTOMLEFT", cx + gap, cy)
end

function CursorCircle:PlayPingAnimation(texturePath)
    if not self.PingFrame then return end
    if texturePath then
        self.PingFrame:SetTexture(texturePath)
    end
    self.isPingAnimating = true
    self.pingTimer = 0
    self.PingFrame:SetSize(self.pingStartSize, self.pingStartSize)
    self.PingFrame:SetAlpha(1.0)
    self.PingFrame:Show()
end

function CursorCircle:PlayCrosshairAnimation()
    if not self.CrosshairFrame then return end
    self.isCrosshairAnimating = true
    self.crosshairTimer = 0
    self.CrosshairFrame:SetAlpha(1.0)
    self.CrosshairFrame:Show()
end

function CursorCircle:UpdateHealthRing()
    local healthFrame = self.HealthFrame
    if not healthFrame then return end

    local currentHealth = UnitHealth("player")
    local maxHealth = UnitHealthMax("player")

    -- Handle restricted/secret values from the API
    if type(currentHealth) ~= "number" or type(maxHealth) ~= "number" then return end
    if maxHealth == 0 then return end

    local ok, healthPercent = pcall(function()
        return currentHealth / maxHealth
    end)
    if not ok or type(healthPercent) ~= "number" then return end

    local missingHealthPercent = 1 - healthPercent

    local db = GetDb()
    local r, g, b

    local healthColorLock = db and db.healthColorLock or false

    if healthColorLock or healthPercent > 0.70 then
        local healthColorMode = db and db.healthColorMode or "default"
        if healthColorMode == "class" then
            local _, class = UnitClass("player")
            if class then
                local classColor = RAID_CLASS_COLORS[class]
                if classColor then
                    r, g, b = classColor.r, classColor.g, classColor.b
                else
                    r, g, b = 1.0, 1.0, 1.0
                end
            else
                r, g, b = 1.0, 1.0, 1.0
            end
        elseif healthColorMode == "custom" then
            local customColor = db and db.healthCustomColor or {r = 1.0, g = 1.0, b = 1.0}
            r, g, b = customColor.r, customColor.g, customColor.b
        else
            r, g, b = 1.0, 1.0, 1.0
        end
    elseif healthPercent > 0.50 then
        r, g, b = 1.0, 0.788, 0.302
    elseif healthPercent > 0.35 then
        r, g, b = 1.0, 0.451, 0.184
    else
        r, g, b = 0.8, 0.0, 0.02
    end

    healthFrame:SetSwipeColor(r, g, b, 0.8)
    healthFrame:SetCooldown(0, 0)
    healthFrame:Clear()
    local hugeDuration = 86400
    local elapsed = missingHealthPercent * hugeDuration
    healthFrame:SetCooldown(GetTime() - elapsed, hugeDuration)
    healthFrame:Show()

    self.lastHealthPercent = healthPercent
end

function CursorCircle:UpdatePowerRing()
    local powerFrame = self.PowerFrame
    if not powerFrame then return end

    local currentPower = UnitPower("player")
    local maxPower = UnitPowerMax("player")

    if maxPower == 0 then return end

    local ok, powerPercent = pcall(function()
        return currentPower / maxPower
    end)
    if not ok or type(powerPercent) ~= "number" then return end
    local missingPowerPercent = 1 - powerPercent

    local r, g, b = self:GetClassColor("power")

    if not r then
        local powerType = UnitPowerType("player")

        if powerType == 0 then
            r, g, b = 0.00, 0.00, 1.00
        elseif powerType == 1 then
            r, g, b = 1.00, 0.00, 0.00
        elseif powerType == 2 then
            r, g, b = 1.00, 0.50, 0.25
        elseif powerType == 3 then
            r, g, b = 1.00, 1.00, 0.00
        elseif powerType == 4 then
            r, g, b = 1.00, 0.96, 0.41
        elseif powerType == 5 then
            r, g, b = 0.50, 0.50, 0.50
        elseif powerType == 6 then
            r, g, b = 0.00, 0.82, 1.00
        elseif powerType == 7 then
            r, g, b = 0.50, 0.32, 0.55
        elseif powerType == 8 then
            r, g, b = 0.30, 0.52, 0.90
        elseif powerType == 9 then
            r, g, b = 0.95, 0.90, 0.60
        elseif powerType == 11 then
            r, g, b = 0.00, 0.50, 1.00
        elseif powerType == 13 then
            r, g, b = 0.40, 0.00, 0.80
        elseif powerType == 12 then
            r, g, b = 0.71, 1.00, 0.92
        elseif powerType == 16 then
            r, g, b = 0.10, 0.10, 0.98
        elseif powerType == 17 then
            r, g, b = 0.788, 0.259, 0.992
        elseif powerType == 18 then
            r, g, b = 1.00, 0.61, 0.00
        else
            r, g, b = 0.00, 0.00, 1.00
        end
    end

    powerFrame:SetSwipeColor(r, g, b, 0.8)

    local hugeDuration = 86400
    local elapsed = missingPowerPercent * hugeDuration
    powerFrame:SetCooldown(GetTime() - elapsed, hugeDuration)
    powerFrame:Show()

    self.lastPowerPercent = powerPercent
end

function CursorCircle:StartGCDAnimation(startTime, duration)
    if not self.GCDCooldownFrame then return end
    if not self.enableGCD then return end

    local db = GetDb()
    self.isGCDAnimating = true

    local fillDrain = db and db.gcdFillDrain or "drain"
    self.GCDCooldownFrame:SetReverse(fillDrain == "fill")

    self.GCDCooldownFrame:SetCooldown(startTime, duration)
    self.GCDCooldownFrame:Show()
end

function CursorCircle:StartCastAnimation(startTime, duration)
    if not self.CastFrame then return end
    if not self.enableCast then return end

    local db = GetDb()
    self.isCasting = true

    local isChanneling = UnitChannelInfo("player") ~= nil

    local fillDrain = db and db.castFillDrain or "fill"
    local shouldReverse = (fillDrain == "fill")

    if isChanneling then
        shouldReverse = not shouldReverse
    end

    self.CastFrame:SetReverse(shouldReverse)

    self.CastFrame:SetCooldown(startTime, duration)
    self.CastFrame:Show()
end

function CursorCircle:StopCastAnimation()
    if not self.CastFrame then return end

    self.isCasting = false
    self.CastFrame:Clear()
    self.CastFrame:Hide()
end

function CursorCircle:GCDCastHandler(event, unit, spellName, spellId)
    if GetTime() - self.lastGCDTime < 0.1 then return end

    self.lastGCDTime = GetTime()

    local GCDInfo = C_Spell.GetSpellCooldown(GCD_SPELL_ID)

    if GCDInfo and GCDInfo.duration > 0 then
        self:StartGCDAnimation(GCDInfo.startTime, GCDInfo.duration)
    end
end

function CursorCircle:CastEventHandler(event, unit)
    local startTime, endTime, infoValid = nil, nil, false

    if event == "UNIT_SPELLCAST_START" then
        local cName, cRank, cTarget, cStartTime, cEndTime = UnitCastingInfo("player")
        startTime, endTime = cStartTime, cEndTime
        infoValid = true
    elseif event == "UNIT_SPELLCAST_CHANNEL_START" then
        local chName, chRank, chTarget, chStartTime, chEndTime, isMoving = UnitChannelInfo("player")
        startTime, endTime = chStartTime, chEndTime
        infoValid = true
    end

    if infoValid and startTime and endTime then
        local duration = (endTime - startTime) / 1000

        if duration > 0.1 then
            self:StartCastAnimation(startTime / 1000, duration)
        end
    elseif event == "UNIT_SPELLCAST_STOP" or event == "UNIT_SPELLCAST_CHANNEL_STOP" then
        self:StopCastAnimation()
    end
end

function CursorCircle:UpdateVisibility(forceState)
    if not self.CursorFrame then return end

    local db = GetDb()
    if not db or not db.enabled then
        self.CursorFrame:Hide()
        return
    end

    local shiftDown = IsShiftKeyDown()
    local ctrlDown = IsControlKeyDown()
    local altDown = IsAltKeyDown()

    local modifierShow = (shiftDown and db.shiftAction == "Show Rings") or
                         (ctrlDown and db.ctrlAction == "Show Rings") or
                         (altDown and db.altAction == "Show Rings")

    if modifierShow then
        self.CursorFrame:Show()
        return
    end

    local inCombat = forceState
    if inCombat == nil then
        inCombat = InCombatLockdown()
    end

    if db.showOnlyInCombat then
        if inCombat then
            self.CursorFrame:Show()
        else
            self.CursorFrame:Hide()
        end
    else
        local isAnyShowRingsConfigured = (db.shiftAction == "Show Rings") or
                                         (db.ctrlAction == "Show Rings") or
                                         (db.altAction == "Show Rings")

        if isAnyShowRingsConfigured then
            self.CursorFrame:Hide()
        else
            self.CursorFrame:Show()
        end
    end
end

function CursorCircle:ResetCooldownFrames()
    self.isGCDAnimating = false
    self.isCasting = false

    if self.GCDCooldownFrame then
        self.GCDCooldownFrame:Hide()
        self.GCDCooldownFrame:SetParent(nil)
        self.GCDCooldownFrame = nil
    end
    if self.GCDBackgroundFrame then
        self.GCDBackgroundFrame:Hide()
        self.GCDBackgroundFrame:SetParent(nil)
        self.GCDBackgroundFrame = nil
    end

    if self.CastFrame then
        self.CastFrame:Hide()
        self.CastFrame:SetParent(nil)
        self.CastFrame = nil
    end
    if self.CastBackgroundFrame then
        self.CastBackgroundFrame:Hide()
        self.CastBackgroundFrame:SetParent(nil)
        self.CastBackgroundFrame = nil
    end

    local db = GetDb()
    if not db then return end

    local gcdBgFrame = CreateFrame("Cooldown", nil, self.CursorFrame)
    gcdBgFrame:SetSize(70, 70)
    gcdBgFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    gcdBgFrame:SetFrameLevel(2)
    self.GCDBackgroundFrame = gcdBgFrame
    gcdBgFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    gcdBgFrame:SetSwipeColor(0.5, 0.5, 0.5, 0.7)
    gcdBgFrame:SetReverse(false)
    gcdBgFrame:SetHideCountdownNumbers(true)
    gcdBgFrame:SetCooldown(GetTime() - 1, 0.01)
    gcdBgFrame:Hide()

    local cooldownFrame = CreateFrame("Cooldown", nil, self.CursorFrame)
    cooldownFrame:SetSize(50, 50)
    cooldownFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    cooldownFrame:SetFrameLevel(3)
    self.GCDCooldownFrame = cooldownFrame
    cooldownFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    local r, g, b = self:GetClassColor("gcd")
    cooldownFrame:SetSwipeColor(r, g, b, 1.0)
    cooldownFrame:SetHideCountdownNumbers(true)

    local gcdRotation = db.gcdRotation or 12
    cooldownFrame:SetRotation(self:ClockToRadians(gcdRotation))
    cooldownFrame:Hide()

    local castBgFrame = CreateFrame("Cooldown", nil, self.CursorFrame)
    castBgFrame:SetSize(70, 70)
    castBgFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    castBgFrame:SetFrameLevel(2)
    self.CastBackgroundFrame = castBgFrame
    castBgFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    castBgFrame:SetSwipeColor(0.5, 0.5, 0.5, 0.7)
    castBgFrame:SetReverse(false)
    castBgFrame:SetHideCountdownNumbers(true)
    castBgFrame:SetCooldown(GetTime() - 1, 0.01)
    castBgFrame:Hide()

    local castFrame = CreateFrame("Cooldown", nil, self.CursorFrame)
    castFrame:SetSize(90, 90)
    castFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    castFrame:SetFrameLevel(3)
    self.CastFrame = castFrame
    castFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    r, g, b = self:GetClassColor("cast")
    castFrame:SetSwipeColor(r, g, b, 1.0)
    castFrame:SetHideCountdownNumbers(true)

    local castRotation = db.castRotation or 12
    castFrame:SetRotation(self:ClockToRadians(castRotation))
    castFrame:Hide()

    if self.ApplySettings then
        self:ApplySettings()
    end
end

function CursorCircle:SetupUI()
    local db = GetDb()
    if not db then return end

    local transparency = db.transparency or 1.0
    self.CursorFrame:SetAlpha(transparency)
    self.CursorFrame:SetFrameStrata("HIGH")
    self.CursorFrame:SetToplevel(false)
    self.CursorFrame:Show()
    self:SetGroupScale(self.currentGroupScale)
    self.CursorFrame.MainRing:Show()

    self:UpdateReticle()

    local gcdBgFrame = CreateFrame("Cooldown", "EdiUI_GCD_BG_COOLDOWN", self.CursorFrame)
    gcdBgFrame:SetSize(70, 70)
    gcdBgFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    gcdBgFrame:SetFrameLevel(2)
    self.GCDBackgroundFrame = gcdBgFrame
    gcdBgFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    gcdBgFrame:SetSwipeColor(0.5, 0.5, 0.5, 0.7)
    gcdBgFrame:SetReverse(false)
    gcdBgFrame:SetHideCountdownNumbers(true)
    gcdBgFrame:SetCooldown(GetTime() - 1, 0.01)
    gcdBgFrame:Hide()

    local cooldownFrame = CreateFrame("Cooldown", "EdiUI_GCD_COOLDOWN", self.CursorFrame)
    cooldownFrame:SetSize(50, 50)
    cooldownFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    cooldownFrame:SetFrameLevel(3)
    self.GCDCooldownFrame = cooldownFrame
    cooldownFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    local r, g, b = self:GetClassColor("gcd")
    cooldownFrame:SetSwipeColor(r, g, b, 1.0)
    cooldownFrame:SetHideCountdownNumbers(true)

    local gcdRotation = db.gcdRotation or 12
    cooldownFrame:SetRotation(self:ClockToRadians(gcdRotation))
    cooldownFrame:Hide()

    local castBgFrame = CreateFrame("Cooldown", "EdiUI_CAST_BG_COOLDOWN", self.CursorFrame)
    castBgFrame:SetSize(70, 70)
    castBgFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    castBgFrame:SetFrameLevel(2)
    self.CastBackgroundFrame = castBgFrame
    castBgFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    castBgFrame:SetSwipeColor(0.5, 0.5, 0.5, 0.7)
    castBgFrame:SetReverse(false)
    castBgFrame:SetHideCountdownNumbers(true)
    castBgFrame:SetCooldown(GetTime() - 1, 0.01)
    castBgFrame:Hide()

    local castFrame = CreateFrame("Cooldown", "EdiUI_CAST_COOLDOWN", self.CursorFrame)
    castFrame:SetSize(90, 90)
    castFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    castFrame:SetFrameLevel(3)
    self.CastFrame = castFrame
    castFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    r, g, b = self:GetClassColor("cast")
    castFrame:SetSwipeColor(r, g, b, 1.0)
    castFrame:SetHideCountdownNumbers(true)

    local castRotation = db.castRotation or 12
    castFrame:SetRotation(self:ClockToRadians(castRotation))
    castFrame:Hide()

    local healthBgFrame = self.CursorFrame:CreateTexture(nil, "ARTWORK")
    healthBgFrame:SetSize(70, 70)
    healthBgFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    healthBgFrame:SetTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    healthBgFrame:SetVertexColor(0.5, 0.5, 0.5, 0.7)
    self.HealthBackgroundFrame = healthBgFrame
    healthBgFrame:Hide()

    local healthFrame = CreateFrame("Cooldown", "EdiUI_HEALTH_COOLDOWN", self.CursorFrame)
    healthFrame:SetSize(70, 70)
    healthFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    healthFrame:SetFrameLevel(3)
    self.HealthFrame = healthFrame
    healthFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    healthFrame:SetSwipeColor(1.0, 0.0, 0.0, 0.8)
    healthFrame:SetReverse(false)
    healthFrame:SetHideCountdownNumbers(true)
    healthFrame:Hide()

    local powerFrame = CreateFrame("Cooldown", "EdiUI_POWER_COOLDOWN", self.CursorFrame)
    powerFrame:SetSize(80, 80)
    powerFrame:SetPoint("CENTER", self.CursorFrame, "CENTER")
    powerFrame:SetFrameLevel(1)
    self.PowerFrame = powerFrame
    powerFrame:SetSwipeTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    powerFrame:SetSwipeColor(0.0, 0.5, 1.0, 0.8)
    powerFrame:SetReverse(false)
    powerFrame:SetHideCountdownNumbers(true)
    powerFrame:Hide()

    local pingFrame = self.CursorFrame:CreateTexture(nil, "OVERLAY")
    pingFrame:SetTexture("Interface\\AddOns\\EdiUI\\Media\\CursorCircle\\Ring_Main")
    pingFrame:SetBlendMode("ADD")
    pingFrame:SetVertexColor(1.0, 1.0, 1.0, 0.5)
    pingFrame:Hide()
    self.PingFrame = pingFrame

    local crosshairFrame = CreateFrame("Frame", "EdiUI_CrosshairFrame", UIParent)
    crosshairFrame:SetFrameStrata("BACKGROUND")
    crosshairFrame:SetAllPoints()
    crosshairFrame:EnableMouse(false)
    crosshairFrame:Hide()
    self.CrosshairFrame = crosshairFrame

    local function CreateLine(name)
        local line = crosshairFrame:CreateTexture(nil, "OVERLAY")
        line:SetColorTexture(1, 1, 1, 0.5)
        line:SetWidth(2)
        return line
    end

    crosshairFrame.Top = CreateLine("Top")
    crosshairFrame.Bottom = CreateLine("Bottom")
    crosshairFrame.Left = CreateLine("Left")
    crosshairFrame.Right = CreateLine("Right")

    crosshairFrame.Left:SetWidth(0)
    crosshairFrame.Left:SetHeight(2)
    crosshairFrame.Right:SetWidth(0)
    crosshairFrame.Right:SetHeight(2)

    self:UpdateHealthRing()
    self:UpdatePowerRing()

    self:InitializeTrail()

    if self.ApplySettings then
        self:ApplySettings()
    end
end

function CursorCircle:ApplySettings()
    local db = GetDb()
    if not db then return end

    if db.scale then
        self:SetGroupScale(db.scale)
    end

    if self.CursorFrame then
        local transparency = db.transparency or 1.0
        self.CursorFrame:SetAlpha(transparency)
    end

    if self.GCDCooldownFrame then self.GCDCooldownFrame:Hide() end
    if self.GCDBackgroundFrame then self.GCDBackgroundFrame:Hide() end
    if self.CastFrame then self.CastFrame:Hide() end
    if self.CastBackgroundFrame then self.CastBackgroundFrame:Hide() end
    if self.HealthFrame then self.HealthFrame:Hide() end
    if self.HealthBackgroundFrame then self.HealthBackgroundFrame:Hide() end
    if self.PowerFrame then self.PowerFrame:Hide() end
    if self.CursorFrame and self.CursorFrame.MainRing then self.CursorFrame.MainRing:Hide() end

    if self.HighContrastRings then
        for _, ring in pairs(self.HighContrastRings) do
            if ring.outerHalf then ring.outerHalf:Hide() end
            if ring.innerHalf then ring.innerHalf:Hide() end
        end
    end

    self.enableGCD = false
    self.enableCast = false
    local trackHealth = false
    local trackPower = false

    local slots = {
        {config = db.innerRing, size = 50},
        {config = db.mainRing, size = 70},
        {config = db.outerRing, size = 90},
    }

    for _, slot in ipairs(slots) do
        local ringType = slot.config
        local size = slot.size

        if ringType == "Main Ring" then
            if self.CursorFrame and self.CursorFrame.MainRing then
                self.CursorFrame.MainRing:SetSize(size, size)
                self.CursorFrame.MainRing:Show()
            end

        elseif ringType == "GCD" then
            if self.GCDCooldownFrame then
                self.GCDCooldownFrame:SetSize(size, size)
                self.GCDCooldownFrame:Show()
                self.enableGCD = true
            end
            if size == 70 and self.GCDBackgroundFrame then
                self.GCDBackgroundFrame:SetSize(size, size)
                self.GCDBackgroundFrame:Show()
            end

        elseif ringType == "Cast" then
            if self.CastFrame then
                self.CastFrame:SetSize(size, size)
                self.CastFrame:Show()
                self.enableCast = true
            end
            if size == 70 and self.CastBackgroundFrame then
                self.CastBackgroundFrame:SetSize(size, size)
                self.CastBackgroundFrame:Show()
            end

        elseif ringType == "Health" then
            if self.HealthFrame then
                self.HealthFrame:SetSize(size, size)
                self.HealthFrame:Show()
                trackHealth = true
            end
            if self.HealthBackgroundFrame then
                self.HealthBackgroundFrame:SetSize(size, size)
                self.HealthBackgroundFrame:Show()
            end

        elseif ringType == "Power" then
            if self.PowerFrame then
                self.PowerFrame:SetSize(size, size)
                self.PowerFrame:Show()
                trackPower = true
            end

        elseif ringType == "Health and Power" then
            if self.HealthFrame then
                self.HealthFrame:SetSize(size, size)
                self.HealthFrame:Show()
                trackHealth = true
            end
            if self.HealthBackgroundFrame then
                self.HealthBackgroundFrame:SetSize(size, size)
                self.HealthBackgroundFrame:Show()
            end
            if self.PowerFrame then
                self.PowerFrame:SetSize(size + 10, size + 10)
                self.PowerFrame:Show()
                trackPower = true
            end

        elseif ringType == "Main Ring + GCD" then
            if self.CursorFrame and self.CursorFrame.MainRing then
                self.CursorFrame.MainRing:SetSize(size, size)
                self.CursorFrame.MainRing:Show()
            end
            if self.GCDCooldownFrame then
                self.GCDCooldownFrame:SetSize(size, size)
                self.GCDCooldownFrame:Show()
                self.enableGCD = true
            end
            if self.GCDBackgroundFrame then
                self.GCDBackgroundFrame:SetSize(size, size)
                self.GCDBackgroundFrame:Show()
            end

        elseif ringType == "Main Ring + Cast" then
            if self.CursorFrame and self.CursorFrame.MainRing then
                self.CursorFrame.MainRing:SetSize(size, size)
                self.CursorFrame.MainRing:Show()
            end
            if self.CastFrame then
                self.CastFrame:SetSize(size, size)
                self.CastFrame:Show()
                self.enableCast = true
            end
            if self.CastBackgroundFrame then
                self.CastBackgroundFrame:SetSize(size, size)
                self.CastBackgroundFrame:Show()
            end

        elseif ringType == "High Contrast Ring" then
            self:CreateHighContrastRing(size)
        end
    end

    if TrackerFrame then
        if self.enableGCD then
            TrackerFrame:RegisterEvent("UNIT_SPELLCAST_SENT")
        else
            TrackerFrame:UnregisterEvent("UNIT_SPELLCAST_SENT")
        end

        if self.enableCast then
            TrackerFrame:RegisterEvent("UNIT_SPELLCAST_START")
            TrackerFrame:RegisterEvent("UNIT_SPELLCAST_STOP")
            TrackerFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
            TrackerFrame:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
        else
            TrackerFrame:UnregisterEvent("UNIT_SPELLCAST_START")
            TrackerFrame:UnregisterEvent("UNIT_SPELLCAST_STOP")
            TrackerFrame:UnregisterEvent("UNIT_SPELLCAST_CHANNEL_START")
            TrackerFrame:UnregisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
        end

        if trackHealth then
            TrackerFrame:RegisterEvent("UNIT_HEALTH")
            TrackerFrame:RegisterEvent("UNIT_MAXHEALTH")
            if self.HealthFrame and self.HealthFrame:IsShown() then
                self:UpdateHealthRing()
            end
        else
            TrackerFrame:UnregisterEvent("UNIT_HEALTH")
            TrackerFrame:UnregisterEvent("UNIT_MAXHEALTH")
        end

        if trackPower then
            TrackerFrame:RegisterEvent("UNIT_POWER_UPDATE")
            TrackerFrame:RegisterEvent("UNIT_MAXPOWER")
            if self.PowerFrame and self.PowerFrame:IsShown() then
                self:UpdatePowerRing()
            end
        else
            TrackerFrame:UnregisterEvent("UNIT_POWER_UPDATE")
            TrackerFrame:UnregisterEvent("UNIT_MAXPOWER")
        end
    end

    self:UpdateRingColors()
    self:UpdateVisibility()
    self:UpdateReticle()
end

function CursorCircle:OnEnable()
    self:CreateCursorFrame()

    TrackerFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    TrackerFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    TrackerFrame:RegisterEvent("PLAYER_REGEN_ENABLED")

    local self = self
    TrackerFrame:SetScript("OnEvent", function(frame, event, ...)
        if event == "PLAYER_ENTERING_WORLD" then
            if self.CursorFrame then
                self:SetupUI()
            end
        elseif event:match("UNIT_SPELLCAST_") then
            self:GCDCastHandler(event, ...)
            self:CastEventHandler(event, ...)
        elseif event == "UNIT_HEALTH" or event == "UNIT_MAXHEALTH" then
            local unit = ...
            if unit == "player" then
                self:UpdateHealthRing()
            end
        elseif event == "UNIT_POWER_UPDATE" or event == "UNIT_MAXPOWER" then
            local unit = ...
            if unit == "player" then
                self:UpdatePowerRing()
            end
        elseif event == "PLAYER_REGEN_DISABLED" then
            self:UpdateVisibility(true)
        elseif event == "PLAYER_REGEN_ENABLED" then
            self:UpdateVisibility(false)
        end
    end)

    TrackerFrame:SetScript("OnUpdate", function(frame, elapsed)
        self:OnUpdate(elapsed)
    end)

    TrackerFrame:Show()
    self:OnUpdate(0)
end

function CursorCircle:OnDisable()
    if self.CursorFrame then
        self.CursorFrame:Hide()
    end
    TrackerFrame:Hide()
    TrackerFrame:SetScript("OnUpdate", nil)
    TrackerFrame:SetScript("OnEvent", nil)
    TrackerFrame:UnregisterAllEvents()
end
