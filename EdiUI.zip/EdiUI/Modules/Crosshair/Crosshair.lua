-- EdiUI Crosshair Module
-- Screen center crosshair overlay with optional range-based coloring
local EdiUI = EdiUI
local Crosshair = EdiUI:NewModule("Crosshair", "AceEvent-3.0")

local crosshairFrame
local horizLineLeft, horizLineRight, vertLineTop, vertLineBottom
local horizBorderLeft, horizBorderRight, vertBorderTop, vertBorderBottom
local rangeCheckFrame

local isOutOfRange = false
local isOutOfMidRange = false
local rangeCheckElapsed = 0
local RANGE_CHECK_INTERVAL = 0.1

local function GetSettings()
    return EdiUI.db and EdiUI.db.profile and EdiUI.db.profile.crosshair
end

local MELEE_RANGE_ABILITIES = {
    96231,  -- Paladin: Rebuke
    6552,   -- Warrior: Pummel
    1766,   -- Rogue: Kick
    116705, -- Monk: Spear Hand Strike
    183752, -- Demon Hunter: Disrupt (Havoc)
    228478, -- Vengeance DH: Soul Cleave
    263642, -- Vengeance DH: Fracture
    49143,  -- DK: Frost Strike
    55090,  -- DK: Scourge Strike
    206930, -- DK: Heart Strike
    100780, -- Monk: Tiger Palm
    100784, -- Monk: Blackout Kick
    107428, -- Monk: Rising Sun Kick
    5221,   -- Druid: Shred
    3252,   -- Druid: Shred (alt)
    1822,   -- Druid: Rake
    22568,  -- Druid: Ferocious Bite
    22570,  -- Druid: Maim
    33917,  -- Guardian: Mangle
    6807,   -- Guardian: Maul
}

local MID_RANGE_ABILITIES = {
    361469, -- Evoker: Living Flame
    356995, -- Evoker: Disintegrate
    382266, -- Evoker: Fire Breath
    357211, -- Evoker: Pyre
    355913, -- Evoker: Emerald Blossom
    360995, -- Evoker: Verdant Embrace
    364343, -- Evoker: Echo
    366155, -- Evoker: Reversion
    473662, -- Devourer DH: Consume
    1226019, -- Devourer DH: Reap
    473728, -- Devourer DH: Void Ray
}

local function IsOutOfMeleeRange()
    if not UnitExists("target") then
        return false
    end

    if not UnitCanAttack("player", "target") then
        return false
    end

    if UnitIsDeadOrGhost("target") then
        return false
    end

    if IsActionInRange then
        for slot = 1, 180 do
            local actionType, id, subType = GetActionInfo(slot)
            if id and (actionType == "spell" or (actionType == "macro" and subType == "spell")) then
                for _, abilityID in ipairs(MELEE_RANGE_ABILITIES) do
                    if id == abilityID then
                        local inRange = IsActionInRange(slot)
                        if inRange == true then
                            return false
                        elseif inRange == false then
                            return true
                        end
                    end
                end
            end
        end
    end

    if IsSpellInRange then
        local attackInRange = IsSpellInRange("Attack", "target")
        if attackInRange == 1 then
            return false
        elseif attackInRange == 0 then
            return true
        end
    end

    if C_Spell and C_Spell.IsSpellInRange then
        for _, spellID in ipairs(MELEE_RANGE_ABILITIES) do
            local spellKnown = IsSpellKnown and IsSpellKnown(spellID)
            if spellKnown then
                local inRange = C_Spell.IsSpellInRange(spellID, "target")
                if inRange == true then
                    return false
                elseif inRange == false then
                    return true
                end
            end
        end
    end

    local inRange = CheckInteractDistance("target", 3)
    if inRange ~= nil then
        return not inRange
    end

    return false
end

local function IsOutOfMidRange()
    if not UnitExists("target") then
        return false
    end

    if not UnitCanAttack("player", "target") then
        return false
    end

    if UnitIsDeadOrGhost("target") then
        return false
    end

    if IsActionInRange then
        local foundInRange = false
        local foundOutOfRange = false
        for slot = 1, 180 do
            local actionType, id, subType = GetActionInfo(slot)
            if id and (actionType == "spell" or (actionType == "macro" and subType == "spell")) then
                for _, abilityID in ipairs(MID_RANGE_ABILITIES) do
                    if id == abilityID then
                        local inRange = IsActionInRange(slot)
                        if inRange == false then
                            foundOutOfRange = true
                        elseif inRange == true then
                            foundInRange = true
                        end
                    end
                end
            end
        end
        if foundOutOfRange then
            return true
        end
        if foundInRange then
            return false
        end
    end

    if C_Spell and C_Spell.IsSpellInRange then
        for _, spellID in ipairs(MID_RANGE_ABILITIES) do
            if IsPlayerSpell and IsPlayerSpell(spellID) then
                local inRange = C_Spell.IsSpellInRange(spellID, "target")
                if inRange == true then
                    return false
                elseif inRange == false then
                    return true
                end
            end
        end
    end

    return false
end

local function ApplyCrosshairColor(settings, outOfMelee, outOfMid)
    if not horizLineLeft or not horizLineRight or not vertLineTop or not vertLineBottom then return end

    local r, g, b, a

    if settings.changeColorOnRange then
        local meleeCheck = settings.enableMeleeRangeCheck ~= false
        local midCheck = settings.enableMidRangeCheck == true

        if meleeCheck and midCheck then
            if outOfMid then
                local oorColor = settings.outOfRangeColor or { 1, 0.2, 0.2, 1 }
                r, g, b, a = oorColor[1] or 1, oorColor[2] or 0.2, oorColor[3] or 0.2, oorColor[4] or 1
            elseif outOfMelee then
                local midColor = settings.midRangeColor or { 1, 0.6, 0.2, 1 }
                r, g, b, a = midColor[1] or 1, midColor[2] or 0.6, midColor[3] or 0.2, midColor[4] or 1
            else
                local color = settings.color or {}
                r, g, b, a = color.r or 1, color.g or 0.949, color.b or 0, color.a or 1
            end
        elseif meleeCheck then
            if outOfMelee then
                local oorColor = settings.outOfRangeColor or { 1, 0.2, 0.2, 1 }
                r, g, b, a = oorColor[1] or 1, oorColor[2] or 0.2, oorColor[3] or 0.2, oorColor[4] or 1
            else
                local color = settings.color or {}
                r, g, b, a = color.r or 1, color.g or 0.949, color.b or 0, color.a or 1
            end
        elseif midCheck then
            if outOfMid then
                local oorColor = settings.outOfRangeColor or { 1, 0.2, 0.2, 1 }
                r, g, b, a = oorColor[1] or 1, oorColor[2] or 0.2, oorColor[3] or 0.2, oorColor[4] or 1
            else
                local color = settings.color or {}
                r, g, b, a = color.r or 1, color.g or 0.949, color.b or 0, color.a or 1
            end
        else
            local color = settings.color or {}
            r, g, b, a = color.r or 1, color.g or 0.949, color.b or 0, color.a or 1
        end
    else
        local color = settings.color or {}
        r, g, b, a = color.r or 1, color.g or 0.949, color.b or 0, color.a or 1
    end

    horizLineLeft:SetColorTexture(r, g, b, a)
    horizLineRight:SetColorTexture(r, g, b, a)
    vertLineTop:SetColorTexture(r, g, b, a)
    vertLineBottom:SetColorTexture(r, g, b, a)
end

local function OnRangeUpdate(self, elapsed)
    rangeCheckElapsed = rangeCheckElapsed + elapsed
    if rangeCheckElapsed < RANGE_CHECK_INTERVAL then return end
    rangeCheckElapsed = 0

    local settings = GetSettings()
    if not settings or not settings.enabled or not settings.changeColorOnRange then
        self:SetScript("OnUpdate", nil)
        return
    end

    local inCombat = InCombatLockdown()

    if settings.rangeColorInCombatOnly and not inCombat then
        if isOutOfRange or isOutOfMidRange then
            isOutOfRange = false
            isOutOfMidRange = false
            ApplyCrosshairColor(settings, false, false)
        end
        if settings.hideUntilOutOfRange and crosshairFrame then
            crosshairFrame:Hide()
        end
        return
    end

    local meleeCheck = settings.enableMeleeRangeCheck ~= false
    local midCheck = settings.enableMidRangeCheck == true

    local newOutOfRange = meleeCheck and IsOutOfMeleeRange() or false
    local newOutOfMidRange = midCheck and IsOutOfMidRange() or false

    if newOutOfRange ~= isOutOfRange or newOutOfMidRange ~= isOutOfMidRange then
        isOutOfRange = newOutOfRange
        isOutOfMidRange = newOutOfMidRange
        ApplyCrosshairColor(settings, isOutOfRange, isOutOfMidRange)
    end

    if settings.hideUntilOutOfRange and crosshairFrame then
        local shouldShow = inCombat and ((meleeCheck and isOutOfRange) or (midCheck and not meleeCheck and isOutOfMidRange))
        if shouldShow then
            crosshairFrame:Show()
        else
            crosshairFrame:Hide()
        end
    end
end

local function UpdateRangeChecking()
    if not crosshairFrame then return end

    if not rangeCheckFrame then
        rangeCheckFrame = CreateFrame("Frame", "EdiUI_CrosshairRangeCheck", UIParent)
        rangeCheckFrame:SetSize(1, 1)
        rangeCheckFrame:SetPoint("CENTER")
        rangeCheckFrame:Show()
    end

    local settings = GetSettings()
    if settings and settings.enabled and settings.changeColorOnRange then
        rangeCheckElapsed = 0
        rangeCheckFrame:SetScript("OnUpdate", OnRangeUpdate)

        local inCombat = InCombatLockdown()
        local meleeCheck = settings.enableMeleeRangeCheck ~= false
        local midCheck = settings.enableMidRangeCheck == true

        if settings.rangeColorInCombatOnly and not inCombat then
            isOutOfRange = false
            isOutOfMidRange = false
            ApplyCrosshairColor(settings, false, false)
        else
            isOutOfRange = meleeCheck and IsOutOfMeleeRange() or false
            isOutOfMidRange = midCheck and IsOutOfMidRange() or false
            ApplyCrosshairColor(settings, isOutOfRange, isOutOfMidRange)
        end

        if settings.hideUntilOutOfRange then
            if inCombat and isOutOfRange then
                crosshairFrame:Show()
            else
                crosshairFrame:Hide()
            end
        end
    else
        if rangeCheckFrame then
            rangeCheckFrame:SetScript("OnUpdate", nil)
        end
        isOutOfRange = false
        isOutOfMidRange = false
    end
end

local function CreateCrosshair()
    if crosshairFrame then return end

    crosshairFrame = CreateFrame("Frame", "EdiUI_Crosshair", UIParent)
    crosshairFrame:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    crosshairFrame:SetSize(1, 1)
    crosshairFrame:SetFrameStrata("HIGH")
    crosshairFrame:EnableMouse(false)

    horizBorderLeft = crosshairFrame:CreateTexture(nil, "BACKGROUND")
    horizBorderLeft:SetColorTexture(0, 0, 0, 1)
    horizBorderRight = crosshairFrame:CreateTexture(nil, "BACKGROUND")
    horizBorderRight:SetColorTexture(0, 0, 0, 1)
    vertBorderTop = crosshairFrame:CreateTexture(nil, "BACKGROUND")
    vertBorderTop:SetColorTexture(0, 0, 0, 1)
    vertBorderBottom = crosshairFrame:CreateTexture(nil, "BACKGROUND")
    vertBorderBottom:SetColorTexture(0, 0, 0, 1)

    horizLineLeft = crosshairFrame:CreateTexture(nil, "ARTWORK")
    horizLineLeft:SetColorTexture(1, 0.949, 0, 1)
    horizLineRight = crosshairFrame:CreateTexture(nil, "ARTWORK")
    horizLineRight:SetColorTexture(1, 0.949, 0, 1)
    vertLineTop = crosshairFrame:CreateTexture(nil, "ARTWORK")
    vertLineTop:SetColorTexture(1, 0.949, 0, 1)
    vertLineBottom = crosshairFrame:CreateTexture(nil, "ARTWORK")
    vertLineBottom:SetColorTexture(1, 0.949, 0, 1)

    crosshairFrame:Hide()
end

function Crosshair:Update()
    if not crosshairFrame then
        CreateCrosshair()
    end

    local settings = GetSettings()
    if not settings then
        crosshairFrame:Hide()
        return
    end

    local enabled = settings.enabled
    local size = settings.size
    if not size and type(settings.height) == "number" and settings.height >= 4 then
        size = settings.height
    end
    size = size or 12

    local thickness = settings.thickness or settings.width or 3
    local borderSize = settings.borderSize or settings.borderWidth or 2
    local gap = settings.gap or 35
    local halfGap = gap / 2
    local offsetX = settings.offsetX or 0
    local offsetY = settings.offsetY or 0
    local strata = settings.strata or "HIGH"
    local onlyInCombat = settings.onlyInCombat

    crosshairFrame:SetFrameStrata(strata)
    crosshairFrame:ClearAllPoints()
    crosshairFrame:SetPoint("CENTER", UIParent, "CENTER", offsetX, offsetY)

    horizLineLeft:SetSize(size, thickness)
    horizLineRight:SetSize(size, thickness)
    vertLineTop:SetSize(thickness, size)
    vertLineBottom:SetSize(thickness, size)

    horizLineLeft:ClearAllPoints()
    horizLineLeft:SetPoint("RIGHT", crosshairFrame, "CENTER", -halfGap, 0)
    horizLineRight:ClearAllPoints()
    horizLineRight:SetPoint("LEFT", crosshairFrame, "CENTER", halfGap, 0)
    vertLineTop:ClearAllPoints()
    vertLineTop:SetPoint("BOTTOM", crosshairFrame, "CENTER", 0, halfGap)
    vertLineBottom:ClearAllPoints()
    vertLineBottom:SetPoint("TOP", crosshairFrame, "CENTER", 0, -halfGap)

    if settings.showBorder then
        local borderColor = settings.borderColor or {}
        local borderR = settings.borderR or borderColor.r or 0
        local borderG = settings.borderG or borderColor.g or 0
        local borderB = settings.borderB or borderColor.b or 0
        local borderA = settings.borderA or borderColor.a or 1

        local borderLength = size + borderSize * 2
        local borderThickness = thickness + borderSize * 2

        horizBorderLeft:SetSize(borderLength, borderThickness)
        horizBorderRight:SetSize(borderLength, borderThickness)
        vertBorderTop:SetSize(borderThickness, borderLength)
        vertBorderBottom:SetSize(borderThickness, borderLength)

        horizBorderLeft:ClearAllPoints()
        horizBorderLeft:SetPoint("RIGHT", crosshairFrame, "CENTER", -halfGap, 0)
        horizBorderRight:ClearAllPoints()
        horizBorderRight:SetPoint("LEFT", crosshairFrame, "CENTER", halfGap, 0)
        vertBorderTop:ClearAllPoints()
        vertBorderTop:SetPoint("BOTTOM", crosshairFrame, "CENTER", 0, halfGap)
        vertBorderBottom:ClearAllPoints()
        vertBorderBottom:SetPoint("TOP", crosshairFrame, "CENTER", 0, -halfGap)

        horizBorderLeft:SetColorTexture(borderR, borderG, borderB, borderA)
        horizBorderRight:SetColorTexture(borderR, borderG, borderB, borderA)
        vertBorderTop:SetColorTexture(borderR, borderG, borderB, borderA)
        vertBorderBottom:SetColorTexture(borderR, borderG, borderB, borderA)

        horizBorderLeft:Show()
        horizBorderRight:Show()
        vertBorderTop:Show()
        vertBorderBottom:Show()
    else
        horizBorderLeft:Hide()
        horizBorderRight:Hide()
        vertBorderTop:Hide()
        vertBorderBottom:Hide()
    end

    if settings.changeColorOnRange then
        local meleeCheck = settings.enableMeleeRangeCheck ~= false
        local midCheck = settings.enableMidRangeCheck == true
        isOutOfRange = meleeCheck and IsOutOfMeleeRange() or false
        isOutOfMidRange = midCheck and IsOutOfMidRange() or false
        ApplyCrosshairColor(settings, isOutOfRange, isOutOfMidRange)
    else
        local color = settings.color or {}
        local r = settings.r or color.r or 1
        local g = settings.g or color.g or 0.949
        local b = settings.b or color.b or 0
        local a = settings.a or color.a or 1
        horizLineLeft:SetColorTexture(r, g, b, a)
        horizLineRight:SetColorTexture(r, g, b, a)
        vertLineTop:SetColorTexture(r, g, b, a)
        vertLineBottom:SetColorTexture(r, g, b, a)
    end

    if not enabled then
        crosshairFrame:Hide()
        crosshairFrame:SetScript("OnUpdate", nil)
    elseif onlyInCombat then
        crosshairFrame:SetShown(InCombatLockdown())
    else
        crosshairFrame:Show()
    end

    UpdateRangeChecking()
end

function Crosshair:OnCombatStart()
    local settings = GetSettings()
    if settings and settings.enabled and settings.onlyInCombat then
        if crosshairFrame then
            crosshairFrame:Show()
            UpdateRangeChecking()
        end
    end
end

function Crosshair:OnCombatEnd()
    local settings = GetSettings()
    if settings and settings.onlyInCombat then
        if crosshairFrame then
            crosshairFrame:Hide()
            crosshairFrame:SetScript("OnUpdate", nil)
        end
    end
end

function Crosshair:OnTargetChanged()
    local settings = GetSettings()
    if settings and settings.enabled and settings.changeColorOnRange then
        local meleeCheck = settings.enableMeleeRangeCheck ~= false
        local midCheck = settings.enableMidRangeCheck == true
        isOutOfRange = meleeCheck and IsOutOfMeleeRange() or false
        isOutOfMidRange = midCheck and IsOutOfMidRange() or false
        ApplyCrosshairColor(settings, isOutOfRange, isOutOfMidRange)
    end
end

function Crosshair:OnEnable()
    self:RegisterEvent("PLAYER_REGEN_DISABLED", "OnCombatStart")
    self:RegisterEvent("PLAYER_REGEN_ENABLED", "OnCombatEnd")
    self:RegisterEvent("PLAYER_TARGET_CHANGED", "OnTargetChanged")

    C_Timer.After(1, function()
        if self.Update then
            self:Update()
        end
    end)
end

function Crosshair:OnDisable()
    if crosshairFrame then
        crosshairFrame:Hide()
    end
    if rangeCheckFrame then
        rangeCheckFrame:SetScript("OnUpdate", nil)
    end
end

EdiUI.RefreshCrosshair = function()
    if Crosshair and Crosshair.Update then
        Crosshair:Update()
    end
end
