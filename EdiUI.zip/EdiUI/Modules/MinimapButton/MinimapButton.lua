-- EdiUI Minimap Button
local EdiUI = EdiUI
local MinimapButton = EdiUI:NewModule("MinimapButton", "AceEvent-3.0")

local button = nil

function MinimapButton:CreateButton()
    if button then return end

    button = CreateFrame("Button", "EdiUI_MinimapButton", Minimap)
    button:SetSize(32, 32)
    button:SetFrameStrata("MEDIUM")
    button:SetFrameLevel(8)

    -- Position at top right of minimap
    button:SetPoint("TOPRIGHT", Minimap, "TOPRIGHT", 0, 0)

    -- Icon texture
    local icon = button:CreateTexture(nil, "ARTWORK")
    icon:SetSize(24, 24)
    icon:SetPoint("CENTER", button, "CENTER", 0, 0)
    icon:SetTexture("Interface\\AddOns\\EdiUI\\Media\\Logo\\logo.tga")
    button.icon = icon

    -- Background
    local bg = button:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(28, 28)
    bg:SetPoint("CENTER", button, "CENTER", 0, 0)
    bg:SetColorTexture(0, 0, 0, 0.6)
    button.bg = bg

    -- Highlight
    local highlight = button:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetSize(24, 24)
    highlight:SetPoint("CENTER", button, "CENTER", 0, 0)
    highlight:SetColorTexture(1, 1, 1, 0.2)

    -- Scripts
    button:SetScript("OnClick", function(self, btn)
        if btn == "LeftButton" then
            if EdiUI.OpenOptions then
                EdiUI:OpenOptions()
            end
        elseif btn == "RightButton" then
            if EdiUI.Installer and EdiUI.Installer.Show then
                EdiUI.Installer:Show()
            end
        end
    end)

    button:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("|cffe74c3cEdi|r|cffffc84aUI|r", 1, 1, 1)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cffffffffLeft-click:|r Open settings", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("|cffffffffRight-click:|r Open installer", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)

    button:SetScript("OnLeave", function(self)
        GameTooltip:Hide()
    end)

    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:Show()
end

function MinimapButton:OnEnable()
    self:CreateButton()
end

function MinimapButton:OnDisable()
    if button then
        button:Hide()
    end
end
