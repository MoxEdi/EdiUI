-- EdiUI Utilities Module
-- Changelog, Conflict Detection, Performance Monitor
local EdiUI = EdiUI

-- Colors
local COLOR_GOLD = { r = 1.0, g = 0.78, b = 0.29 }
local COLOR_BLUE = { r = 0.906, g = 0.298, b = 0.235 }
local GOLD_HEX = "|cffffc84a"
local BLUE_HEX = "|cffe74c3c"

-- ============================================================================
-- CHANGELOG SYSTEM
-- ============================================================================
local Changelog = {}
EdiUI.Changelog = Changelog

-- Changelog entries (newest first)
Changelog.Entries = {
    {
        version = "1.400",
        date = "2026-02-04",
        changes = {
            "NEW: M+ Teleports",
            "NEW: Crosshair",
            "NEW: Trinket Tracker",
            "NEW: Installer EditMode step",
            "UPDATED: CursorCircle reworked",
            "UPDATED: EditMode import reworked",
            "UPDATED: Installer flow reworked",
            "UPDATED: Installer auto-open logic reworked",
        }
    },
    {
        version = "1.300",
        date = "2026-02-03",
        changes = {
            "NEW: Quality of Life (QoL) tab with 3 sub-tabs",
            "AUTOMATION: Auto-accept/turn-in quests with override key",
            "AUTOMATION: Auto-accept summons and resurrections",
            "AUTOMATION: Auto-release in PvP zones (with exclusions)",
            "AUTOMATION: Auto-sell junk and auto-repair at vendors",
            "AUTOMATION: Automate gossip (hold Alt for single options)",
            "SOCIAL: Block duels, pet battles, party invites from non-friends",
            "SOCIAL: Block friend requests and shared quests",
            "SOCIAL: Auto-accept party/sync/queue from friends",
            "SOCIAL: Invite players via whisper keyword",
            "SOCIAL: Treat guild/community members as friends",
            "SYSTEM: Disable screen glow and death effects",
            "SYSTEM: Weather density control and max camera zoom",
            "SYSTEM: Faster looting and movie skip",
            "SYSTEM: Combat nameplates and easy item destroy",
        }
    },
    {
        version = "1.226",
        date = "2026-02-02",
        changes = {
            "NEW: Changelog popup shows what's new after updates",
            "NEW: Conflict detection warns about potentially conflicting addons",
            "NEW: Performance monitor (/eui perf)",
            "Added resize grip and reset size button (ElvUI style)",
            "Fixed installer not reopening after reload actions",
            "Disabled mousewheel on sliders to prevent accidental changes",
            "Renamed 'Gap' to 'Y Offset' in Cooldown Manager options",
            "Ensured X Offset sliders are on left, Y Offset on right",
            "Centered installer buttons from step 2 onwards",
        }
    },
    {
        version = "1.218",
        date = "2026-01-15",
        changes = {
            "Initial release with Sushi-based options panel",
            "Portrait customization for all unit frames",
            "Cooldown Manager integration",
            "Power Bar, Class Bar, and Cast Bar modules",
            "Cluster Positioning for ElvUI frames",
            "Profile import/export system",
        }
    },
}

local ChangelogFrame = nil

function Changelog:ShouldShow()
    if not EdiUI.db or not EdiUI.db.global then return false end

    local lastSeen = EdiUI.db.global.lastSeenVersion or "0"
    local current = EdiUI.Version or "1.0"

    return lastSeen ~= current
end

function Changelog:MarkSeen()
    if not EdiUI.db or not EdiUI.db.global then return end
    EdiUI.db.global.lastSeenVersion = EdiUI.Version or "1.0"
end

function Changelog:Show()
    if ChangelogFrame then
        ChangelogFrame:Show()
        return
    end

    -- Create frame
    local frame = CreateFrame("Frame", "EdiUI_ChangelogFrame", UIParent, "BackdropTemplate")
    frame:SetSize(500, 450)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(100)
    frame:SetToplevel(true)
    frame:EnableMouse(true)
    frame:SetMovable(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:SetClampedToScreen(true)

    frame:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        tile = false,
        edgeSize = 1,
        insets = { left = 0, right = 0, top = 0, bottom = 0 }
    })
    frame:SetBackdropColor(0.08, 0.08, 0.1, 0.98)
    frame:SetBackdropBorderColor(0.3, 0.3, 0.35, 1)

    -- Title bar
    local titleBar = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    titleBar:SetHeight(40)
    titleBar:SetPoint("TOPLEFT", 0, 0)
    titleBar:SetPoint("TOPRIGHT", 0, 0)
    titleBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8" })
    titleBar:SetBackdropColor(0.12, 0.12, 0.15, 1)

    -- Title
    local title = titleBar:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("LEFT", 15, 0)
    title:SetText(BLUE_HEX .. "Edi" .. GOLD_HEX .. "UI|r " .. GOLD_HEX .. "- What's New!|r")

    -- Close button
    local closeBtn = CreateFrame("Button", nil, titleBar)
    closeBtn:SetSize(30, 30)
    closeBtn:SetPoint("RIGHT", -5, 0)
    closeBtn:SetNormalFontObject("GameFontNormalLarge")
    closeBtn:SetText("X")
    closeBtn:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)
    closeBtn:SetScript("OnClick", function()
        Changelog:MarkSeen()
        frame:Hide()
    end)
    closeBtn:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(1, 0.3, 0.3) end)
    closeBtn:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b) end)

    -- Content scroll frame
    local scrollFrame = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 15, -50)
    scrollFrame:SetPoint("BOTTOMRIGHT", -35, 60)

    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(440, 1)
    scrollFrame:SetScrollChild(content)

    -- Build changelog content
    local yOffset = 0
    for i, entry in ipairs(self.Entries) do
        -- Version header
        local versionHeader = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        versionHeader:SetPoint("TOPLEFT", 0, -yOffset)
        versionHeader:SetText(GOLD_HEX .. "v" .. entry.version .. "|r " .. BLUE_HEX .. "(" .. entry.date .. ")|r")
        yOffset = yOffset + 25

        -- Changes
        for _, change in ipairs(entry.changes) do
            local changeLine = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            changeLine:SetPoint("TOPLEFT", 15, -yOffset)
            changeLine:SetPoint("RIGHT", -10, 0)
            changeLine:SetJustifyH("LEFT")
            changeLine:SetText(GOLD_HEX .. "•|r " .. change)
            changeLine:SetWordWrap(true)
            local height = changeLine:GetStringHeight() or 14
            yOffset = yOffset + height + 5
        end

        yOffset = yOffset + 15
    end

    content:SetHeight(yOffset + 20)

    -- "Don't show again" checkbox
    local dontShow = CreateFrame("CheckButton", nil, frame, "UICheckButtonTemplate")
    dontShow:SetPoint("BOTTOMLEFT", 15, 15)
    dontShow:SetSize(24, 24)
    dontShow.text = dontShow:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    dontShow.text:SetPoint("LEFT", dontShow, "RIGHT", 5, 0)
    dontShow.text:SetText("Don't show this again")
    dontShow.text:SetTextColor(0.8, 0.8, 0.8)
    dontShow:SetScript("OnClick", function(self)
        if self:GetChecked() then
            Changelog:MarkSeen()
        end
    end)

    -- OK button
    local okBtn = CreateFrame("Button", nil, frame, "BackdropTemplate")
    okBtn:SetSize(100, 30)
    okBtn:SetPoint("BOTTOMRIGHT", -15, 15)
    okBtn:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    okBtn:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
    okBtn:SetBackdropBorderColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b, 1)

    local okText = okBtn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    okText:SetPoint("CENTER")
    okText:SetText("Got it!")
    okText:SetTextColor(COLOR_GOLD.r, COLOR_GOLD.g, COLOR_GOLD.b)

    okBtn:SetScript("OnClick", function()
        Changelog:MarkSeen()
        frame:Hide()
    end)
    okBtn:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.35, 0.7, 1, 1)
    end)
    okBtn:SetScript("OnLeave", function(self)
        self:SetBackdropColor(COLOR_BLUE.r, COLOR_BLUE.g, COLOR_BLUE.b, 1)
    end)

    -- Apply ElvUI skin if available
    if EdiUI.Skin and EdiUI.Skin:IsEnabled() then
        EdiUI.Skin:ApplyFrame(frame, 'Transparent')
        EdiUI.Skin:ApplyFrame(titleBar, 'Transparent')
        EdiUI.Skin:ApplyCloseButton(closeBtn)
        EdiUI.Skin:ApplyButton(okBtn)
        EdiUI.Skin:ApplyCheckBox(dontShow)
        if scrollFrame.ScrollBar then
            EdiUI.Skin:ApplyScrollBar(scrollFrame.ScrollBar)
        end
    end

    tinsert(UISpecialFrames, "EdiUI_ChangelogFrame")
    ChangelogFrame = frame
end

function Changelog:MaybeShow()
    if self:ShouldShow() then
        C_Timer.After(2, function()
            self:Show()
        end)
    end
end

-- ============================================================================
-- CONFLICT DETECTION
-- ============================================================================
local ConflictDetection = {}
EdiUI.ConflictDetection = ConflictDetection

-- Known conflicting addons
ConflictDetection.KnownConflicts = {
    {
        addon = "ShadowedUnitFrames",
        module = "Portraits",
        severity = "warning",
        message = "May conflict with EdiUI portrait frames"
    },
    {
        addon = "Bartender4",
        module = "General",
        severity = "info",
        message = "Both addons may modify action bars"
    },
    {
        addon = "Dominos",
        module = "General",
        severity = "info",
        message = "Both addons may modify action bars"
    },
    {
        addon = "TidyPlates",
        module = "Portraits",
        severity = "info",
        message = "May interfere with nameplate portraits"
    },
    {
        addon = "Kui_Nameplates",
        module = "Portraits",
        severity = "info",
        message = "May interfere with nameplate portraits"
    },
    {
        addon = "Plater",
        module = "Portraits",
        severity = "info",
        message = "Both addons modify nameplates"
    },
}

function ConflictDetection:Check()
    local conflicts = {}
    local Compat = EdiUI.Compat or {}
    local IsAddOnLoaded = Compat.IsAddOnLoaded or (C_AddOns and C_AddOns.IsAddOnLoaded)

    if not IsAddOnLoaded then return conflicts end

    for _, conflict in ipairs(self.KnownConflicts) do
        if IsAddOnLoaded(conflict.addon) then
            table.insert(conflicts, conflict)
        end
    end

    return conflicts
end

function ConflictDetection:Report()
    local conflicts = self:Check()

    if #conflicts == 0 then
        EdiUI:Print("|cff00ff00No addon conflicts detected!|r")
        return
    end

    EdiUI:Print(GOLD_HEX .. "Potential addon conflicts detected:|r")
    for _, conflict in ipairs(conflicts) do
        local color = conflict.severity == "warning" and "|cffff8800" or "|cff888888"
        EdiUI:Print(color .. "  • " .. conflict.addon .. ":|r " .. conflict.message)
    end
end

function ConflictDetection:MaybeWarn()
    local conflicts = self:Check()
    local warnings = {}

    for _, conflict in ipairs(conflicts) do
        if conflict.severity == "warning" then
            table.insert(warnings, conflict)
        end
    end

    if #warnings > 0 then
        C_Timer.After(3, function()
            EdiUI:Print(GOLD_HEX .. "Warning:|r " .. #warnings .. " potential addon conflict(s) detected. Type /eui conflicts for details.")
        end)
    end
end

-- ============================================================================
-- PERFORMANCE MONITOR
-- ============================================================================
local PerfMonitor = {}
EdiUI.PerfMonitor = PerfMonitor

function PerfMonitor:GetMemoryUsage()
    UpdateAddOnMemoryUsage()
    local mem = GetAddOnMemoryUsage("EdiUI")
    return mem
end

function PerfMonitor:GetFormattedMemory()
    local mem = self:GetMemoryUsage()
    if mem > 1024 then
        return string.format("%.2f MB", mem / 1024)
    else
        return string.format("%.0f KB", mem)
    end
end

function PerfMonitor:Report()
    EdiUI:Print(GOLD_HEX .. "EdiUI Performance Report:|r")
    EdiUI:Print("  Memory Usage: " .. self:GetFormattedMemory())

    -- Check module status
    local modules = {
        "CooldownManager",
        "PowerBar",
        "ClassBar",
        "CastBar",
        "ClusterPositioning",
        "CursorCircle",
        "General",
    }

    EdiUI:Print("  " .. GOLD_HEX .. "Module Status:|r")
    for _, moduleName in ipairs(modules) do
        local module = EdiUI:GetModule(moduleName, true) or EdiUI[moduleName]
        local status = module and "|cff00ff00Loaded|r" or "|cff888888Not loaded|r"
        EdiUI:Print("    • " .. moduleName .. ": " .. status)
    end
end

-- ============================================================================
-- SLASH COMMAND EXTENSIONS
-- ============================================================================
local originalCMD = EdiUI.CMD
function EdiUI:CMD(msg)
    msg = msg and msg:lower() or ""

    if msg == "changelog" or msg == "changes" or msg == "whatsnew" then
        Changelog:Show()
    elseif msg == "conflicts" then
        ConflictDetection:Report()
    elseif msg == "perf" or msg == "performance" then
        PerfMonitor:Report()
    else
        -- Call original handler
        if originalCMD then
            originalCMD(self, msg)
        end
    end
end

-- ============================================================================
-- INITIALIZATION
-- ============================================================================
C_Timer.After(1.5, function()
    -- Show changelog if version changed
    Changelog:MaybeShow()

    -- Warn about conflicts
    ConflictDetection:MaybeWarn()
end)
