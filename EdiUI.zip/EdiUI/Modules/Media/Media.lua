-- EdiUI Media Module
-- Registers fonts and textures via LibSharedMedia
local EdiUI = EdiUI
local Media = EdiUI.Media

local LSM = LibStub("LibSharedMedia-3.0")

-- ============================================================================
-- FONTS
-- ============================================================================
LSM:Register("font", "EdiFont", [[Interface\AddOns\EdiUI\Media\Fonts\EdiFont.ttf]])
LSM:Register("font", "GothamNarrowUltra", [[Interface\AddOns\EdiUI\Media\Fonts\GothamNarrowUltra.ttf]])

-- ============================================================================
-- TEXTURES (Statusbars)
-- ============================================================================
LSM:Register("statusbar", "Melli", [[Interface\AddOns\EdiUI\Media\Textures\Melli]])
LSM:Register("statusbar", "bar1", [[Interface\AddOns\EdiUI\Media\Textures\bar1]])
LSM:Register("statusbar", "bar2", [[Interface\AddOns\EdiUI\Media\Textures\bar2]])
LSM:Register("statusbar", "bar3", [[Interface\AddOns\EdiUI\Media\Textures\bar3]])
LSM:Register("statusbar", "bar4", [[Interface\AddOns\EdiUI\Media\Textures\bar4]])
LSM:Register("statusbar", "bar5", [[Interface\AddOns\EdiUI\Media\Textures\bar5]])
LSM:Register("statusbar", "bar6", [[Interface\AddOns\EdiUI\Media\Textures\bar6]])
LSM:Register("statusbar", "bar7", [[Interface\AddOns\EdiUI\Media\Textures\bar7]])
LSM:Register("statusbar", "EthricArrow", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow]])
LSM:Register("statusbar", "EthricArrow2", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow2]])
LSM:Register("statusbar", "EthricArrow3", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow3]])
LSM:Register("statusbar", "EthricArrow4", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow4]])
LSM:Register("statusbar", "EthricArrow5", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow5]])
LSM:Register("statusbar", "EthricArrow6", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow6]])
LSM:Register("statusbar", "EthricArrow7", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow7]])
LSM:Register("statusbar", "EthricArrow8", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow8]])
LSM:Register("statusbar", "EthricArrow9", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow9]])
LSM:Register("statusbar", "EthricArrow10", [[Interface\AddOns\EdiUI\Media\Textures\EthricArrow10]])
LSM:Register("statusbar", "mouseover-2", [[Interface\AddOns\EdiUI\Media\Textures\mouseover-2]])
LSM:Register("statusbar", "mouseover-3", [[Interface\AddOns\EdiUI\Media\Textures\mouseover-3]])
LSM:Register("statusbar", "mouseover-3-inwards", [[Interface\AddOns\EdiUI\Media\Textures\mouseover-3-inwards]])
