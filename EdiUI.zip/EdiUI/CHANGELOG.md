# EdiUI Changelog

## Version 1.400

### New Features
- M+ Teleports added.
- Crosshair added.
- Trinket Tracker added.
- Installer EditMode step added.

### Changes
- CursorCircle reworked.
- EditMode import reworked.
- Installer flow reworked.
- Installer auto-open logic reworked.

## Version 1.300

### New Features

**Quality of Life Module**
- Added comprehensive quest automation
  - Auto-accept quests
  - Auto-complete quests
  - Auto-turn in quests
  - Modifier key override support
- Gossip automation - automatically select options
- Vendor automation features
- PvP release automation
- Social features panel
- System utilities panel

**Profile Imports**
- BigWigs profile import with automatic addon loading
  - Detects Load-on-Demand addons properly
  - Force-loads BigWigs modules when needed
  - Multiple fallback import methods
- Plater profile import with V2 format support
  - Native WoW API decoding (Base64/Decompress/CBOR)
  - Backwards compatible with old format
- EditMode profile import

**Installer Improvements**
- Fixed BigWigs detection for Load-on-Demand addons
- Improved profile import reliability
- ElvUI-styled close button (removed duplicate X)

**UI Improvements**
- Glitch effect on logo with cyberpunk-style chromatic aberration
- ElvUI skin integration throughout
- Reorganized options tabs (QoL moved below Cursor Circle)
- Cleaner close buttons with ElvUI styling

**Modules**
- Cursor Circle module
- Power Bar customization
- Class Bar customization
- Cast Bar customization
- Cooldown Manager

### Bug Fixes
- Fixed quest automation not triggering (switched to raw frame events)
- Fixed BigWigs not being detected when not yet loaded
- Fixed BigWigs profile import failing on first attempt
- Fixed duplicate close buttons in Options and Installer panels
- Fixed Plater import issues with WoW 12.0 API changes

---

## Version 1.226 and earlier
- Initial release with core functionality
- Portrait system
- Media management
- Basic ElvUI integration
