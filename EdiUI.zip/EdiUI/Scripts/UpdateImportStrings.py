import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
PROFILES_DIR = ROOT / "Profiles"
OUTPUT = PROFILES_DIR / "CustomImportStrings.lua"

FILES = [
    ("ElvUI", PROFILES_DIR / "ElvUI.txt"),
    ("ElvUIDark", PROFILES_DIR / "ElvUIDark.txt"),
    ("ElvUIAuras", PROFILES_DIR / "ElvUIAura.txt"),
    ("ElvUIPrivate", PROFILES_DIR / "ElvUIPrivate.txt"),
    ("ElvUIGlobal", PROFILES_DIR / "ElvUIGlobal.txt"),
    ("Plater", PROFILES_DIR / "Plater.txt"),
    ("Details", PROFILES_DIR / "Details.txt"),
    ("EditMode", PROFILES_DIR / "EditMode.txt"),
]

parts = []
parts.append("-- User-editable import strings. Regenerated from Profiles/*.txt.\n")
parts.append("local EdiUI = EdiUI\n")
parts.append("if not EdiUI or not EdiUI.Profiles then return end\n\n")
parts.append("EdiUI_CustomImportStrings = {\n")

for key, path in FILES:
    if path.exists():
        data = path.read_text(encoding="utf-8")
    else:
        data = ""
    parts.append(f'    ["{key}"] = [=[{data}]=],\n')

parts.append("}\n")
OUTPUT.write_text("".join(parts), encoding="utf-8")
print(f"Wrote {OUTPUT}")
