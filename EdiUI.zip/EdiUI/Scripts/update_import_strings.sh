#!/bin/bash
# Update CustomImportStrings.lua from .txt profile files
# Run this script after updating any profile .txt files

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ADDON_DIR="$(dirname "$SCRIPT_DIR")"
PROFILES_DIR="$ADDON_DIR/Profiles"
OUTPUT_FILE="$PROFILES_DIR/CustomImportStrings.lua"

# Define the profile files to include (order matters for readability)
declare -a PROFILES=(
    "ElvUI:ElvUI.txt"
    "ElvUIDark:ElvUIDark.txt"
    "ElvUIAuras:ElvUIAura.txt"
    "ElvUIPrivate:ElvUIPrivate.txt"
    "ElvUIGlobal:ElvUIGlobal.txt"
    "Details:Details.txt"
    "Plater:Plater.txt"
    "EditMode:EditMode.txt"
    "BigWigs:BigWigs.txt"
)

echo "Updating CustomImportStrings.lua..."
echo "Profiles directory: $PROFILES_DIR"

# Start the output file
cat > "$OUTPUT_FILE" << 'HEADER'
-- User-editable import strings for EdiUI.
-- Auto-generated from Profiles/*.txt files
-- Run Scripts/update_import_strings.sh to regenerate
EdiUI_CustomImportStrings = {
HEADER

# Process each profile
FIRST=true
for entry in "${PROFILES[@]}"; do
    KEY="${entry%%:*}"
    FILE="${entry##*:}"
    FILEPATH="$PROFILES_DIR/$FILE"

    if [[ -f "$FILEPATH" ]]; then
        CONTENT=$(cat "$FILEPATH")

        if [[ -n "$CONTENT" ]]; then
            if [[ "$FIRST" != true ]]; then
                echo "" >> "$OUTPUT_FILE"
            fi
            FIRST=false

            echo "    [\"$KEY\"] = [=[$CONTENT]=]," >> "$OUTPUT_FILE"
            echo "  Added: $KEY ($FILE)"
        else
            echo "  Skipped: $KEY ($FILE) - empty file"
        fi
    else
        echo "  Missing: $KEY ($FILE)"
    fi
done

# Close the table
echo "}" >> "$OUTPUT_FILE"

echo ""
echo "Done! Output written to:"
echo "  $OUTPUT_FILE"
echo ""
echo "Note: WarpDeplete uses WarpDepleteProfile.lua directly (not included here)"
